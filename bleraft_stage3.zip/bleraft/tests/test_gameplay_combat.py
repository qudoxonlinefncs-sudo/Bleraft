import types
import unittest

import settings
from combat.attacks import resolve_attack
from core.gameplay import GameplayState
from core.loop import FixedStepLoop
from entities.fighter import FighterState as S
from input.command_input import CommandInput
from input.commands import AttackKeyCommand, ResetCommand, StrokeCommand
from input.gesture_recorder import GestureRecorder, Stroke
from tests.helpers import circle_points, make_stroke, shape_stroke
from tests.test_command_input import down, fake_pygame, move, up


class NoMove:
    def direction(self, index):
        return (0, 0)


def state(**kw):
    s = GameplayState(NoMove(), **kw)
    blue, red = s.fighters
    red.x = red.prev_x = blue.x + 60       # вплотную друг к другу
    red.y = red.prev_y = blue.y
    return s


def stroke_command(player, points):
    return StrokeCommand(player, Stroke(tuple(points)))


def run(s, seconds, dt=1 / 60):
    for _ in range(int(round(seconds / dt))):
        s.update(dt)


class StrokeToAttackTests(unittest.TestCase):
    def test_recognized_gesture_starts_windup_not_instant_damage(self):
        s = state()
        blue, red = s.fighters
        s.execute(stroke_command(0, shape_stroke("slash", scale=200, duration=0.4)))
        self.assertEqual(blue.state, S.WINDUP)
        self.assertEqual(red.hp, red.max_hp)
        self.assertEqual(blue.attack.spec.name, "slash")

    def test_damage_arrives_only_after_windup(self):
        s = state()
        blue, red = s.fighters
        s.execute(stroke_command(0, shape_stroke("thrust", scale=200, duration=0.4)))
        windup = blue.attack.spec.windup
        t = 0.0
        while t < windup - 0.03:
            s.update(1 / 60)
            t += 1 / 60
            self.assertEqual(red.hp, red.max_hp)
        run(s, 0.3)
        self.assertLess(red.hp, red.max_hp)

    def test_each_gesture_launches_its_own_attack(self):
        for name in ("slash", "sweep", "thrust", "double"):
            s = state()
            s.execute(stroke_command(0, shape_stroke(name, scale=200)))
            self.assertEqual(s.fighters[0].attack.spec.name, name)

    def test_unknown_gestures_do_not_start_attacks(self):
        bad = [make_stroke(circle_points()), shape_stroke("backslash"), shape_stroke("L"),
               shape_stroke("slash", scale=20), [(100, 100, 0.0)], []]
        for points in bad:
            s = state()
            s.execute(stroke_command(0, points))
            self.assertEqual(s.fighters[0].state, S.IDLE)
            self.assertIsNone(s.fighters[0].attack)
            self.assertIsNone(s.effects.indicators[0].gesture)
            self.assertFalse(s.effects.indicators[0].accepted)

    def test_unknown_gesture_does_not_break_a_running_combo(self):
        s = state()
        blue, _ = s.fighters
        s.execute(stroke_command(0, shape_stroke("slash", scale=200)))
        run(s, 0.1)
        s.execute(stroke_command(0, make_stroke(circle_points())))
        self.assertEqual(blue.combo.history, ["slash"])
        run(s, 1.0)                                      # цикл продолжает работать

    def test_gesture_speed_changes_the_attack(self):
        fast, slow = state(), state()
        fast.execute(stroke_command(0, shape_stroke("slash", scale=200, duration=0.15)))
        slow.execute(stroke_command(0, shape_stroke("slash", scale=200, duration=0.9)))
        f, sl = fast.fighters[0].attack.spec, slow.fighters[0].attack.spec
        self.assertEqual((f.tier, sl.tier), ("fast", "slow"))
        self.assertLess(f.windup, sl.windup)
        self.assertLess(f.recovery, sl.recovery)
        self.assertLess(f.damage, sl.damage)

    def test_fast_slash_hits_sooner_but_weaker_than_slow(self):
        results = {}
        for tier, duration in (("fast", 0.15), ("slow", 0.9)):
            s = state()
            s.execute(stroke_command(0, shape_stroke("slash", scale=200, duration=duration)))
            red = s.fighters[1]
            for i in range(120):
                s.update(1 / 60)
                if red.hp < red.max_hp:
                    results[tier] = (i / 60, red.max_hp - red.hp)
                    break
        self.assertLess(results["fast"][0], results["slow"][0])
        self.assertLess(results["fast"][1], results["slow"][1])

    def test_indicator_reports_gesture_tier_and_acceptance(self):
        s = state()
        s.execute(stroke_command(0, shape_stroke("sweep", scale=200, duration=0.15)))
        ind = s.effects.indicators[0]
        self.assertEqual((ind.gesture, ind.tier, ind.accepted), ("sweep", "fast", True))
        s.execute(stroke_command(0, shape_stroke("sweep", scale=200, duration=0.15)))   # занят
        self.assertFalse(s.effects.indicators[0].accepted)

    def test_garbage_player_index_and_stroke_are_ignored(self):
        s = state()
        s.execute(stroke_command(5, shape_stroke("slash")))
        s.execute(stroke_command(-1, shape_stroke("slash")))
        s.execute(AttackKeyCommand(9, "slash"))
        s.execute(stroke_command(0, [None, "x", (1,)]))
        s.execute(object())
        run(s, 0.5)

    def test_second_player_attack_key_uses_same_rules(self):
        s = state()
        _, red = s.fighters
        s.execute(AttackKeyCommand(1, "thrust"))
        self.assertEqual(red.attack.spec.name, "thrust")
        self.assertEqual(red.attack.spec.tier, "medium")
        self.assertEqual(red.attack.spec.damage, resolve_attack("thrust").damage)

    def test_both_players_have_identical_base_abilities(self):
        s = state()
        blue, red = s.fighters
        s.execute(AttackKeyCommand(0, "slash"))
        s.execute(AttackKeyCommand(1, "slash"))
        self.assertEqual(blue.attack.spec, red.attack.spec)
        self.assertEqual((blue.max_hp, blue.speed), (red.max_hp, red.speed))

    def test_reset_restores_the_round(self):
        s = state()
        blue, red = s.fighters
        s.execute(AttackKeyCommand(0, "slash"))
        run(s, 0.5)
        self.assertLess(red.hp, red.max_hp)
        s.execute(ResetCommand())
        self.assertEqual([f.hp for f in s.fighters], [100.0, 100.0])
        self.assertTrue(all(f.state is S.IDLE and f.attack is None for f in s.fighters))
        self.assertEqual(s.effects.sparks, [])
        self.assertLess(s.fighters[0].x, s.arena.center_x)
        self.assertEqual(s.combat.fighters, s.fighters)


class MouseToAttackTests(unittest.TestCase):
    """Полная цепочка: события мыши -> запись -> распознавание -> атака."""

    def make(self):
        ci = CommandInput(fake_pygame(), recorder=GestureRecorder())
        return state(command_input=ci), ci

    def draw_with_mouse(self, s, points_xy, seconds):
        steps = len(points_xy) - 1
        dt = seconds / steps
        s.handle_event(down(*points_xy[0]))
        for p in points_xy[1:-1]:
            s.update(dt)
            s.handle_event(move(*p))
        s.update(dt)
        s.handle_event(up(*points_xy[-1]))

    def test_mouse_slash_launches_attack(self):
        s, _ = self.make()
        xy = [(300 + i * 12, 500 - i * 12) for i in range(21)]      # `/`
        self.draw_with_mouse(s, xy, 0.4)
        self.assertEqual(s.fighters[0].state, S.WINDUP)
        self.assertEqual(s.fighters[0].attack.spec.name, "slash")

    def test_mouse_vertical_line_in_other_screen_corner_launches_thrust(self):
        s, _ = self.make()
        xy = [(1150, 100 + i * 15) for i in range(16)]
        self.draw_with_mouse(s, xy, 0.35)
        self.assertEqual(s.fighters[0].attack.spec.name, "thrust")

    def test_short_click_does_not_attack(self):
        s, _ = self.make()
        s.handle_event(down(400, 400))
        s.update(0.05)
        s.handle_event(up(401, 401))
        self.assertEqual(s.fighters[0].state, S.IDLE)

    def test_trail_is_available_only_while_drawing(self):
        s, _ = self.make()
        self.assertEqual(s.trail, [])
        s.handle_event(down(100, 100))
        s.update(0.02)
        s.handle_event(move(150, 150))
        self.assertEqual(len(s.trail), 2)
        s.update(0.02)
        s.handle_event(up(200, 200))
        self.assertEqual(s.trail, [])

    def test_state_without_command_input_ignores_events(self):
        s = state()
        s.handle_event(down(1, 1))
        s.handle_event(types.SimpleNamespace(type=123))


class DrawTests(unittest.TestCase):
    def test_draw_calls_scene_renderer_then_combat_view(self):
        order = []

        class R:
            def draw(self, surface, arena, fighters, alpha):
                order.append("scene")

        class V:
            def draw(self, surface, scene, alpha):
                order.append(("view", scene))

        s = state(renderer=R(), combat_view=V())
        s.draw(object(), 0.5)
        self.assertEqual(order, ["scene", ("view", s)])

    def test_combat_view_alone_is_enough(self):
        seen = []
        s = state(combat_view=types.SimpleNamespace(draw=lambda *a: seen.append(a)))
        s.draw("surface", 0.25)
        self.assertEqual(len(seen), 1)

    def test_hit_creates_spark_effect_at_target(self):
        s = state()
        s.execute(AttackKeyCommand(0, "slash"))
        for _ in range(60):
            s.update(1 / 60)
            if s.effects.sparks:
                break
        self.assertEqual(len(s.effects.sparks), 1)


class FrameRateSimulationTests(unittest.TestCase):
    """Один и тот же бой, разбитый на кадры по-разному (30...240 FPS)."""

    def scenario(self, fps, seconds=2.0):
        s = state()
        blue, red = s.fighters
        s.execute(AttackKeyCommand(0, "slash"))
        loop = FixedStepLoop(settings.LOGIC_TICKS_PER_SECOND, settings.MAX_FRAME_TIME)
        hit_time = None
        for _ in range(int(round(seconds * fps))):
            loop.advance(1.0 / fps, s.update)
            if hit_time is None and red.hp < red.max_hp:
                hit_time = s.time
        return red.hp, red.x, hit_time, blue.state, red.state

    def test_same_result_at_all_frame_rates(self):
        baseline = self.scenario(60)
        spec = resolve_attack("slash")
        for fps in (30, 45, 60, 90, 144, 240):
            hp, x, hit_time, blue_state, red_state = self.scenario(fps)
            self.assertAlmostEqual(hp, baseline[0], msg=str(fps))
            self.assertAlmostEqual(x, baseline[1], delta=0.5, msg=str(fps))
            self.assertEqual((blue_state, red_state), (baseline[3], baseline[4]), msg=str(fps))
            self.assertAlmostEqual(hit_time, baseline[2], delta=1 / 60 + 1e-9, msg=str(fps))
            self.assertGreaterEqual(hit_time, spec.windup - 1e-9)

    def test_combo_timing_is_frame_rate_independent(self):
        outcomes = set()
        for fps in (30, 60, 144):
            s = state()
            blue, _ = s.fighters
            s.execute(AttackKeyCommand(0, "slash"))
            loop = FixedStepLoop(settings.LOGIC_TICKS_PER_SECOND, settings.MAX_FRAME_TIME)
            chained = False
            for _ in range(int(round(3.0 * fps))):
                loop.advance(1.0 / fps, s.update)
                if not chained and blue.state is S.RECOVERY and blue.combo.window_open(s.time):
                    s.execute(AttackKeyCommand(0, "sweep"))
                    chained = blue.combo.history == ["slash", "sweep"]
            outcomes.add(chained)
        self.assertEqual(outcomes, {True})

    def test_long_frame_does_not_skip_the_attack_phases(self):
        s = state()
        blue, red = s.fighters
        s.execute(AttackKeyCommand(0, "slash"))
        loop = FixedStepLoop(settings.LOGIC_TICKS_PER_SECOND, settings.MAX_FRAME_TIME)
        loop.advance(0.25, s.update)             # один лагающий кадр в 250 мс
        self.assertLess(red.hp, red.max_hp)      # попадание не пропущено
        self.assertEqual(red.max_hp - red.hp, resolve_attack("slash").damage)


if __name__ == "__main__":
    unittest.main()
