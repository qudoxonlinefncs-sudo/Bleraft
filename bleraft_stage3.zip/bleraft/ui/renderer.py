"""Отрисовка сцены. Модуль pygame передаётся снаружи (удобно для тестов).

Тяжёлые слои (пол арены, спрайты, тень) строятся один раз и кэшируются.
"""

import settings
from ui import palette, sprites


class SceneRenderer:
    def __init__(self, pygame):
        self._pg = pygame
        self._arena_key = None
        self._arena_layer = None
        self._sprites = {}
        self._shadow = None

    # --- кэшируемые слои ---

    def _build_arena_layer(self, arena):
        pg = self._pg
        frame = settings.ARENA_FRAME
        tile = settings.ARENA_TILE_SIZE
        width, height = int(arena.width), int(arena.height)
        total_w, total_h = width + 2 * frame, height + 2 * frame

        layer = pg.Surface((total_w, total_h))
        layer.fill(palette.FRAME_OUTER)
        pg.draw.rect(layer, palette.FRAME_INNER, (2, 2, total_w - 4, total_h - 4))

        for row in range(0, height, tile):
            for col in range(0, width, tile):
                color = palette.FLOOR_A if ((row + col) // tile) % 2 == 0 else palette.FLOOR_B
                pg.draw.rect(
                    layer, color,
                    (frame + col, frame + row, min(tile, width - col), min(tile, height - row)),
                )

        pg.draw.rect(layer, palette.CENTER_LINE, (frame + width // 2 - 1, frame, 2, height))
        pg.draw.rect(layer, palette.FRAME_HIGHLIGHT, (frame - 1, frame - 1, width + 2, height + 2), 1)
        return layer

    def _get_arena_layer(self, arena):
        key = (arena.left, arena.top, arena.width, arena.height)
        if key != self._arena_key:
            self._arena_layer = self._build_arena_layer(arena)
            self._arena_key = key
        return self._arena_layer

    def _get_sprite(self, team):
        if team not in self._sprites:
            self._sprites[team] = sprites.build_fighter_sprite(
                self._pg, team, settings.SPRITE_SCALE
            )
        return self._sprites[team]

    def _get_shadow(self):
        if self._shadow is None:
            pg = self._pg
            width, height = settings.PLAYER_SIZE, settings.PLAYER_SIZE // 3
            self._shadow = pg.Surface((width, height), pg.SRCALPHA)
            pg.draw.ellipse(self._shadow, palette.SHADOW, (0, 0, width, height))
        return self._shadow

    # --- кадр ---

    def draw(self, surface, arena, fighters, alpha):
        surface.fill(settings.BACKGROUND_COLOR)

        frame = settings.ARENA_FRAME
        surface.blit(
            self._get_arena_layer(arena),
            (int(arena.left) - frame, int(arena.top) - frame),
        )

        shadow = self._get_shadow()
        # нижние (по экрану) персонажи рисуются поверх верхних
        for fighter in sorted(fighters, key=lambda f: f.y):
            rx, ry = fighter.render_position(alpha)
            half_w, half_h = fighter.width // 2, fighter.height // 2
            surface.blit(shadow, (round(rx) - half_w, round(ry) + half_h - shadow.get_height() // 2))
            surface.blit(self._get_sprite(fighter.team), (round(rx) - half_w, round(ry) - half_h))
