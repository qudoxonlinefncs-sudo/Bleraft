"""Короткоживущие визуальные эффекты (логика, без Pygame)."""

from dataclasses import dataclass


@dataclass
class HitSpark:
    x: float
    y: float
    big: bool            # завершающая атака комбо рисуется крупнее
    age: float = 0.0
    life: float = 0.28


@dataclass
class GestureIndicator:
    player_index: int
    gesture: str         # имя жеста или None (не распознан)
    tier: str            # fast / medium / slow или None
    accepted: bool       # запущена ли атака
    age: float = 0.0
    life: float = 0.8


class Effects:
    def __init__(self):
        self.sparks = []
        self.indicators = {}     # player_index -> GestureIndicator

    def add_hit(self, x, y, big=False):
        self.sparks.append(HitSpark(x, y, big))

    def set_indicator(self, player_index, gesture, tier, accepted):
        self.indicators[player_index] = GestureIndicator(player_index, gesture, tier, accepted)

    def clear(self):
        self.sparks = []
        self.indicators = {}

    def update(self, dt):
        for spark in self.sparks:
            spark.age += dt
        self.sparks = [s for s in self.sparks if s.age < s.life]
        for ind in self.indicators.values():
            ind.age += dt
        self.indicators = {k: v for k, v in self.indicators.items() if v.age < v.life}
