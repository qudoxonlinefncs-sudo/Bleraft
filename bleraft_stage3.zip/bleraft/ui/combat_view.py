"""Отрисовка боя: зоны атак, взгляд, вспышки, здоровье, след и значок жеста.

Модуль pygame передаётся снаружи. Используются только простые формы
(polygon, line, circle, rect) - без прозрачности и тяжёлых поверхностей,
чтобы кадр оставался дешёвым на слабых компьютерах.
"""

import settings
from combat.hitbox import attack_hitbox
from entities.fighter import FighterState
from input.gesture_templates import DEFAULT_TEMPLATES
from ui import palette, sprites

HP_BAR_WIDTH = 360
HP_BAR_HEIGHT = 18
HP_BAR_Y = 34
ICON_BOX = 44
ICON_SIZE = 26
TIER_SEGMENTS = {"fast": 1, "medium": 2, "slow": 3}


def _pts(points):
    return [(int(round(x)), int(round(y))) for x, y in points]


class CombatView:
    def __init__(self, pygame, templates=DEFAULT_TEMPLATES):
        self._pg = pygame
        self._icons = {t.name: t.points for t in templates}
        self._flash = None

    def draw(self, surface, scene, alpha):
        self._draw_attacks(surface, scene.fighters, alpha)
        self._draw_flash(surface, scene.fighters, alpha)
        self._draw_sparks(surface, scene.effects.sparks)
        self._draw_hp(surface, scene)
        self._draw_indicators(surface, scene)
        self._draw_trail(surface, scene.trail)

    # ---------- бойцы ----------

    def _draw_attacks(self, surface, fighters, alpha):
        pg = self._pg
        for f in fighters:
            if not f.alive:
                continue
            rx, ry = f.render_position(alpha)
            colors = palette.ATTACK_COLORS[f.team]
            atk = f.attack
            if atk is not None:
                spec = atk.spec
                thick = 3 if spec.is_finisher else 1
                full = attack_hitbox(rx, ry, atk.facing, spec)
                if atk.phase is FighterState.WINDUP:
                    # зона удара обозначена контуром, внутри "заряжается" клинок
                    pg.draw.polygon(surface, colors["dim"], _pts(full.corners()), 1)
                    part = attack_hitbox(rx, ry, atk.facing, spec, max(atk.progress, 0.08))
                    pg.draw.polygon(surface, colors["main"], _pts(part.corners()))
                elif atk.phase is FighterState.ACTIVE:
                    fill = colors["bright"] if atk.in_hit_window() else colors["main"]
                    pg.draw.polygon(surface, fill, _pts(full.corners()))
                    pg.draw.polygon(surface, colors["bright"], _pts(full.corners()), thick + 1)
                else:  # восстановление: слабый контур, боец уязвим
                    pg.draw.polygon(surface, colors["dim"], _pts(full.corners()), thick)
            # указатель взгляда
            fx, fy = f.facing
            tip = (int(round(rx + fx * 28)), int(round(ry + fy * 28)))
            pg.draw.line(surface, colors["bright"], (int(round(rx)), int(round(ry))), tip, 2)
            pg.draw.circle(surface, colors["bright"], tip, 3)

    def _flash_sprite(self):
        if self._flash is None:
            self._flash = sprites.build_fighter_sprite(self._pg, "flash", settings.SPRITE_SCALE)
        return self._flash

    def _draw_flash(self, surface, fighters, alpha):
        for f in fighters:
            if f.hit_flash > 0.0:
                rx, ry = f.render_position(alpha)
                half = settings.PLAYER_SIZE // 2
                surface.blit(self._flash_sprite(), (round(rx) - half, round(ry) - half))

    def _draw_sparks(self, surface, sparks):
        pg = self._pg
        for s in sparks:
            progress = s.age / s.life
            radius = int(6 + progress * (36 if s.big else 22))
            center = (int(round(s.x)), int(round(s.y)))
            pg.draw.circle(surface, palette.SPARK, center, radius, 2)
            inner, outer = int(radius * 0.55), radius
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                pg.draw.line(
                    surface, palette.SPARK,
                    (center[0] + dx * inner, center[1] + dy * inner),
                    (center[0] + dx * outer, center[1] + dy * outer), 2)

    # ---------- интерфейс ----------

    def _bar_x(self, scene, index):
        if index == 0:
            return int(scene.arena.left)
        return int(scene.arena.right) - HP_BAR_WIDTH

    def _draw_hp(self, surface, scene):
        pg = self._pg
        for index, f in enumerate(scene.fighters):
            x, y = self._bar_x(scene, index), HP_BAR_Y
            pg.draw.rect(surface, palette.HP_BACK, (x, y, HP_BAR_WIDTH, HP_BAR_HEIGHT))
            filled = int(round(HP_BAR_WIDTH * max(0.0, f.hp) / f.max_hp))
            if filled > 0:
                fx = x if index == 0 else x + HP_BAR_WIDTH - filled
                pg.draw.rect(surface, palette.HP_FILL[f.team], (fx, y, filled, HP_BAR_HEIGHT))
            for i in range(1, 10):  # деления по 10%
                tx = x + HP_BAR_WIDTH * i // 10
                pg.draw.line(surface, palette.HP_TICK, (tx, y), (tx, y + HP_BAR_HEIGHT - 1), 1)
            pg.draw.rect(surface, palette.HP_BORDER, (x, y, HP_BAR_WIDTH, HP_BAR_HEIGHT), 2)

    def _icon_points(self, name, cx, cy):
        pts = self._icons[name]
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        size = max(max(xs) - min(xs), max(ys) - min(ys)) or 1.0
        mx, my = (max(xs) + min(xs)) / 2, (max(ys) + min(ys)) / 2
        k = ICON_SIZE / size
        return _pts([(cx + (x - mx) * k, cy + (y - my) * k) for x, y in pts])

    def _draw_indicators(self, surface, scene):
        pg = self._pg
        for index, ind in scene.effects.indicators.items():
            x = self._bar_x(scene, index) if index == 0 else int(scene.arena.right) - ICON_BOX
            y = HP_BAR_Y + HP_BAR_HEIGHT + 6
            pg.draw.rect(surface, palette.HP_BACK, (x, y, ICON_BOX, ICON_BOX))
            pg.draw.rect(surface, palette.HP_BORDER, (x, y, ICON_BOX, ICON_BOX), 2)
            cx, cy = x + ICON_BOX // 2, y + ICON_BOX // 2 - 3
            if ind.gesture is None:                  # жест не распознан
                r = ICON_SIZE // 2 - 2
                pg.draw.line(surface, palette.REJECTED, (cx - r, cy - r), (cx + r, cy + r), 3)
                pg.draw.line(surface, palette.REJECTED, (cx - r, cy + r), (cx + r, cy - r), 3)
                continue
            color = palette.TIER_COLORS[ind.tier] if ind.accepted else palette.HP_BORDER
            if ind.gesture in self._icons:
                pg.draw.lines(surface, color, False, self._icon_points(ind.gesture, cx, cy), 3)
            segments = TIER_SEGMENTS[ind.tier]       # больше сегментов - медленнее и сильнее
            for i in range(3):
                seg_color = color if i < segments else palette.HP_TICK
                pg.draw.rect(surface, seg_color, (x + 6 + i * 12, y + ICON_BOX - 8, 10, 4))

    def _draw_trail(self, surface, trail):
        if len(trail) >= 2:
            self._pg.draw.lines(surface, palette.TRAIL, False,
                                [(int(x), int(y)) for x, y, _ in trail], 3)
