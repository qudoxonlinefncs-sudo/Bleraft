"""Игровая сцена: арена, два бойца, жесты и ближний бой."""

import settings
from arena.arena import Arena
from combat.attacks import tier_for_speed
from combat.combat_system import STARTED, CombatSystem
from core.states import State
from entities.fighter import Fighter
from input.commands import AttackKeyCommand, ResetCommand, StrokeCommand
from input.gesture_recognizer import GestureRecognizer
from ui.effects import Effects


def create_fighters(arena):
    """Синий слева, красный справа, оба по центру арены по вертикали."""
    offset = settings.PLAYER_SPAWN_OFFSET
    return [
        Fighter("blue", arena.center_x - offset, arena.center_y,
                settings.PLAYER_SIZE, settings.PLAYER_SPEED),
        Fighter("red", arena.center_x + offset, arena.center_y,
                settings.PLAYER_SIZE, settings.PLAYER_SPEED),
    ]


class GameplayState(State):
    """Логика сцены. Ввод и отрисовка подключаются снаружи.

    input_source.direction(index) -> (dx, dy) - движение игрока index.
    command_input.handle_event(event, now) -> команды (жесты, клавиши атак).
    renderer.draw(surface, arena, fighters, alpha) - арена и бойцы.
    combat_view.draw(surface, scene, alpha) - бой, HUD, след жеста.
    Всё, кроме input_source, необязательно.
    """

    def __init__(self, input_source, renderer=None, arena=None, fighters=None,
                 command_input=None, combat_view=None, recognizer=None):
        super().__init__()
        self.input = input_source
        self.renderer = renderer
        self.command_input = command_input
        self.combat_view = combat_view
        self.recognizer = recognizer if recognizer is not None else GestureRecognizer()
        self.arena = arena if arena is not None else Arena.from_settings()
        self.fighters = (
            fighters if fighters is not None else create_fighters(self.arena)
        )
        self.combat = CombatSystem(self.fighters)
        self.effects = Effects()

    @property
    def time(self):
        return self.combat.time

    @property
    def trail(self):
        """Точки жеста, который рисуется прямо сейчас."""
        if self.command_input is None or not self.command_input.recorder.active:
            return []
        return self.command_input.recorder.points

    # ---------- ввод ----------

    def handle_event(self, event):
        if self.command_input is None:
            return
        for command in self.command_input.handle_event(event, self.time):
            self.execute(command)

    def execute(self, command):
        if isinstance(command, ResetCommand):
            self.reset()
        elif isinstance(command, StrokeCommand):
            self._attack_from_stroke(command)
        elif isinstance(command, AttackKeyCommand):
            if 0 <= command.player_index < len(self.fighters):
                result = self.combat.request_attack(
                    self.fighters[command.player_index], command.gesture, "medium")
                self.effects.set_indicator(
                    command.player_index, command.gesture, "medium", result == STARTED)

    def _attack_from_stroke(self, command):
        index = command.player_index
        if not 0 <= index < len(self.fighters):
            return
        result = self.recognizer.recognize(command.stroke.points)
        if not result.ok:
            self.effects.set_indicator(index, None, None, False)
            return  # неизвестный жест атаку не запускает
        tier = tier_for_speed(result.speed)
        started = self.combat.request_attack(self.fighters[index], result.name, tier)
        self.effects.set_indicator(index, result.name, tier, started == STARTED)

    def reset(self):
        self.fighters[:] = create_fighters(self.arena)
        self.effects.clear()
        if self.command_input is not None:
            self.command_input.recorder.cancel()

    # ---------- логика и отрисовка ----------

    def update(self, dt):
        self.combat.update(dt)
        for event in self.combat.events:
            self.effects.add_hit(event.x, event.y, event.finisher)
        for index, fighter in enumerate(self.fighters):
            fighter.update(dt, self.input.direction(index), self.arena.bounds)
        self.effects.update(dt)

    def draw(self, surface, alpha):
        if self.renderer is not None:
            self.renderer.draw(surface, self.arena, self.fighters, alpha)
        if self.combat_view is not None:
            self.combat_view.draw(surface, self, alpha)
