"""Шаблоны жестов (данные). Чистая логика, без Pygame.

Чтобы добавить новый жест, достаточно добавить GestureTemplate в
DEFAULT_TEMPLATES (и атаку с тем же именем в combat/attacks.py).
Распознаватель менять не нужно.

Точки шаблона - ключевые точки полилинии в любом масштабе; ось Y направлена
вниз, как на экране. Масштаб, положение и число точек не важны.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class GestureTemplate:
    name: str                 # ключ жеста (совпадает с ключом атаки)
    points: tuple             # ключевые точки (x, y)
    symbol: str               # как жест выглядит для игрока
    allow_reverse: bool = True  # можно рисовать в обратном направлении


DEFAULT_TEMPLATES = (
    GestureTemplate("slash", ((0.0, 1.0), (1.0, 0.0)), "/"),
    GestureTemplate("sweep", ((0.0, 0.0), (1.0, 0.0)), "-"),
    GestureTemplate("thrust", ((0.0, 0.0), (0.0, 1.0)), "|"),
    GestureTemplate("double", ((0.0, 0.0), (0.5, 1.0), (1.0, 0.0)), "V"),
)
