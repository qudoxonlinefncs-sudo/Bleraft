"""Распознавание жестов по шаблонам (в духе $1 Recognizer). Без Pygame.

Шаги: ресемплинг в N равноудалённых точек -> перенос центра масс в ноль ->
равномерное масштабирование по большей стороне -> среднее расстояние до
каждого шаблона. Поворот НЕ нормализуется: `/`, `-` и `|` - разные жесты.
Масштабирование равномерное, поэтому прямые линии остаются линиями.
"""

import math
from dataclasses import dataclass

import settings
from input.gesture_templates import DEFAULT_TEMPLATES

_EPS = 1e-9


@dataclass(frozen=True)
class Recognition:
    name: str            # имя жеста или None, если не распознан
    reason: str          # "ok", "invalid", "too_few_points", "too_short",
                         # "too_quick", "no_match", "ambiguous"
    distance: float      # расстояние до лучшего шаблона (меньше - точнее)
    margin: float        # отрыв лучшего шаблона от второго
    length: float        # длина пути, пиксели
    duration: float      # секунды
    speed: float         # доля опорного размера в секунду

    @property
    def ok(self):
        return self.name is not None


def path_length(points):
    return sum(
        math.hypot(x1 - x0, y1 - y0)
        for (x0, y0), (x1, y1) in zip(points, points[1:])
    )


def resample(points, count):
    """count равноудалённых по длине пути точек. None, если путь нулевой."""
    total = path_length(points)
    if total < _EPS or count < 2:
        return None
    step = total / (count - 1)
    result = [points[0]]
    accumulated = 0.0
    pts = list(points)
    i = 1
    while i < len(pts):
        (x0, y0), (x1, y1) = pts[i - 1], pts[i]
        segment = math.hypot(x1 - x0, y1 - y0)
        if segment > _EPS and accumulated + segment >= step:
            ratio = (step - accumulated) / segment
            point = (x0 + ratio * (x1 - x0), y0 + ratio * (y1 - y0))
            result.append(point)
            pts.insert(i, point)  # продолжаем с новой точки
            accumulated = 0.0
        else:
            accumulated += segment
        i += 1
    while len(result) < count:  # накопленная погрешность float
        result.append(pts[-1])
    return result[:count]


def normalize_path(points, count):
    """Путь -> count точек с центром в нуле и большей стороной рамки = 1.

    Возвращает None для вырожденного пути (все точки в одном месте).
    """
    sampled = resample(points, count)
    if sampled is None:
        return None
    cx = sum(p[0] for p in sampled) / len(sampled)
    cy = sum(p[1] for p in sampled) / len(sampled)
    shifted = [(x - cx, y - cy) for x, y in sampled]
    xs = [p[0] for p in shifted]
    ys = [p[1] for p in shifted]
    size = max(max(xs) - min(xs), max(ys) - min(ys))
    if size < _EPS:
        return None
    return [(x / size, y / size) for x, y in shifted]


def mean_distance(a, b):
    return sum(math.hypot(p[0] - q[0], p[1] - q[1]) for p, q in zip(a, b)) / len(a)


class GestureRecognizer:
    def __init__(
        self,
        templates=DEFAULT_TEMPLATES,
        reference_size=None,
        resample_points=None,
        min_points=None,
        min_length_ratio=None,
        min_duration=None,
        max_distance=None,
        min_margin=None,
    ):
        s = settings
        self.reference_size = s.GESTURE_REFERENCE_SIZE if reference_size is None else reference_size
        self.count = s.GESTURE_RESAMPLE_POINTS if resample_points is None else resample_points
        self.min_points = s.GESTURE_MIN_POINTS if min_points is None else min_points
        self.min_length_ratio = s.GESTURE_MIN_LENGTH_RATIO if min_length_ratio is None else min_length_ratio
        self.min_duration = s.GESTURE_MIN_DURATION if min_duration is None else min_duration
        self.max_distance = s.GESTURE_MAX_DISTANCE if max_distance is None else max_distance
        self.min_margin = s.GESTURE_MIN_MARGIN if min_margin is None else min_margin
        self._variants = []  # (имя, нормализованные точки)
        for template in templates:
            self.add_template(template)

    def add_template(self, template):
        """Добавляет жест без изменения самого распознавателя."""
        pts = normalize_path(template.points, self.count)
        if pts is None:
            raise ValueError("Шаблон %r вырожден" % template.name)
        self._variants.append((template.name, pts))
        if template.allow_reverse:
            self._variants.append((template.name, pts[::-1]))

    def _result(self, name, reason, distance=0.0, margin=0.0, length=0.0, duration=0.0):
        speed = 0.0
        if duration > 0:
            speed = length / self.reference_size / duration
        return Recognition(name, reason, distance, margin, length, duration, speed)

    def recognize(self, points):
        """points - последовательность (x, y, t). Никогда не бросает исключений."""
        clean = []
        try:
            for p in points:
                x, y, t = float(p[0]), float(p[1]), float(p[2])
                if math.isfinite(x) and math.isfinite(y) and math.isfinite(t):
                    clean.append((x, y, t))
        except (TypeError, ValueError, IndexError):
            return self._result(None, "invalid")
        if not clean:
            return self._result(None, "invalid")

        xy = [(x, y) for x, y, _ in clean]
        length = path_length(xy)
        duration = clean[-1][2] - clean[0][2]
        if not (math.isfinite(length) and math.isfinite(duration)):
            return self._result(None, "invalid")  # абсурдные координаты
        info = dict(length=length, duration=max(duration, 0.0))

        if len(clean) < self.min_points:
            return self._result(None, "too_few_points", **info)
        if length < self.min_length_ratio * self.reference_size:
            return self._result(None, "too_short", **info)
        if duration < self.min_duration:
            return self._result(None, "too_quick", **info)

        path = normalize_path(xy, self.count)
        if path is None:
            return self._result(None, "too_short", **info)

        best = {}  # имя -> лучшее расстояние (с учётом обратного направления)
        for name, template in self._variants:
            d = mean_distance(path, template)
            if name not in best or d < best[name]:
                best[name] = d
        ranked = sorted(best.items(), key=lambda item: item[1])
        best_name, best_distance = ranked[0]
        if not math.isfinite(best_distance):
            return self._result(None, "invalid", **info)
        margin = (ranked[1][1] - best_distance) if len(ranked) > 1 else float("inf")

        if best_distance > self.max_distance:
            return self._result(None, "no_match", best_distance, margin, **info)
        if margin < self.min_margin:
            return self._result(None, "ambiguous", best_distance, margin, **info)
        return self._result(best_name, "ok", best_distance, margin, **info)
