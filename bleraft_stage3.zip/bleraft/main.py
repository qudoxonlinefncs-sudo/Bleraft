"""Точка входа Bleraft: python main.py"""

import sys


def main():
    try:
        import pygame
    except ImportError:
        print("Pygame не установлен. Выполните: pip install -r requirements.txt")
        return 1

    from core.game import Game
    from core.gameplay import GameplayState
    from input.command_input import CommandInput
    from input.keyboard import KeyboardInput
    from ui.combat_view import CombatView
    from ui.renderer import SceneRenderer

    state = GameplayState(
        KeyboardInput(pygame),
        SceneRenderer(pygame),
        command_input=CommandInput(pygame),
        combat_view=CombatView(pygame),
    )
    Game(initial_state=state).run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
