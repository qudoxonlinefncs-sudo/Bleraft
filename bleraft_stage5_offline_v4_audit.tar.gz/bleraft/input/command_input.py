"""Преобразование событий pygame в команды.

Мышь рисует жесты. Q/E/R — модификаторы (удерживаются во время жеста).
F — блок. Z/X/C/V в PvE отключены (не управляют ботом).
Назначения клавиш приходят из Profile через set_bindings().
"""

from input.commands import AttackKeyCommand, ResetCommand, SpecialCommand, StrokeCommand
from input.gesture_recorder import GestureRecorder
from combat.specials import SPECIAL_GESTURE_WINDOW


def default_modifier_keys(pygame):
    def key(name, fallback):
        return getattr(pygame, name, fallback)
    return {
        key("K_q", ord("q")): "crush",
        key("K_e", ord("e")): "launch",
        key("K_r", ord("r")): "drain",
    }


def default_block_key(pygame):
    return getattr(pygame, "K_f", ord("f"))


class CommandInput:
    def __init__(self, pygame, recorder=None, mouse_player=0,
                 modifier_keys=None, block_key=None, attack_keys=None,
                 enable_keyboard_attacks=False):
        self._pg = pygame
        self.recorder = recorder if recorder is not None else GestureRecorder()
        self.mouse_player = mouse_player
        self.modifier_keys = modifier_keys if modifier_keys is not None else default_modifier_keys(pygame)
        self.block_key = block_key if block_key is not None else default_block_key(pygame)
        # PvE: keyboard attacks OFF so Z/X/C/V never control the bot
        self.attack_keys = attack_keys if enable_keyboard_attacks else {}
        self.enable_keyboard_attacks = enable_keyboard_attacks
        self._held_modifiers = set()
        self._modifier_started_at = {}
        self._event_time = 0.0
        # actual key labels for HUD (updated by set_bindings)
        self.key_labels = {"crush": "Q", "launch": "E", "drain": "R", "block": "F"}

    def set_bindings(self, pygame, profile_bindings):
        """Применить переназначенные клавиши из Profile.

        profile_bindings: dict вроде p1_special_crush -> keycode
        """
        mapping = {
            "p1_special_crush": "crush",
            "p1_special_launch": "launch",
            "p1_special_drain": "drain",
            "p1_block": "block",
        }
        mods = {}
        block = self.block_key
        labels = dict(self.key_labels)
        for bind_name, action in mapping.items():
            code = profile_bindings.get(bind_name)
            if code is None:
                continue
            if action == "block":
                block = code
            else:
                mods[code] = action
            labels[action] = _key_name(pygame, code)
        if mods:
            self.modifier_keys = mods
        self.block_key = block
        self.key_labels = labels

    @property
    def active_modifier(self):
        """Активный Q/E/R, только пока не истекло окно подготовки."""
        info = self.pending_modifier_info(self._event_time)
        return info[0] if info is not None else None

    def active_modifier_at(self, now):
        """То же, но с явным временем (для тестов и внешнего использования)."""
        info = self.pending_modifier_info(now)
        return info[0] if info is not None else None

    def pending_modifier_info(self, now):
        """Возвращает (эффект, оставшееся время) для HUD или None.

        Отсчёт начинается в момент KEYDOWN, а не при начале рисования.
        """
        held = [n for n in ("crush", "launch", "drain") if n in self._held_modifiers]
        if len(held) != 1:
            return None
        name = held[0]
        started = self._modifier_started_at.get(name)
        if started is None:
            return None
        remaining = SPECIAL_GESTURE_WINDOW - max(0.0, float(now) - started)
        if remaining <= 0.0:
            return None
        return name, remaining

    @property
    def modifier_conflict(self):
        return sum(1 for n in ("crush", "launch", "drain") if n in self._held_modifiers) > 1

    def handle_event(self, event, now):
        self._event_time = float(now)
        pg, rec = self._pg, self.recorder
        kind = event.type

        if kind == getattr(pg, "KEYDOWN", -2):
            mod = self.modifier_keys.get(event.key)
            if mod is not None:
                if mod not in self._held_modifiers:
                    self._held_modifiers.add(mod)
                    self._modifier_started_at[mod] = float(now)
                return []  # alone does nothing; preparation timer starts now
            if event.key == getattr(pg, "K_F5", 1073741920):
                return [ResetCommand()]
            if event.key == self.block_key:
                return [SpecialCommand(self.mouse_player, "block")]
            if self.enable_keyboard_attacks:
                for player, keys in self.attack_keys.items():
                    gesture = keys.get(event.key)
                    if gesture is not None:
                        return [AttackKeyCommand(player, gesture, self.active_modifier)]
            return []

        if kind == getattr(pg, "KEYUP", -1):
            mod = self.modifier_keys.get(event.key)
            if mod is not None:
                self._held_modifiers.discard(mod)
                self._modifier_started_at.pop(mod, None)
            return []

        if kind == pg.MOUSEBUTTONDOWN and event.button == 1:
            rec.begin(event.pos[0], event.pos[1], now)
            return []

        if kind == pg.MOUSEMOTION and rec.active:
            if not event.buttons[0]:
                return self._finish(event.pos, now)
            rec.add_point(event.pos[0], event.pos[1], now)
            return []

        if kind == pg.MOUSEBUTTONUP and event.button == 1:
            return self._finish(event.pos, now)

        return []

    def _finish(self, pos, now):
        stroke = self.recorder.end(pos[0], pos[1], now)
        if stroke is None:
            return []
        if self.modifier_conflict:
            # conflicting Q+E etc. → no modifier, scene can show notice
            return [StrokeCommand(self.mouse_player, stroke, None)]
        return [StrokeCommand(self.mouse_player, stroke, self.active_modifier_at(now))]


def _key_name(pygame, code):
    for name in dir(pygame):
        if name.startswith("K_") and getattr(pygame, name, None) == code:
            return name[2:].upper()
    return "?"
