"""Команды, которые ввод передаёт игровой сцене. Чистые данные."""

from dataclasses import dataclass


@dataclass(frozen=True)
class StrokeCommand:
    player_index: int
    stroke: object          # input.gesture_recorder.Stroke
    modifier: str = None    # crush / launch / drain или None


@dataclass(frozen=True)
class AttackKeyCommand:
    """Атака клавишей (временная замена жеста для игрока без мыши)."""
    player_index: int
    gesture: str
    modifier: str = None


@dataclass(frozen=True)
class ResetCommand:
    """Начать раунд заново."""


@dataclass(frozen=True)
class SpecialCommand:
    """Только блок (F). Q/E/R — модификаторы жеста, не отдельные команды атаки."""
    player_index: int
    action: str          # только "block"
