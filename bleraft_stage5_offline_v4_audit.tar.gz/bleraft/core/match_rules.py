"""Правила матча и статистика. Чистая логика, без Pygame.

Stage 5:
  - у каждого бойца PLAYER_LIVES жизней по MAX_HP;
  - KO или Ring Out отнимает одну жизнь;
  - при оставшихся жизнях возрождение через RESPAWN_TIME;
  - победа: все противники полностью выбыли (lives == 0);
  - если все участники обеих сторон выбывают в одном тике — DRAW;
  - по истечении времени без победителя — TIME UP (без сравнения HP/урона).
"""

from dataclasses import dataclass, field

import settings

VICTORY = "victory"
DEFEAT = "defeat"
DRAW = "draw"
KO = "ko"
RING_OUT = "ring_out"
TIMEOUT = "timeout"
TIME_UP = "time_up"


@dataclass
class MatchStats:
    damage_dealt: float = 0.0
    damage_taken: float = 0.0
    hits_landed: int = 0
    hits_taken: int = 0
    gestures_ok: int = 0
    gestures_failed: int = 0
    max_combo: int = 0
    lives_lost: int = 0
    ring_outs: int = 0

    def as_dict(self):
        return dict(self.__dict__)


@dataclass(frozen=True)
class MatchResult:
    outcome: str            # victory / defeat / draw
    reason: str             # ko / ring_out / timeout / time_up
    duration: float         # секунды игрового времени
    player_hp: float
    enemy_hp: float
    player_lives: int = 0
    enemy_lives: int = 0
    stats: dict = field(default_factory=dict)


class MatchRules:
    def __init__(self, player_index=0, time_limit=None, team_mode=False):
        self.player_index = player_index
        self.time_limit = time_limit     # None — без ограничения (тренировка)
        self.team_mode = team_mode       # True для 2v2

    def _result(self, outcome, reason, scene):
        fighters = scene.fighters
        me = fighters[self.player_index]
        if self.team_mode:
            my_team = me.team
            enemies = [f for f in fighters if f.team != my_team]
            allies = [f for f in fighters if f.team == my_team]
            enemy_hp = sum(e.hp for e in enemies) / max(1, len(enemies))
            enemy_lives = sum(max(0, e.lives) for e in enemies)
            player_lives = sum(max(0, a.lives) for a in allies)
        else:
            enemies = [f for i, f in enumerate(fighters) if i != self.player_index]
            enemy_hp = sum(e.hp for e in enemies) / max(1, len(enemies)) if enemies else 0.0
            enemy_lives = sum(max(0, e.lives) for e in enemies)
            player_lives = me.lives
        return MatchResult(
            outcome, reason, scene.time, me.hp, enemy_hp,
            player_lives=player_lives, enemy_lives=enemy_lives,
            stats=scene.stats.as_dict(),
        )

    def evaluate(self, scene):
        """MatchResult, если матч закончился, иначе None."""
        fighters = scene.fighters
        me = fighters[self.player_index]

        if self.team_mode:
            my_team = me.team
            allies = [f for f in fighters if f.team == my_team]
            enemies = [f for f in fighters if f.team != my_team]
            allies_out = all(f.eliminated for f in allies)
            enemies_out = all(f.eliminated for f in enemies) if enemies else False
            if allies_out and enemies_out:
                return self._result(DRAW, KO, scene)
            if enemies_out:
                return self._result(VICTORY, KO, scene)
            if allies_out:
                return self._result(DEFEAT, KO, scene)
        else:
            enemies = [f for i, f in enumerate(fighters) if i != self.player_index]
            me_out = me.eliminated
            enemies_out = all(e.eliminated for e in enemies) if enemies else False
            if me_out and enemies_out:
                return self._result(DRAW, KO, scene)
            if enemies_out:
                dead = next((e for e in enemies if e.ring_out), enemies[0] if enemies else me)
                reason = RING_OUT if getattr(dead, "ring_out", False) else KO
                return self._result(VICTORY, reason, scene)
            if me_out:
                reason = RING_OUT if me.ring_out else KO
                return self._result(DEFEAT, reason, scene)

        # TIME UP: время вышло, победителя нет — без сравнения HP/урона
        if self.time_limit is not None and scene.time >= self.time_limit:
            return self._result(TIME_UP, TIME_UP, scene)
        return None
