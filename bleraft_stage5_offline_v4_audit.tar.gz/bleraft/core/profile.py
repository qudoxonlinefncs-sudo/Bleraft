"""Профиль игрока: настройки и статистика матчей (JSON-файлы). Без Pygame.

Файлы хранятся в ~/.bleraft (или в указанной папке). Повреждённый или
недоступный файл не ломает игру: используются значения по умолчанию.
"""

import json
import os
import time

from input.controls import ControlScheme

ACTIONS = ("up", "down", "left", "right")
SPECIAL_ACTIONS = ("special_crush", "special_launch", "special_drain", "block")
ALL_ACTIONS = ACTIONS + SPECIAL_ACTIONS
MAX_MATCHES = 200


def default_dir():
    return os.path.join(os.path.expanduser("~"), ".bleraft")


class Storage:
    def __init__(self, directory=None):
        self.directory = directory or default_dir()

    def _path(self, name):
        return os.path.join(self.directory, name)

    def load(self, name, default):
        try:
            with open(self._path(name), "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, type(default)) else default
        except (OSError, ValueError):
            return default

    def save(self, name, data):
        """Атомарная запись. Возвращает True при успехе."""
        try:
            os.makedirs(self.directory, exist_ok=True)
            tmp = self._path(name + ".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self._path(name))
            return True
        except OSError:
            return False


def default_bindings(pygame):
    return {
        "p1_up": pygame.K_w, "p1_down": pygame.K_s, "p1_left": pygame.K_a, "p1_right": pygame.K_d,
        "p1_special_crush": pygame.K_q,
        "p1_special_launch": pygame.K_e,
        "p1_special_drain": pygame.K_r,
        "p1_block": pygame.K_f,
        "p2_up": pygame.K_UP, "p2_down": pygame.K_DOWN,
        "p2_left": pygame.K_LEFT, "p2_right": pygame.K_RIGHT,
        "p2_special_crush": pygame.K_u,
        "p2_special_launch": pygame.K_i,
        "p2_special_drain": pygame.K_o,
        "p2_block": pygame.K_p,
    }


class Profile:
    DEFAULTS = {"sound_on": True, "volume": 0.7, "difficulty": "normal", "bindings": {}}

    def __init__(self, storage=None):
        self.storage = storage or Storage()
        loaded = self.storage.load("settings.json", {})
        self.settings = dict(self.DEFAULTS)
        for key, value in loaded.items():
            if key in self.DEFAULTS and isinstance(value, type(self.DEFAULTS[key])):
                self.settings[key] = value
        self.settings["volume"] = min(1.0, max(0.0, float(self.settings["volume"])))
        self.matches = self.storage.load("stats.json", [])

    # ---------- настройки ----------

    def save_settings(self):
        return self.storage.save("settings.json", self.settings)

    @property
    def sound_on(self):
        return self.settings["sound_on"]

    @property
    def volume(self):
        return self.settings["volume"]

    def set_volume(self, value):
        self.settings["volume"] = min(1.0, max(0.0, value))

    def set_difficulty(self, name):
        self.settings["difficulty"] = name

    @property
    def difficulty(self):
        return self.settings["difficulty"]

    def bindings(self, pygame):
        result = default_bindings(pygame)
        for key, value in self.settings["bindings"].items():
            if key in result and isinstance(value, int):
                result[key] = value
        return result

    def set_binding(self, pygame, action, code):
        """Назначает клавишу; если она занята другим действием, действия меняются местами."""
        current = self.bindings(pygame)
        if action not in current:
            return False
        for other, other_code in current.items():
            if other != action and other_code == code:
                current[other] = current[action]
        current[action] = code
        self.settings["bindings"] = current
        return True

    def reset_bindings(self):
        self.settings["bindings"] = {}

    def schemes(self, pygame):
        b = self.bindings(pygame)
        return tuple(
            ControlScheme(**{a: b["%s_%s" % (p, a)] for a in ACTIONS}) for p in ("p1", "p2"))

    # ---------- статистика ----------

    def record_match(self, result, mode, difficulty):
        # Тренировка не влияет на статистику матчей (Stage 5)
        if mode == "training":
            return None
        entry = {
            "mode": mode, "difficulty": difficulty, "outcome": result.outcome,
            "reason": result.reason, "duration": round(result.duration, 1),
            "damage_dealt": round(result.stats.get("damage_dealt", 0.0), 1),
            "damage_taken": round(result.stats.get("damage_taken", 0.0), 1),
            "max_combo": int(result.stats.get("max_combo", 0)),
            "player_lives": getattr(result, "player_lives", 0),
            "enemy_lives": getattr(result, "enemy_lives", 0),
            "time": int(time.time()),
        }
        self.matches.append(entry)
        del self.matches[:-MAX_MATCHES]
        self.storage.save("stats.json", self.matches)
        return entry

    def summary(self):
        real = [m for m in self.matches if m.get("mode") == "match"]
        wins = sum(1 for m in real if m["outcome"] == "victory")
        losses = sum(1 for m in real if m["outcome"] == "defeat")
        draws = sum(1 for m in real if m["outcome"] in ("draw", "time_up"))
        time_ups = sum(1 for m in real if m["outcome"] == "time_up")
        played = len(real)
        return {
            "played": played,
            "wins": wins,
            "losses": losses,
            "draws": draws,
            "time_ups": time_ups,
            "winrate": round(100.0 * wins / played) if played else 0,
            "best_combo": max((m.get("max_combo", 0) for m in self.matches), default=0),
            "damage_dealt": round(sum(m.get("damage_dealt", 0) for m in real)),
            "damage_taken": round(sum(m.get("damage_taken", 0) for m in real)),
            "ring_out_wins": sum(1 for m in real if m["outcome"] == "victory" and m.get("reason") == "ring_out"),
            "ring_out_losses": sum(1 for m in real if m["outcome"] == "defeat" and m.get("reason") == "ring_out"),
            "avg_duration": round(sum(m.get("duration", 0) for m in real) / played) if played else 0,
            "training": sum(1 for m in self.matches if m.get("mode") == "training"),
            "recent": list(reversed(self.matches[-8:])),
        }
