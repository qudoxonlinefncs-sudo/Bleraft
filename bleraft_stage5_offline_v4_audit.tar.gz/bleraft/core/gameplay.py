"""Игровая сцена: арена, бойцы, жесты, бой, Combo Rush, пол арены, Ring Out, боты."""

import settings
from arena.arena import Arena
from combat.attacks import tier_for_speed
from combat.combat_system import BUSY, STARTED, CombatSystem
from combat.combo_rush import ComboRush
from combat.specials import (SPECIALS, BLOCK, CooldownState, EnergyPool,
                             ENERGY_ON_HIT, ENERGY_COST)
from core.match_rules import MatchStats
from core.states import State
from entities.fighter import Fighter, FighterState
from input.commands import AttackKeyCommand, ResetCommand, SpecialCommand, StrokeCommand
from input.gesture_recognizer import GestureRecognizer
from ui.effects import Effects


def create_fighters(arena):
    """Синий слева, красный справа, оба по центру арены по вертикали."""
    offset = settings.PLAYER_SPAWN_OFFSET
    return [
        Fighter("blue", arena.center_x - offset, arena.center_y,
                settings.PLAYER_SIZE, settings.PLAYER_SPEED),
        Fighter("red", arena.center_x + offset, arena.center_y,
                settings.PLAYER_SIZE, settings.PLAYER_SPEED),
    ]


class GameplayState(State):
    """Логика сцены. Ввод, отрисовка, боты и правила матча подключаются снаружи.

    input_source.direction(index) -> (dx, dy) - движение игрока index.
    command_input.handle_event(event, now) -> команды (жесты, клавиши атак).
    renderer.draw(surface, arena, fighters, alpha) - арена и бойцы.
    combat_view.draw(surface, scene, alpha) - бой, HUD, след жеста.
    controllers - {индекс бойца: бот}; бот вместо input_source решает, куда идти и когда бить.
    rules - MatchRules: после каждого тика проверяет конец матча (scene.result).
    Всё, кроме input_source, необязательно.
    """

    def __init__(self, input_source, renderer=None, arena=None, fighters=None,
                 command_input=None, combat_view=None, recognizer=None,
                 controllers=None, rules=None, player_index=0):
        super().__init__()
        self.input = input_source
        self.renderer = renderer
        self.command_input = command_input
        self.combat_view = combat_view
        self.recognizer = recognizer if recognizer is not None else GestureRecognizer()
        self.arena = arena if arena is not None else Arena.from_settings()
        self.floor = self.arena.floor
        self.fighters = (
            fighters if fighters is not None else create_fighters(self.arena)
        )
        self.controllers = controllers if controllers is not None else {}
        self.rules = rules
        self.player_index = player_index
        self.combat = CombatSystem(self.fighters)
        self.effects = Effects()
        self.rush = [ComboRush() for _ in self.fighters]
        self.cooldowns = [CooldownState() for _ in self.fighters]
        self.energy = [EnergyPool() for _ in self.fighters]
        self.blocking = [0.0 for _ in self.fighters]  # оставшееся время блока
        self.stats = MatchStats()
        self.result = None
        self.sound_events = []     # "hit", "swing", "combo", "crack", "fall", "ringout"

    @property
    def time(self):
        return self.combat.time

    @property
    def trail(self):
        """Точки жеста, который рисуется прямо сейчас."""
        if self.command_input is None or not self.command_input.recorder.active:
            return []
        return self.command_input.recorder.points

    # ---------- ввод ----------

    def handle_event(self, event):
        if self.command_input is None or self.result is not None:
            return
        for command in self.command_input.handle_event(event, self.time):
            self.execute(command)

    def execute(self, command):
        if isinstance(command, ResetCommand):
            self.reset()
        elif isinstance(command, StrokeCommand):
            self._attack_from_stroke(command)
        elif isinstance(command, AttackKeyCommand):
            if 0 <= command.player_index < len(self.fighters):
                self.perform_gesture(command.player_index, command.gesture, "medium",
                                     getattr(command, "modifier", None))
        elif isinstance(command, SpecialCommand):
            if 0 <= command.player_index < len(self.fighters):
                self.perform_special(command.player_index, command.action)

    def _attack_from_stroke(self, command):
        index = command.player_index
        if not 0 <= index < len(self.fighters):
            return
        result = self.recognizer.recognize(command.stroke.points)
        if not result.ok:
            self.effects.set_indicator(index, None, None, False, result.reason)
            if result.is_attempt:                      # неправильный жест, а не клик
                self.rush[index].fail(self.time)
                if index == self.player_index:
                    self.stats.gestures_failed += 1
            return                                     # неизвестный жест атаку не запускает
        self.perform_gesture(index, result.name, tier_for_speed(result.speed),
                                 getattr(command, "modifier", None))

    def perform_gesture(self, index, gesture, tier="medium", modifier=None):
        """Распознанный жест: обычный или Q/E/R-модифицированный.

        Если модификатор задан, но энергии/кулдауна нет — атака ОТКЛОНЯЕТСЯ
        (не превращается в обычную). Combo Rush продвигается только при STARTED.
        """
        fighter = self.fighters[index]
        if not fighter.alive:
            return
        if modifier is not None and modifier not in SPECIALS:
            modifier = None

        special_spec = None
        if modifier in SPECIALS:
            cd = self.cooldowns[index]
            energy = self.energy[index]
            spec = SPECIALS[modifier]
            cost = spec["energy_cost"]
            if not cd.ready(modifier):
                self._notify(index, "ПЕРЕЗАРЯДКА")
                return
            if not energy.can_afford(cost):
                self._notify(index, "МАЛО ЭНЕРГИИ")
                return
            special_spec = spec

        damage_scale = 1.0
        if special_spec is not None:
            damage_scale = float(special_spec["damage_mult"])
            result = self.combat.request_special_gesture(
                fighter, gesture, tier, special_spec, damage_scale)
            if result == STARTED:
                self.energy[index].spend(special_spec["energy_cost"])
                self.cooldowns[index].trigger(modifier, special_spec["cooldown"])
                self.sound_events.append("swing")
                self._register_rush_success(index)
            elif result == BUSY:
                # буфер сохраняет спец; энергия/CD спишутся при реальном старте —
                # списываем сейчас, чтобы нельзя было спамить буфер
                self.energy[index].spend(special_spec["energy_cost"])
                self.cooldowns[index].trigger(modifier, special_spec["cooldown"])
                self.combat.buffer_attack(
                    fighter, gesture, tier, damage_scale, special_spec=special_spec)
                self._register_rush_success(index)
            else:
                self._notify(index, "НЕЛЬЗЯ")
            label = "%s+%s" % (modifier, gesture)
            self.effects.set_indicator(index, label, tier, result in (STARTED, BUSY), "ok")
            return result

        result = self.combat.request_attack(fighter, gesture, tier, damage_scale=1.0)
        if result == BUSY:
            self.combat.buffer_attack(fighter, gesture, tier, 1.0)
            self._register_rush_success(index)
        elif result == STARTED:
            self.sound_events.append("swing")
            self._register_rush_success(index)
        self.effects.set_indicator(index, gesture, tier, result in (STARTED, BUSY), "ok")
        return result

    def _register_rush_success(self, index):
        """Combo Rush только после реально принятого жеста (STARTED/буфер)."""
        rush = self.rush[index]
        rush.register(self.time)
        if index == self.player_index:
            self.stats.gestures_ok += 1
            self.stats.max_combo = max(self.stats.max_combo, rush.peak)

    def _notify(self, index, text):
        """Короткое уведомление на HUD (через effects indicator)."""
        if hasattr(self, "effects") and self.effects is not None:
            self.effects.set_indicator(index, text, "medium", False, "fail")
        if not hasattr(self, "notices"):
            self.notices = []
        self.notices.append((self.time, text))

    def perform_special(self, index, action):
        """Только блок (F). Q/E/R больше не вызывают атаку сами по себе."""
        fighter = self.fighters[index]
        if not fighter.alive:
            return
        if action != "block":
            return
        from entities.fighter import FighterState
        # Блок только в IDLE / RECOVERY; не в Windup/Active/Hitstun
        if fighter.state in (FighterState.WINDUP, FighterState.ACTIVE, FighterState.HITSTUN):
            self._notify(index, "НЕЛЬЗЯ")
            return
        cd = self.cooldowns[index]
        if not cd.ready("block"):
            self._notify(index, "ПЕРЕЗАРЯДКА")
            return
        self.blocking[index] = BLOCK["window"]
        fighter.blocking_active = True
        cd.trigger("block", BLOCK["cooldown"] + BLOCK.get("recovery", 0.0))
        self.sound_events.append("swing")

    def reset(self):
        mode = getattr(self, "mode", "match")
        if mode == "training":
            from core.match_setup import create_player, create_dummy
            self.fighters[:] = [create_player(self.arena), create_dummy(self.arena)]
            self.controllers = {}
            self.rules = None
            if self.floor is not None:
                self.floor.enabled = False
        else:
            self.fighters[:] = create_fighters(self.arena)
        self.combat = CombatSystem(self.fighters)
        self.effects.clear()
        self.rush = [ComboRush() for _ in self.fighters]
        self.cooldowns = [CooldownState() for _ in self.fighters]
        self.energy = [EnergyPool() for _ in self.fighters]
        self.blocking = [0.0 for _ in self.fighters]  # оставшееся время блока
        self.stats = MatchStats()
        self.result = None
        self.sound_events = []
        if self.floor is not None:
            self.floor.reset()
        for controller in self.controllers.values():
            controller.reset()
        if self.command_input is not None:
            self.command_input.recorder.cancel()

    # ---------- логика ----------

    def update(self, dt):
        if self.result is not None:
            self.update_visuals(dt)       # бой остановлен: двигаются только эффекты
            return
        self.combat.update(dt)
        for i in range(len(self.blocking)):
            if self.blocking[i] > 0:
                self.blocking[i] = max(0.0, self.blocking[i] - dt)
            self.cooldowns[i].update(dt)
            self.energy[i].regen(dt)
            self.fighters[i].blocking_active = self.blocking[i] > 0
        self._handle_combat_events()
        if self.floor is not None:
            self.floor.update(dt)
            self.sound_events.extend(self.floor.events)
        for index, rush in enumerate(self.rush):
            rush.update(self.time)
            self._drain_rush(rush)

        knock_through = self.floor is not None
        for index, fighter in enumerate(self.fighters):
            controller = self.controllers.get(index)
            if controller is not None and fighter.alive:
                intent = controller.think(self, index, dt)
                direction = intent.direction
                if intent.gesture is not None:
                    self.perform_gesture(index, intent.gesture, intent.tier)
            elif controller is not None:
                direction = (0, 0)
            else:
                direction = self.input.direction(index)
            fighter.update(dt, direction, self.arena.bounds, knock_through)
        if self.floor is not None:
            self._resolve_pushboxes()
        self._check_ring_out()
        self._process_deaths_and_respawns(dt)
        self.update_visuals(dt)
        if self.rules is not None:
            self.result = self.rules.evaluate(self)

    def update_visuals(self, dt):
        self.effects.update(dt)
        for fighter in self.fighters:
            if fighter.ring_out:
                fighter.ring_out_time += dt

    def _handle_combat_events(self):
        for event in self.combat.events:
            self.effects.add_hit(event.x, event.y, event.finisher)
            if event.damage > 0:
                self.sound_events.append("hit")
            attacker = self.fighters.index(event.attacker)
            target = self.fighters.index(event.target)
            self.rush[target].interrupt(self.time)
            self._drain_rush(self.rush[target])
            # энергия за успешное попадание (урон > 0)
            if event.damage > 0 and attacker < len(self.energy):
                self.energy[attacker].gain(ENERGY_ON_HIT)
            if attacker == self.player_index:
                self.stats.damage_dealt += event.damage
                self.stats.hits_landed += 1
            elif target == self.player_index:
                self.stats.damage_taken += event.damage
                self.stats.hits_taken += 1

    def _drain_rush(self, rush):
        for event in rush.events:
            if event.kind in ("combo", "extend", "continue"):
                self.sound_events.append("combo")
        rush.events = []

    def _check_ring_out(self):
        for index, fighter in enumerate(self.fighters):
            if fighter.alive and self.floor is not None and not self.floor.is_safe(fighter.x, fighter.y):
                self._lose_life(index, "ring_out")

    def _lose_life(self, index, reason="ko"):
        """Снять жизнь у бойца (KO или Ring Out)."""
        fighter = self.fighters[index]
        if fighter.eliminated:
            return
        # уже в RESPAWNING — не снимаем жизнь повторно
        if fighter.state is FighterState.RESPAWNING:
            return
        will_respawn = fighter.lose_life(reason)
        self.rush[index].reset(self.time)
        self.stats.lives_lost += 1
        if reason == "ring_out":
            self.stats.ring_outs += 1
            self.sound_events.append("ringout")
        else:
            self.sound_events.append("hit")

    def _process_deaths_and_respawns(self, dt):
        """Конвертировать DEAD от урона в lose_life, тикать возрождения, heal манекена."""
        for index, fighter in enumerate(self.fighters):
            if getattr(fighter, "is_dummy", False):
                # манекен: при 0 HP полностью восстанавливается, урон уже посчитан
                if fighter.hp <= 0:
                    fighter.hp = float(fighter.max_hp)
                    fighter.state = FighterState.IDLE
                    fighter.hit_flash = 0.0
                continue
            if fighter.state is FighterState.DEAD and fighter.lives > 0 and fighter.respawn_timer <= 0:
                self._lose_life(index, "ko")
            elif fighter.state is FighterState.RESPAWNING:
                if fighter.tick_respawn(dt):
                    pos = self._safe_respawn_point(fighter)
                    if pos is None:
                        # отложить: держим таймер около 0
                        fighter.respawn_timer = 0.15
                    else:
                        fighter.respawn(pos)
                        self.sound_events.append("swing")

    # ---------- отрисовка ----------


    def _safe_respawn_point(self, fighter):
        """Безопасная точка возрождения.

        1) Центр живой зоны, если >=60px от врагов и нет windup/active врага рядом.
        2) Ближайшая безопасная клетка.
        3) None — отложить возрождение.
        """
        import math
        left, top, right, bottom = self.arena.bounds
        candidates = []
        # center
        candidates.append(((left + right) / 2, (top + bottom) / 2))
        # spawn
        candidates.append((fighter.spawn_x, fighter.spawn_y))
        # grid of safe floor tiles near center
        if self.floor is not None:
            tsize = getattr(self.floor, "tile_size", 30)
            for r in range(self.floor.r0, self.floor.r1):
                for c in range(self.floor.c0, self.floor.c1):
                    x = self.arena.left + (c + 0.5) * tsize
                    y = self.arena.top + (r + 0.5) * tsize
                    if self.floor.is_safe(x, y):
                        candidates.append((x, y))
        def ok(pos):
            x, y = pos
            if self.floor is not None and not self.floor.is_safe(x, y):
                return False
            for other in self.fighters:
                if other is fighter or not other.alive:
                    continue
                if math.hypot(other.x - x, other.y - y) < 60:
                    return False
                if other.attack is not None:
                    if math.hypot(other.x - x, other.y - y) < 90:
                        return False
            return True
        for pos in candidates:
            if ok(pos):
                return pos
        return None  # defer


    def _resolve_pushboxes(self, passes=3):
        """AABB pushbox: раздвигает живых бойцов после движения."""
        fighters = [f for f in self.fighters if f.alive and not getattr(f, "is_dummy", False)]
        # манекен тоже участвует как неподвижный блок
        dummies = [f for f in self.fighters if getattr(f, "is_dummy", False)]
        all_bodies = fighters + dummies
        for _ in range(passes):
            for i in range(len(all_bodies)):
                for j in range(i + 1, len(all_bodies)):
                    a, b = all_bodies[i], all_bodies[j]
                    aw, ah = a.width, a.width
                    bw, bh = b.width, b.width
                    ax0, ay0 = a.x - aw / 2, a.y - ah / 2
                    bx0, by0 = b.x - bw / 2, b.y - bh / 2
                    overlap_x = min(ax0 + aw, bx0 + bw) - max(ax0, bx0)
                    overlap_y = min(ay0 + ah, by0 + bh) - max(ay0, by0)
                    if overlap_x <= 0 or overlap_y <= 0:
                        continue
                    # раздвигаем по меньшей оси
                    if overlap_x < overlap_y:
                        push = overlap_x / 2
                        if a.x < b.x:
                            dxa, dxb = -push, push
                        else:
                            dxa, dxb = push, -push
                        dya = dyb = 0.0
                    else:
                        push = overlap_y / 2
                        if a.y < b.y:
                            dya, dyb = -push, push
                        else:
                            dya, dyb = push, -push
                        dxa = dxb = 0.0
                    if not getattr(a, "is_dummy", False) and a.alive:
                        a.x += dxa
                        a.y += dya
                    if not getattr(b, "is_dummy", False) and b.alive:
                        b.x += dxb
                        b.y += dyb
                    # clamp to arena
                    for f in (a, b):
                        if getattr(f, "is_dummy", False):
                            continue
                        half = f.width / 2
                        left, top, right, bottom = self.arena.bounds
                        f.x = max(left + half, min(right - half, f.x))
                        f.y = max(top + half, min(bottom - half, f.y))

    def draw(self, surface, alpha):
        if self.renderer is not None:
            self.renderer.draw(surface, self.arena, self.fighters, alpha)
        if self.combat_view is not None:
            self.combat_view.draw(surface, self, alpha)
