"""Сборка матча: арена, бойцы, бот, манекен, правила, ввод."""

import random

import settings
from ai.bot import BotController
from arena.arena import Arena
from arena.floor import ArenaFloor
from core.gameplay import GameplayState, create_fighters
from core.match_rules import MatchRules
from entities.fighter import Fighter
from input.command_input import CommandInput
from input.gesture_recognizer import GestureRecognizer
from input.keyboard import KeyboardInput
from ui.combat_view import CombatView
from ui.renderer import SceneRenderer

MODE_MATCH = "match"
MODE_TRAINING = "training"

DUMMY_HP = 9999
DUMMY_TEAM = "red"


def time_limit_for(mode):
    return settings.MATCH_DURATION if mode == MODE_MATCH else None


def create_dummy(arena):
    offset = settings.PLAYER_SPAWN_OFFSET
    dummy = Fighter(
        DUMMY_TEAM,
        arena.center_x + offset,
        arena.center_y,
        settings.PLAYER_SIZE,
        0.0,
        max_hp=DUMMY_HP,
        lives=999,
    )
    dummy.is_dummy = True
    dummy.no_knockback = True
    dummy.speed = 0.0
    return dummy


def create_player(arena):
    return Fighter(
        "blue",
        arena.center_x - settings.PLAYER_SPAWN_OFFSET,
        arena.center_y,
        settings.PLAYER_SIZE,
        settings.PLAYER_SPEED,
    )


def build_command_input(ctx):
    """CommandInput с актуальными биндингами из профиля. Z/X/C/V в PvE выключены."""
    pg = ctx.pygame
    ci = CommandInput(pg, enable_keyboard_attacks=False)
    try:
        ci.set_bindings(pg, ctx.profile.bindings(pg))
    except Exception:
        pass
    return ci


def build_scene(ctx, mode=MODE_MATCH, difficulty="normal", seed=None):
    pg = ctx.pygame
    arena = Arena.from_settings()
    is_training = mode == MODE_TRAINING
    arena.attach_floor(ArenaFloor(
        arena, tile_size=settings.ARENA_TILE_SIZE, interval=settings.COLLAPSE_INTERVAL,
        warning=settings.COLLAPSE_WARNING, fall_time=settings.COLLAPSE_FALL_TIME,
        min_cols=settings.COLLAPSE_MIN_COLS, min_rows=settings.COLLAPSE_MIN_ROWS,
        enabled=(not is_training)))

    if is_training:
        fighters = [create_player(arena), create_dummy(arena)]
        controllers = {}
        rules = None
    else:
        fighters = create_fighters(arena)
        if seed is None:
            seed = random.randrange(1 << 30)
        controllers = {1: BotController(difficulty, seed)}
        rules = MatchRules(0, time_limit_for(mode))

    scene = GameplayState(
        KeyboardInput(pg, ctx.profile.schemes(pg)),
        SceneRenderer(pg),
        arena=arena,
        fighters=fighters,
        command_input=build_command_input(ctx),
        combat_view=CombatView(pg, font=ctx.font),
        recognizer=GestureRecognizer(),
        controllers=controllers,
        rules=rules,
    )
    scene.mode = mode
    scene._build_ctx = ctx  # for training-safe reset
    return scene
