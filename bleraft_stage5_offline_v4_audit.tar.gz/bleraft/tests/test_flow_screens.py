import shutil
import tempfile
import types
import unittest

import settings
from app import AppContext
from core.flow import Phase, ScreenFlow
from core.profile import Profile, Storage
from core.states import State, StateManager
from tests.fake_pygame import (
    FakePygame, key_down, mouse_down, mouse_move, mouse_up,
)
from ui.screens import (
    CONTROL_LABELS, LobbyScreen, MainMenuScreen, MatchScreen, SettingsScreen, StatsScreen,
)
from ui.widgets import Button, Menu


class StubFont:
    def __init__(self):
        self.texts = []

    def draw(self, surface, text, x, y, scale=2, color=(255, 255, 255), shadow=None, anchor="topleft"):
        self.texts.append(text)
        return (x, y, 1, 1)


class StubFlow:
    def __init__(self):
        self.calls = []

    def go(self, name, **params):
        self.calls.append((name, params))

    def quit(self):
        self.calls.append(("quit", {}))


class StubSound:
    def __init__(self):
        self.played = []

    def play(self, name):
        self.played.append(name)


class Dummy(State):
    def __init__(self, name, phase):
        super().__init__()
        self.name, self.phase = name, phase
        self.events, self.updates, self.draws = [], 0, 0

    def handle_event(self, event):
        self.events.append(event)

    def update(self, dt):
        self.updates += 1

    def draw(self, surface, alpha):
        self.draws += 1


class TmpCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.pg = FakePygame()
        self.ctx = AppContext(self.pg, self.tmp)
        self.ctx.sound = StubSound()
        self.flow = StubFlow()
        self.ctx.flow = self.flow

    def screen(self, cls, **kw):
        s = cls(self.ctx, **kw)
        s.flow = self.flow
        return s

    def key(self, name):
        return key_down(self.pg, name)


class ScreenFlowTests(unittest.TestCase):
    def make(self, fade=0.2):
        pg = FakePygame()
        self.screens = {}

        def factory(name, phase):
            def build(flow, **params):
                d = Dummy(name, phase)
                d.params = params
                self.screens[name] = d
                return d
            return build

        flow = ScreenFlow(pg, {"a": factory("a", Phase.MAIN_MENU), "b": factory("b", Phase.LOBBY)},
                          "a", fade=fade)
        manager = StateManager()
        manager.change(flow)
        self.manager, self.pg = manager, pg
        return flow

    def test_starts_on_the_start_screen_and_fades_in(self):
        flow = self.make()
        self.assertEqual(flow.history, ["a"])
        self.assertEqual(flow.phase, Phase.MAIN_MENU)
        self.assertTrue(flow.transitioning)
        surface = self.pg.Surface((1280, 720))
        flow.draw(surface, 0.0)
        self.assertEqual(flow._veil.alpha, 255)                 # старт с чёрного экрана
        flow.update(0.25)
        self.assertFalse(flow.transitioning)

    def test_go_fades_out_then_swaps_then_fades_in(self):
        flow = self.make()
        flow.update(0.3)
        flow.go("b", x=1)
        surface = self.pg.Surface((1280, 720))
        alphas = []
        for _ in range(40):
            flow.update(0.02)
            flow.draw(surface, 0.0)
            alphas.append(flow._veil.alpha if flow._veil is not None and flow.transitioning else 0)
        self.assertEqual(flow.history, ["a", "b"])
        self.assertEqual(flow.phase, Phase.LOBBY)
        self.assertEqual(self.screens["b"].params, {"x": 1})
        self.assertEqual(max(alphas), 255 if max(alphas) == 255 else max(alphas))
        peak = alphas.index(max(alphas))
        self.assertTrue(all(a <= b for a, b in zip(alphas[:peak], alphas[1:peak + 1])))   # темнеет
        self.assertTrue(all(a >= b for a, b in zip(alphas[peak:], alphas[peak + 1:])))    # светлеет
        self.assertFalse(flow.transitioning)

    def test_input_is_blocked_while_fading_out_but_works_otherwise(self):
        flow = self.make()
        flow.update(0.3)
        flow.handle_event("e1")
        flow.go("b")
        flow.handle_event("e2")                                  # затемнение: игнорируется
        flow.update(0.25)
        flow.handle_event("e3")                                  # уже новый экран
        self.assertEqual(self.screens["a"].events, ["e1"])
        self.assertEqual(self.screens["b"].events, ["e3"])

    def test_second_go_during_transition_and_unknown_screens_are_ignored(self):
        flow = self.make()
        flow.update(0.3)
        flow.go("nope")
        self.assertFalse(flow.transitioning)
        flow.go("b")
        flow.go("a")
        flow.update(0.25)
        self.assertEqual(flow.history, ["a", "b"])

    def test_screens_keep_updating_and_drawing(self):
        flow = self.make()
        surface = self.pg.Surface((1280, 720))
        flow.update(0.1)
        flow.draw(surface, 0.0)
        self.assertEqual((self.screens["a"].updates, self.screens["a"].draws), (1, 1))

    def test_quit_asks_the_root_manager(self):
        flow = self.make()
        flow.quit()
        self.assertTrue(self.manager.quit_requested)

    def test_phase_enum_has_every_required_state(self):
        names = {p.name for p in Phase}
        for required in ("MAIN_MENU", "LOBBY", "MATCH_START", "FIGHT", "VICTORY", "DEFEAT"):
            self.assertIn(required, names)


class MenuTests(unittest.TestCase):
    def setUp(self):
        self.pg = FakePygame()
        self.log = []
        self.buttons = [Button("A", (10, 10, 100, 40), lambda: self.log.append("A")),
                        Button("B", (10, 60, 100, 40), lambda: self.log.append("B"), enabled=False),
                        Button("C", (10, 110, 100, 40), lambda: self.log.append("C"))]
        self.clicked = []
        self.menu = Menu(self.pg, self.buttons, lambda b: self.clicked.append(b.label))

    def key(self, name):
        return key_down(self.pg, name)

    def test_keyboard_navigation_wraps_and_skips_disabled(self):
        self.menu.handle_event(self.key("K_DOWN"))
        self.assertEqual(self.menu.selected, 2)
        self.menu.handle_event(self.key("K_s"))
        self.assertEqual(self.menu.selected, 0)
        self.menu.handle_event(self.key("K_UP"))
        self.assertEqual(self.menu.selected, 2)

    def test_enter_and_space_activate(self):
        self.menu.handle_event(self.key("K_RETURN"))
        self.menu.handle_event(self.key("K_SPACE"))
        self.assertEqual(self.log, ["A", "A"])
        self.assertEqual(self.clicked, ["A", "A"])

    def test_disabled_button_never_activates(self):
        self.menu.activate(1)
        self.assertEqual(self.log, [])

    def test_mouse_hover_selects(self):
        self.menu.handle_event(mouse_move(50, 125, left=False))
        self.assertEqual(self.menu.selected, 2)

    def test_click_needs_press_and_release_on_the_same_button(self):
        self.menu.handle_event(mouse_down(50, 125))
        self.menu.handle_event(mouse_up(50, 30))                  # отпустили на другой кнопке
        self.assertEqual(self.log, [])
        self.menu.handle_event(mouse_down(50, 125))
        self.menu.handle_event(mouse_up(55, 130))
        self.assertEqual(self.log, ["C"])

    def test_right_click_and_click_outside_do_nothing(self):
        self.menu.handle_event(mouse_down(50, 125, button=3))
        self.menu.handle_event(mouse_up(50, 125, button=3))
        self.menu.handle_event(mouse_down(900, 900))
        self.menu.handle_event(mouse_up(900, 900))
        self.assertEqual(self.log, [])

    def test_horizontal_menu_uses_left_right(self):
        menu = Menu(self.pg, self.buttons, horizontal=True)
        menu.handle_event(self.key("K_RIGHT"))
        self.assertEqual(menu.selected, 2)
        menu.handle_event(self.key("K_a"))
        self.assertEqual(menu.selected, 0)


class MainMenuTests(TmpCase):
    def test_has_the_five_required_buttons_in_order(self):
        s = self.screen(MainMenuScreen)
        self.assertEqual([b.label for b in s.menu.buttons],
                         ["ИГРАТЬ", "ТРЕНИРОВКА", "СТАТИСТИКА", "НАСТРОЙКИ", "ВЫХОД"])
        self.assertEqual(s.phase, Phase.MAIN_MENU)

    def test_every_button_does_what_it_says(self):
        s = self.screen(MainMenuScreen)
        for i in range(5):
            s.menu.activate(i)
        self.assertEqual(self.flow.calls, [
            ("lobby", {"mode": "match"}), ("lobby", {"mode": "training"}),
            ("stats", {}), ("settings", {}), ("quit", {})])
        self.assertEqual(self.ctx.sound.played, ["click"] * 5)

    def test_draws_background_title_and_buttons(self):
        s = self.screen(MainMenuScreen)
        screen = self.pg.Surface((1280, 720))
        s.draw(screen, 0.0)
        self.assertGreater(len(screen.blits), 5)
        self.assertGreater(self.pg.draw_calls["rect"], 20)


class LobbyTests(TmpCase):
    def test_start_passes_mode_and_difficulty_to_the_match(self):
        s = self.screen(LobbyScreen, mode="training")
        s.menu.activate(0)
        self.assertEqual(self.flow.calls, [("match", {"mode": "training", "difficulty": "normal"})])

    def test_difficulty_cycles_with_arrows_and_is_saved(self):
        s = self.screen(LobbyScreen, mode="match")
        s.menu.selected = 1
        s.handle_event(self.key("K_RIGHT"))
        self.assertEqual(s.difficulty, "hard")
        s.handle_event(self.key("K_a"))
        s.handle_event(self.key("K_a"))
        self.assertEqual(s.difficulty, "easy")
        self.assertEqual(Profile(Storage(self.tmp)).difficulty, "easy")
        self.assertIn("ЛЁГКИЙ", s.diff_button.label)

    def test_clicking_the_difficulty_button_cycles(self):
        s = self.screen(LobbyScreen, mode="match")
        s.menu.activate(1)
        self.assertEqual(s.difficulty, "hard")

    def test_escape_and_back_return_to_main_menu(self):
        s = self.screen(LobbyScreen)
        s.handle_event(self.key("K_ESCAPE"))
        s.menu.activate(2)
        self.assertEqual(self.flow.calls, [("main_menu", {}), ("main_menu", {})])

    def test_saved_difficulty_is_used_and_garbage_falls_back(self):
        self.ctx.profile.set_difficulty("hard")
        self.assertEqual(self.screen(LobbyScreen).difficulty, "hard")
        self.ctx.profile.set_difficulty("impossible")
        self.assertEqual(self.screen(LobbyScreen).difficulty, "normal")

    def test_draws_for_both_modes(self):
        for mode in ("match", "training"):
            s = self.screen(LobbyScreen, mode=mode)
            s.draw(self.pg.Surface((1280, 720)), 0.0)


class StatsScreenTests(TmpCase):
    def test_shows_real_recorded_results(self):
        from core.match_rules import MatchResult
        self.ctx.profile.record_match(MatchResult("victory", "ko", 50.0, 70.0, 0.0,
                                                  stats={"damage_dealt": 90, "damage_taken": 30, "max_combo": 5}),
                                      "match", "normal")
        s = self.screen(StatsScreen)
        self.assertEqual(s.summary["played"], 1)
        self.assertEqual(s.summary["best_combo"], 5)
        s.draw(self.pg.Surface((1280, 720)), 0.0)

    def test_empty_and_filled_screens_draw(self):
        for _ in range(2):
            self.screen(StatsScreen).draw(self.pg.Surface((1280, 720)), 0.0)
            from core.match_rules import MatchResult
            self.ctx.profile.record_match(MatchResult("defeat", "ring_out", 20.0, 0.0, 50.0, stats={}),
                                          "match", "easy")

    def test_back(self):
        s = self.screen(StatsScreen)
        s.handle_event(self.key("K_ESCAPE"))
        s.menu.activate(0)
        self.assertEqual(self.flow.calls, [("main_menu", {}), ("main_menu", {})])


class SettingsScreenTests(TmpCase):
    def reload(self):
        return Profile(Storage(self.tmp))

    def test_has_sound_volume_and_all_movement_keys(self):
        s = self.screen(SettingsScreen)
        kinds = [r[0] for r in s.rows]
        self.assertEqual(kinds[:2], ["sound", "volume"])
        self.assertEqual(len([r for r in s.rows if r[0] == "key"]), len(CONTROL_LABELS))

    def test_sound_toggle_is_saved(self):
        s = self.screen(SettingsScreen)
        s.selected = 0
        s.handle_event(self.key("K_RETURN"))
        self.assertFalse(self.reload().sound_on)
        s.handle_event(self.key("K_RETURN"))
        self.assertTrue(self.reload().sound_on)

    def test_volume_keys_clamp_and_persist(self):
        s = self.screen(SettingsScreen)
        s.selected = 1
        for _ in range(10):
            s.handle_event(self.key("K_RIGHT"))
        self.assertEqual(self.reload().volume, 1.0)
        for _ in range(15):
            s.handle_event(self.key("K_LEFT"))
        self.assertEqual(self.reload().volume, 0.0)

    def test_volume_slider_with_mouse(self):
        s = self.screen(SettingsScreen)
        x, y, w, h = s._row_rect(1)
        s.handle_event(mouse_down(760 + 150, y + 10))
        self.assertAlmostEqual(self.ctx.profile.volume, 0.5, places=2)
        s.handle_event(mouse_move(760 + 30, y + 10, left=True))
        self.assertAlmostEqual(self.ctx.profile.volume, 0.1, places=2)

    def test_rebinding_a_key(self):
        s = self.screen(SettingsScreen)
        s.selected = 2                                         # ИГРОК 1 ВВЕРХ
        s.handle_event(self.key("K_RETURN"))
        self.assertEqual(s.capturing, "p1_up")
        s.handle_event(self.key("K_i"))
        self.assertIsNone(s.capturing)
        self.assertEqual(self.reload().bindings(self.pg)["p1_up"], self.pg.K_i)
        self.assertEqual(self.reload().schemes(self.pg)[0].up, self.pg.K_i)

    def test_escape_cancels_rebinding_and_does_not_leave_the_screen(self):
        s = self.screen(SettingsScreen)
        s.selected = 3
        s.handle_event(self.key("K_RETURN"))
        s.handle_event(self.key("K_ESCAPE"))
        self.assertIsNone(s.capturing)
        self.assertEqual(self.flow.calls, [])
        self.assertEqual(self.reload().bindings(self.pg)["p1_down"], self.pg.K_s)

    def test_taking_a_used_key_swaps_actions(self):
        s = self.screen(SettingsScreen)
        s.selected = 2
        s.handle_event(self.key("K_RETURN"))
        s.handle_event(self.key("K_s"))                        # S занята "вниз"
        b = self.reload().bindings(self.pg)
        self.assertEqual((b["p1_up"], b["p1_down"]), (self.pg.K_s, self.pg.K_w))

    def test_reset_restores_default_keys(self):
        s = self.screen(SettingsScreen)
        self.ctx.profile.set_binding(self.pg, "p1_up", self.pg.K_i)
        s.selected = [r[0] for r in s.rows].index("reset")
        s.handle_event(self.key("K_RETURN"))
        self.assertEqual(self.reload().bindings(self.pg)["p1_up"], self.pg.K_w)

    def test_navigation_wraps_and_back_saves_and_leaves(self):
        s = self.screen(SettingsScreen)
        s.handle_event(self.key("K_UP"))
        self.assertEqual(s.rows[s.selected][0], "back")
        s.handle_event(self.key("K_RETURN"))
        self.assertEqual(self.flow.calls, [("main_menu", {})])

    def test_mouse_click_on_a_key_row_starts_capture(self):
        s = self.screen(SettingsScreen)
        x, y, w, h = s._row_rect(4)
        s.handle_event(mouse_down(x + 50, y + 10))
        self.assertEqual(s.capturing, "p1_left")

    def test_draw_in_every_state(self):
        s = self.screen(SettingsScreen)
        s.draw(self.pg.Surface((1280, 720)), 0.0)
        s.selected = 2
        s.handle_event(self.key("K_RETURN"))
        s.draw(self.pg.Surface((1280, 720)), 0.0)


class MatchScreenTests(TmpCase):
    def make(self, mode="match", difficulty="normal"):
        self.font = StubFont()
        self.ctx.font = self.font
        return self.screen(MatchScreen, mode=mode, difficulty=difficulty, seed=1)

    def run_to_fight(self, s):
        for _ in range(int((settings.MATCH_COUNTDOWN + settings.MATCH_GO_TIME) * 60) + 2):
            s.update(1 / 60)

    def test_countdown_then_fight_without_any_fighting_before(self):
        s = self.make()
        self.assertEqual(s.phase, Phase.MATCH_START)
        for _ in range(100):
            s.update(1 / 60)
        self.assertEqual(s.phase, Phase.MATCH_START)
        self.assertEqual(s.scene.time, 0.0)                    # время боя не идёт
        self.assertEqual([f.hp for f in s.scene.fighters], [100.0, 100.0])
        self.run_to_fight(s)
        self.assertEqual(s.phase, Phase.FIGHT)

    def test_escape_does_nothing_during_countdown(self):
        s = self.make()
        s.handle_event(self.key("K_ESCAPE"))
        self.assertFalse(s.paused)

    def test_pause_freezes_the_match_and_resume_continues(self):
        s = self.make()
        self.run_to_fight(s)
        for _ in range(30):
            s.update(1 / 60)
        s.handle_event(self.key("K_ESCAPE"))
        self.assertTrue(s.paused)
        t = s.scene.time
        for _ in range(60):
            s.update(1 / 60)
        self.assertEqual(s.scene.time, t)
        s.handle_event(self.key("K_ESCAPE"))
        self.assertFalse(s.paused)
        s.update(1 / 60)
        self.assertGreater(s.scene.time, t)

    def test_pause_menu_leads_to_lobby(self):
        s = self.make("training")
        self.run_to_fight(s)
        s.handle_event(self.key("K_ESCAPE"))
        s.pause_menu.activate(1)
        self.assertEqual(self.flow.calls, [("lobby", {"mode": "training"})])

    def finish(self, s, who_dies):
        self.run_to_fight(s)
        f = s.scene.fighters[who_dies]
        f.hp = 0.0
        f.lives = 0
        f.state = type(f.state).DEAD
        # один тик: gameplay обработает смерть и rules.evaluate выставит result
        s.update(1 / 60)

    def test_victory_state_stats_recorded_once_and_everything_stops(self):
        s = self.make()
        self.finish(s, 1)
        self.assertEqual(s.phase, Phase.VICTORY)
        self.assertEqual(self.ctx.profile.summary()["wins"], 1)
        self.assertIn("win", self.ctx.sound.played)
        t = s.scene.time
        for _ in range(120):
            s.update(1 / 60)
        self.assertEqual(s.scene.time, t)
        self.assertEqual(len(self.ctx.profile.matches), 1)

    def test_defeat_state(self):
        s = self.make()
        self.finish(s, 0)
        self.assertEqual(s.phase, Phase.DEFEAT)
        self.assertEqual(self.ctx.profile.summary()["losses"], 1)
        self.assertIn("lose", self.ctx.sound.played)

    def test_result_screen_texts_and_buttons(self):
        for who, title in ((1, "ПОБЕДА!"), (0, "ПОРАЖЕНИЕ")):
            s = self.make()
            self.finish(s, who)
            for _ in range(60):
                s.update(1 / 60)
            self.font.texts.clear()
            s.draw(self.pg.Surface((1280, 720)), 0.0)
            self.assertIn(title, self.font.texts)
            self.assertIn("РЕВАНШ", self.font.texts)
            self.assertIn("В ЛОББИ", self.font.texts)
            self.assertIn("УРОН НАНЕСЁН", self.font.texts)

    def test_buttons_ignore_clicks_during_the_first_moments_of_the_result(self):
        s = self.make()
        self.finish(s, 1)
        s.handle_event(self.key("K_RETURN"))
        self.assertEqual(self.flow.calls, [])
        for _ in range(60):
            s.update(1 / 60)
        s.handle_event(self.key("K_RETURN"))
        self.assertEqual(self.flow.calls, [("match", {"mode": "match", "difficulty": "normal"})])

    def test_lobby_button_on_result_screen(self):
        s = self.make()
        self.finish(s, 0)
        for _ in range(60):
            s.update(1 / 60)
        s.handle_event(self.key("K_RIGHT"))
        s.handle_event(self.key("K_RETURN"))
        self.assertEqual(self.flow.calls, [("lobby", {"mode": "match"})])

    def test_rematch_creates_a_clean_new_scene(self):
        a = self.make()
        self.finish(a, 1)
        b = self.make()
        self.assertIsNot(a.scene, b.scene)
        self.assertEqual(b.scene.time, 0.0)
        self.assertIsNone(b.scene.result)
        self.assertEqual([f.hp for f in b.scene.fighters], [100.0, 100.0])
        self.assertEqual(b.scene.floor.rings_fallen, 0)

    def test_every_phase_draws(self):
        s = self.make()
        screen = self.pg.Surface((1280, 720))
        s.draw(screen, 0.0)                                   # отсчёт: цифра
        self.assertIn("3", self.font.texts)
        for _ in range(int(settings.MATCH_COUNTDOWN * 60) + 5):
            s.update(1 / 60)
        s.draw(screen, 0.0)                                   # отсчёт: "БОЙ!"
        self.assertIn("БОЙ!", self.font.texts)
        self.run_to_fight(s)
        s.draw(screen, 0.0)                                   # бой
        s.handle_event(self.key("K_ESCAPE"))
        s.draw(screen, 0.0)                                   # пауза
        s.handle_event(self.key("K_ESCAPE"))
        self.finish(s, 1)
        s.draw(screen, 0.0)                                   # результат
        self.assertIn("ПАУЗА", self.font.texts)

    def test_mode_settings_reach_the_scene(self):
        self.assertIsNotNone(self.make("match").scene.rules.time_limit)
        # Stage 5: в тренировке нет MatchRules (нет победы/поражения)
        self.assertIsNone(self.make("training").scene.rules)
        self.assertTrue(self.make("match").scene.floor.enabled)
        self.assertFalse(self.make("training").scene.floor.enabled)

    def test_scene_sounds_are_played(self):
        s = self.make()
        self.run_to_fight(s)
        s.scene.sound_events.append("hit")
        s.update(1 / 60)
        self.assertIn("hit", self.ctx.sound.played)
        self.assertEqual(s.scene.sound_events, [])


if __name__ == "__main__":
    unittest.main()
