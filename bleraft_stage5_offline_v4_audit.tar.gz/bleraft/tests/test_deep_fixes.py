"""Глубокие исправления Stage 5 Offline."""

import types
import unittest

from combat.specials import SPECIALS, ENERGY_MAX, ENERGY_COST
from combat.combo_rush import ComboRush
from core.gameplay import GameplayState
from core.match_rules import MatchRules, TIME_UP, DRAW, VICTORY
from core.match_setup import MODE_TRAINING, MODE_MATCH, build_scene, create_dummy, create_player
from entities.fighter import Fighter, FighterState
from input.command_input import CommandInput
from input.commands import SpecialCommand, StrokeCommand


class Idle:
    def direction(self, i):
        return (0, 0)


def scene():
    from arena.arena import Arena
    arena = Arena.from_settings()
    blue = Fighter("blue", arena.center_x - 80, arena.center_y, 36, 280)
    red = Fighter("red", arena.center_x + 80, arena.center_y, 36, 280)
    return GameplayState(Idle(), arena=arena, fighters=[blue, red],
                         rules=MatchRules(0, None))


class KeyboardNotBotTests(unittest.TestCase):
    def test_default_command_input_has_no_attack_keys_for_bot(self):
        pg = types.SimpleNamespace(
            MOUSEBUTTONDOWN=1, MOUSEBUTTONUP=2, MOUSEMOTION=3,
            KEYDOWN=4, KEYUP=5, K_z=122, K_x=120, K_c=99, K_v=118,
            K_q=113, K_e=101, K_r=114, K_f=102, K_F5=1073741920,
        )
        ci = CommandInput(pg)
        self.assertEqual(ci.attack_keys, {})
        # C alone does nothing
        self.assertEqual(ci.handle_event(types.SimpleNamespace(type=4, key=99), 0.0), [])


class SpecialRejectTests(unittest.TestCase):
    def test_no_energy_rejects_special_not_fallback(self):
        s = scene()
        s.energy[0].current = 0
        s.perform_gesture(0, "slash", modifier="crush")
        self.assertIsNone(s.fighters[0].attack)

    def test_cooldown_rejects_special(self):
        s = scene()
        s.cooldowns[0].trigger("crush", 5)
        s.perform_gesture(0, "slash", modifier="crush")
        self.assertIsNone(s.fighters[0].attack)

    def test_q_alone_noop(self):
        s = scene()
        s.perform_special(0, "crush")
        self.assertIsNone(s.fighters[0].attack)

    def test_buffer_keeps_special(self):
        s = scene()
        blue = s.fighters[0]
        # force busy
        s.perform_gesture(0, "slash")
        self.assertIsNotNone(blue.attack)
        s.energy[0].current = ENERGY_MAX
        s.perform_gesture(0, "slash", modifier="crush")
        # pending should have special_spec
        item = s.combat._pending.get(id(blue))
        self.assertIsNotNone(item)
        self.assertEqual(len(item), 5)
        self.assertIsNotNone(item[4])
        self.assertEqual(item[4]["id"], "crush")


class ComboRushNoBonusTests(unittest.TestCase):
    def test_damage_multiplier_always_one(self):
        r = ComboRush()
        for i in range(10):
            r.register(i * 0.5)
        self.assertEqual(r.damage_multiplier(), 1.0)

    def test_busy_does_not_register_twice_without_start(self):
        s = scene()
        # first starts
        s.perform_gesture(0, "slash")
        c1 = s.rush[0].count
        # while busy, without buffer path counting carefully
        # second attempt while windup - may buffer and register once more
        before = s.rush[0].count
        s.perform_gesture(0, "slash")
        # count should not jump by more than 1
        self.assertLessEqual(s.rush[0].count - before, 1)


class TrainingResetTests(unittest.TestCase):
    def test_reset_keeps_dummy(self):
        from arena.arena import Arena
        arena = Arena.from_settings()
        from arena.floor import ArenaFloor
        arena.attach_floor(ArenaFloor(arena, enabled=False))
        fighters = [create_player(arena), create_dummy(arena)]
        s = GameplayState(Idle(), arena=arena, fighters=fighters, rules=None)
        s.mode = "training"
        s.reset()
        self.assertTrue(getattr(s.fighters[1], "is_dummy", False))
        self.assertGreaterEqual(s.fighters[1].max_hp, 1000)


class TimeUpTests(unittest.TestCase):
    def test_time_up_outcome(self):
        s = scene()
        s.rules = MatchRules(0, 1.0)
        for _ in range(70):
            s.update(1 / 60)
        self.assertIsNotNone(s.result)
        self.assertEqual(s.result.outcome, TIME_UP)


class PushboxTests(unittest.TestCase):
    def test_fighters_are_separated(self):
        s = scene()
        a, b = s.fighters
        a.x = b.x = 400
        a.y = b.y = 300
        s._resolve_pushboxes()
        self.assertGreater(abs(a.x - b.x) + abs(a.y - b.y), 1.0)
        # no overlap
        overlap_x = min(a.x + a.width/2, b.x + b.width/2) - max(a.x - a.width/2, b.x - b.width/2)
        overlap_y = min(a.y + a.width/2, b.y + b.width/2) - max(a.y - a.width/2, b.y - b.width/2)
        self.assertTrue(overlap_x <= 0 or overlap_y <= 0)


class BlockNoDamageTests(unittest.TestCase):
    def test_block_negates_damage_and_hit_stats(self):
        s = scene()
        blue, red = s.fighters
        red.x = red.prev_x = blue.x + 55
        s.perform_special(1, "block")
        before_hits = s.stats.hits_landed
        before_hp = red.hp
        s.perform_gesture(0, "slash")
        for _ in range(40):
            s.update(1 / 60)
        self.assertEqual(red.hp, before_hp)
        # damage 0 events should not count as landed hits with damage
        # (stats may still increment — check damage)
        self.assertEqual(s.stats.damage_dealt, 0)


if __name__ == "__main__":
    unittest.main()
