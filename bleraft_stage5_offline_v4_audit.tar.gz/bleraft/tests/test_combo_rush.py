import unittest

import settings
from combat.combo_rush import ComboRush
from core.gameplay import GameplayState
from entities.fighter import FighterState as S
from input.commands import AttackKeyCommand, StrokeCommand
from input.gesture_recorder import Stroke
from tests.helpers import SHAPES, circle_points, make_stroke, polyline, shape_stroke


class NoMove:
    def direction(self, index):
        return (0, 0)


class ComboRushTests(unittest.TestCase):
    def test_default_time_table_matches_the_design(self):
        r = ComboRush()
        self.assertEqual([r.limit_for(n) for n in (2, 3, 4, 5, 6, 7, 20)],
                         [3.0, 2.5, 2.0, 1.5, 1.0, 1.0, 1.0])

    def test_first_gesture_starts_the_timer_for_the_second(self):
        r = ComboRush()
        e = r.register(10.0)
        self.assertEqual((e.kind, e.count, e.limit), ("start", 1, 3.0))
        self.assertAlmostEqual(r.remaining(11.0), 2.0)

    def test_time_to_continue_shrinks_with_every_correct_gesture(self):
        r, now, limits = ComboRush(), 0.0, []
        for _ in range(7):
            limits.append(r.register(now).limit)
            now += 0.5
        self.assertEqual(limits, [3.0, 2.5, 2.0, 1.5, 1.0, 1.0, 1.0])

    def test_combo_activates_on_third_and_keeps_growing(self):
        r = ComboRush()
        kinds = [r.register(i * 0.5).kind for i in range(6)]
        self.assertEqual(kinds, ["start", "continue", "combo", "extend", "extend", "extend"])
        self.assertTrue(r.combo_active)
        self.assertEqual((r.count, r.peak), (6, 6))

    def test_not_combo_before_third_gesture(self):
        r = ComboRush()
        r.register(0.0)
        r.register(0.5)
        self.assertFalse(r.combo_active)

    def test_minimum_time_is_a_floor(self):
        r = ComboRush(times=(0.2, 0.1), min_time=1.0)
        self.assertEqual(r.limit_for(2), 1.0)
        self.assertEqual(r.limit_for(9), 1.0)

    def test_timeout_resets_the_chain(self):
        r = ComboRush()
        r.register(0.0)
        r.register(1.0)
        self.assertFalse(r.update(3.4))                 # 1.0 + 2.5 = 3.5, ещё можно
        self.assertTrue(r.update(3.6))
        self.assertEqual(r.count, 0)
        self.assertEqual(r.last_event.kind, "reset")
        self.assertEqual(r.last_event.reason, "timeout")

    def test_gesture_just_before_the_deadline_continues(self):
        r = ComboRush()
        r.register(0.0)
        self.assertEqual(r.register(2.99).kind, "continue")

    def test_gesture_after_deadline_without_update_starts_a_new_chain(self):
        r = ComboRush()
        r.register(0.0)
        r.register(1.0)
        e = r.register(9.0)
        self.assertEqual((e.kind, e.count), ("start", 1))

    def test_wrong_gesture_and_interrupt_reset(self):
        for method, reason in (("fail", "wrong"), ("interrupt", "interrupted")):
            r = ComboRush()
            r.register(0.0)
            r.register(0.5)
            getattr(r, method)(1.0)
            self.assertEqual((r.count, r.last_event.reason), (0, reason))

    def test_reset_when_idle_does_nothing(self):
        r = ComboRush()
        self.assertIsNone(r.fail(1.0))
        self.assertIsNone(r.interrupt(1.0))
        self.assertEqual(r.events, [])

    def test_damage_bonus_starts_with_combo_and_is_capped(self):
        r = ComboRush()
        mult = []
        for i in range(12):
            r.register(i * 0.3)
            mult.append(r.damage_multiplier())
        self.assertTrue(all(m == 1.0 for m in mult))

    def test_custom_parameters_are_respected(self):
        r = ComboRush(times=(5.0, 4.0), min_time=0.5, activate_at=2)
        self.assertEqual(r.register(0).limit, 5.0)
        self.assertEqual(r.register(1).kind, "combo")


def duel():
    s = GameplayState(NoMove())
    blue, red = s.fighters
    red.x = red.prev_x = blue.x + 60
    red.y = red.prev_y = blue.y
    return s


def stroke(name, **kw):
    return StrokeCommand(0, Stroke(tuple(shape_stroke(name, scale=200, **kw))))


class RushInGameTests(unittest.TestCase):
    def test_correct_gestures_build_the_chain_and_combo(self):
        s = duel()
        for name in ("slash", "sweep", "thrust"):
            s.execute(stroke(name))
            s.update(0.8)
        self.assertEqual(s.rush[0].count, 3)
        self.assertTrue(s.rush[0].combo_active)
        self.assertEqual(s.stats.max_combo, 3)
        self.assertIn("combo", s.sound_events)

    def test_wrong_gesture_resets_but_a_click_does_not(self):
        s = duel()
        s.execute(stroke("slash"))
        s.execute(StrokeCommand(0, Stroke(((100.0, 100.0, 0.0), (101.0, 100.0, 0.05)))))   # клик
        self.assertEqual(s.rush[0].count, 1)
        s.execute(StrokeCommand(0, Stroke(tuple(make_stroke(circle_points())))))            # не жест
        self.assertEqual(s.rush[0].count, 0)
        self.assertEqual(s.stats.gestures_failed, 1)

    def test_ambiguous_gesture_resets_the_chain(self):
        s = duel()
        s.execute(stroke("slash"))
        s.execute(StrokeCommand(0, Stroke(tuple(shape_stroke("slash", scale=200, rot_deg=-24)))))
        self.assertEqual(s.rush[0].count, 0)
        self.assertEqual(s.effects.indicators[0].reason, "ambiguous")

    def test_timeout_resets_in_the_game_loop(self):
        s = duel()
        s.execute(stroke("slash"))
        for _ in range(int(3.3 * 60)):
            s.update(1 / 60)
        self.assertEqual(s.rush[0].count, 0)

    def test_second_gesture_within_the_limit_keeps_the_chain_alive(self):
        s = duel()
        s.execute(stroke("slash"))
        for _ in range(int(2.8 * 60)):
            s.update(1 / 60)
        s.execute(stroke("sweep"))
        self.assertEqual(s.rush[0].count, 2)
        self.assertAlmostEqual(s.rush[0].limit, 2.5)

    def test_being_hit_interrupts_the_chain(self):
        s = duel()
        s.execute(stroke("slash"))
        s.execute(AttackKeyCommand(1, "thrust"))        # красный бьёт быстрее
        for _ in range(120):
            s.update(1 / 60)
        self.assertEqual(s.rush[0].count, 0)
        self.assertEqual(s.rush[0].last_event.reason, "interrupted")

    def test_gesture_counts_even_when_the_attack_misses(self):
        s = duel()
        s.fighters[1].x = s.fighters[1].prev_x = 1100.0      # далеко
        s.execute(stroke("slash"))
        s.update(1.0)
        self.assertEqual(s.fighters[1].hp, 100)
        self.assertEqual(s.rush[0].count, 1)

    def test_drawing_speed_does_not_change_the_rush_timer(self):
        fast, slow = duel(), duel()
        fast.execute(stroke("slash", duration=0.12))
        slow.execute(stroke("slash", duration=0.95))
        self.assertEqual(fast.rush[0].limit, slow.rush[0].limit)
        self.assertEqual(fast.fighters[0].attack.spec.tier, "fast")
        self.assertEqual(slow.fighters[0].attack.spec.tier, "slow")

    def test_third_gesture_has_no_damage_bonus(self):
        s = duel()
        s.fighters[1].x = s.fighters[1].prev_x = 3000.0
        specs = []
        for name in ("slash", "sweep", "thrust"):
            s.perform_gesture(0, name)
            specs.append((name, s.fighters[0].attack.spec if s.fighters[0].attack else None))
            for _ in range(80):
                s.update(1 / 60)
        from combat.attacks import resolve_attack
        # Stage 5: Combo Rush не усиливает урон
        self.assertAlmostEqual(specs[2][1].damage, resolve_attack("thrust").damage)
        self.assertAlmostEqual(specs[0][1].damage, resolve_attack("slash").damage)

    def test_bot_gestures_use_the_same_rush_rules(self):
        s = duel()
        s.perform_gesture(1, "slash")
        s.perform_gesture(1, "slash")
        self.assertEqual(s.rush[1].count, 2)
        self.assertEqual(s.rush[0].count, 0)


class InputBufferTests(unittest.TestCase):
    def test_gesture_slightly_too_early_is_executed_when_possible(self):
        s = duel()
        s.fighters[1].x = s.fighters[1].prev_x = 3000.0
        s.perform_gesture(0, "slash")
        s.update(0.05)
        s.perform_gesture(0, "sweep")               # ещё идёт подготовка: в буфер
        started = None
        for i in range(120):
            s.update(1 / 60)
            if s.fighters[0].attack and s.fighters[0].attack.spec.name == "sweep":
                started = i / 60
                break
        self.assertIsNotNone(started)
        self.assertLess(started, 0.5)

    def test_buffer_does_not_allow_attacking_faster_than_recovery(self):
        s = duel()
        s.fighters[1].x = s.fighters[1].prev_x = 3000.0
        starts, last = [], None
        for i in range(60 * 6):
            s.perform_gesture(0, "thrust")             # спам каждый тик
            s.update(1 / 60)
            a = s.fighters[0].attack
            if a is not None and a is not last:        # новая атака
                starts.append(s.time)
            last = a
        gaps = [b - a for a, b in zip(starts, starts[1:])]
        self.assertTrue(gaps)
        self.assertGreaterEqual(min(gaps), 0.62 - 2 / 60)      # полный цикл thrust

    def test_buffered_gesture_expires(self):
        s = duel()
        s.fighters[1].x = s.fighters[1].prev_x = 3000.0
        s.perform_gesture(0, "double", "slow")      # очень долгая атака (больше 1.3 с)
        s.update(0.05)
        s.perform_gesture(0, "thrust")              # попал в буфер, но ждать придётся дольше срока
        started = set()
        last = None
        for _ in range(60 * 3):
            s.update(1 / 60)
            a = s.fighters[0].attack
            if a is not None and a is not last:
                started.add(a.spec.name)
            last = a
        self.assertEqual(started, {"double"})       # thrust по истёкшему буферу не запустился

    def test_buffer_is_cleared_when_the_fighter_is_hit(self):
        s = duel()
        s.perform_gesture(0, "slash", "slow")
        s.perform_gesture(0, "sweep")               # в буфере
        s.perform_gesture(1, "thrust", "fast")      # красный быстро бьёт и прерывает
        for _ in range(90):
            s.update(1 / 60)
        self.assertNotEqual(getattr(s.fighters[0].attack, "spec", None) and s.fighters[0].attack.spec.name, "sweep")


if __name__ == "__main__":
    unittest.main()
