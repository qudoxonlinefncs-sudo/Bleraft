"""Stage 5: Q/E/R как модификаторы жеста + энергия + блок F."""

import unittest

from combat.specials import SPECIALS, BLOCK, CooldownState, EnergyPool, ENERGY_MAX, ENERGY_COST, ENERGY_ON_HIT
from core.gameplay import GameplayState
from entities.fighter import Fighter
from input.commands import SpecialCommand, StrokeCommand
from input.command_input import CommandInput
from tests.helpers import shape_stroke
from input.gesture_recorder import Stroke
import types


class Idle:
    def direction(self, i):
        return (0, 0)


def scene():
    from arena.arena import Arena
    arena = Arena.from_settings()
    blue = Fighter("blue", arena.center_x - 100, arena.center_y, 36, 280)
    red = Fighter("red", arena.center_x + 100, arena.center_y, 36, 280)
    return GameplayState(Idle(), arena=arena, fighters=[blue, red])


class EnergyTests(unittest.TestCase):
    def test_starts_full(self):
        e = EnergyPool()
        self.assertEqual(e.current, ENERGY_MAX)

    def test_spend_and_cannot_overspend(self):
        e = EnergyPool()
        self.assertTrue(e.spend(40))
        self.assertFalse(e.spend(ENERGY_MAX))

    def test_regen_caps_at_max(self):
        e = EnergyPool(current=90)
        e.regen(10)
        self.assertEqual(e.current, ENERGY_MAX)

    def test_gain_on_hit(self):
        s = scene()
        s.energy[0].current = 10
        blue, red = s.fighters
        red.x = red.prev_x = blue.x + 55
        s.perform_gesture(0, "slash")
        for _ in range(40):
            s.update(1 / 60)
        self.assertGreater(s.energy[0].current, 10)


class ModifierGestureTests(unittest.TestCase):
    def test_plain_slash_no_modifier(self):
        s = scene()
        s.perform_gesture(0, "slash")
        self.assertEqual(s.fighters[0].attack.spec.name, "slash")
        self.assertFalse(hasattr(s.fighters[0].attack.spec, "special_id") and s.fighters[0].attack.spec.special_id)

    def test_q_plus_each_gesture(self):
        for gesture in ("slash", "sweep", "thrust", "double"):
            s = scene()
            s.energy[0].current = ENERGY_MAX
            s.cooldowns[0].remaining["crush"] = 0
            s.perform_gesture(0, gesture, modifier="crush")
            atk = s.fighters[0].attack
            self.assertIsNotNone(atk, gesture)
            self.assertEqual(atk.spec.name, gesture)
            self.assertEqual(getattr(atk.spec, "special_id", None), "crush")
            self.assertFalse(s.cooldowns[0].ready("crush"))

    def test_e_and_r_modifiers(self):
        for mod in ("launch", "drain"):
            s = scene()
            s.energy[0].current = ENERGY_MAX
            s.perform_gesture(0, "slash", modifier=mod)
            self.assertEqual(getattr(s.fighters[0].attack.spec, "special_id", None), mod)

    def test_no_energy_rejects_special(self):
        s = scene()
        s.energy[0].current = 0
        s.perform_gesture(0, "slash", modifier="crush")
        self.assertIsNone(s.fighters[0].attack)
        self.assertTrue(s.cooldowns[0].ready("crush"))

    def test_cooldown_blocks_special(self):
        s = scene()
        s.energy[0].current = ENERGY_MAX
        s.cooldowns[0].trigger("crush", 5.0)
        s.perform_gesture(0, "slash", modifier="crush")
        self.assertIsNone(s.fighters[0].attack)

    def test_energy_spent_on_special(self):
        s = scene()
        before = s.energy[0].current
        s.perform_gesture(0, "slash", modifier="crush")
        self.assertAlmostEqual(s.energy[0].current, before - ENERGY_COST["crush"], places=1)

    def test_drain_heals_only_on_hit(self):
        s = scene()
        blue, red = s.fighters
        blue.hp = 50
        # miss
        s.perform_gesture(0, "slash", modifier="drain")
        for _ in range(40):
            s.update(1 / 60)
        self.assertEqual(blue.hp, 50)
        # hit
        s.cooldowns[0].remaining["drain"] = 0
        s.energy[0].current = ENERGY_MAX
        red.x = red.prev_x = blue.x + 55
        s.perform_gesture(0, "slash", modifier="drain")
        for _ in range(40):
            s.update(1 / 60)
        self.assertGreater(blue.hp, 50)


class BlockAndInputTests(unittest.TestCase):
    def test_f_block_without_gesture(self):
        s = scene()
        s.perform_special(0, "block")
        self.assertGreater(s.blocking[0], 0)
        self.assertTrue(s.fighters[0].blocking_active)

    def test_q_alone_does_nothing(self):
        s = scene()
        s.perform_special(0, "crush")  # should no-op
        self.assertIsNone(s.fighters[0].attack)
        self.assertTrue(s.cooldowns[0].ready("crush"))

    def test_command_input_modifier_held(self):
        pg = types.SimpleNamespace(
            MOUSEBUTTONDOWN=1, MOUSEBUTTONUP=2, MOUSEMOTION=3, KEYDOWN=4, KEYUP=5,
            K_q=113, K_e=101, K_r=114, K_f=102, K_F5=1073741920,
            K_z=122, K_x=120, K_c=99, K_v=118,
        )
        ci = CommandInput(pg)
        # press Q alone
        ev = types.SimpleNamespace(type=4, key=113)
        self.assertEqual(ci.handle_event(ev, 0.0), [])
        self.assertEqual(ci.active_modifier, "crush")
        # release
        ci.handle_event(types.SimpleNamespace(type=5, key=113), 0.0)
        self.assertIsNone(ci.active_modifier)

    def test_modifier_window_starts_on_keydown_and_expires_after_four_seconds(self):
        pg = types.SimpleNamespace(
            MOUSEBUTTONDOWN=1, MOUSEBUTTONUP=2, MOUSEMOTION=3, KEYDOWN=4, KEYUP=5,
            K_q=113, K_e=101, K_r=114, K_f=102, K_F5=1073741920,
            K_z=122, K_x=120, K_c=99, K_v=118,
        )
        ci = CommandInput(pg)
        ci.handle_event(types.SimpleNamespace(type=4, key=113), 10.0)
        self.assertEqual(ci.active_modifier, "crush")
        self.assertEqual(ci.pending_modifier_info(13.5), ("crush", 0.5))
        self.assertIsNone(ci.pending_modifier_info(14.0))
        # Even while Q remains physically held, a late gesture has no special modifier.
        ci.handle_event(types.SimpleNamespace(type=1, button=1, pos=(100, 100)), 14.1)
        ci.handle_event(types.SimpleNamespace(type=3, buttons=(1,), pos=(200, 50)), 14.2)
        commands = ci.handle_event(types.SimpleNamespace(type=2, button=1, pos=(250, 20)), 14.3)
        self.assertEqual(len(commands), 1)
        self.assertIsNone(commands[0].modifier)

    def test_all_three_effects_have_the_same_four_second_window(self):
        pg = types.SimpleNamespace(
            MOUSEBUTTONDOWN=1, MOUSEBUTTONUP=2, MOUSEMOTION=3, KEYDOWN=4, KEYUP=5,
            K_q=113, K_e=101, K_r=114, K_f=102, K_F5=1073741920,
            K_z=122, K_x=120, K_c=99, K_v=118,
        )
        for keycode, name in ((113, "crush"), (101, "launch"), (114, "drain")):
            ci = CommandInput(pg)
            ci.handle_event(types.SimpleNamespace(type=4, key=keycode), 5.0)
            self.assertEqual(ci.pending_modifier_info(8.0), (name, 1.0))
            self.assertIsNone(ci.pending_modifier_info(9.0))

    def test_modifier_window_is_restarted_by_a_new_key_press(self):
        pg = types.SimpleNamespace(
            MOUSEBUTTONDOWN=1, MOUSEBUTTONUP=2, MOUSEMOTION=3, KEYDOWN=4, KEYUP=5,
            K_q=113, K_e=101, K_r=114, K_f=102, K_F5=1073741920,
            K_z=122, K_x=120, K_c=99, K_v=118,
        )
        ci = CommandInput(pg)
        ci.handle_event(types.SimpleNamespace(type=4, key=113), 1.0)
        ci.handle_event(types.SimpleNamespace(type=5, key=113), 2.0)
        ci.handle_event(types.SimpleNamespace(type=4, key=113), 10.0)
        self.assertEqual(ci.pending_modifier_info(10.5), ("crush", 3.5))

    def test_stroke_carries_modifier(self):
        pg = types.SimpleNamespace(
            MOUSEBUTTONDOWN=1, MOUSEBUTTONUP=2, MOUSEMOTION=3, KEYDOWN=4, KEYUP=5,
            K_q=113, K_e=101, K_r=114, K_f=102, K_F5=1073741920,
            K_z=122, K_x=120, K_c=99, K_v=118,
        )
        ci = CommandInput(pg)
        ci.handle_event(types.SimpleNamespace(type=4, key=113), 0.0)  # hold Q
        ci.handle_event(types.SimpleNamespace(type=1, button=1, pos=(100, 100)), 0.0)
        ci.handle_event(types.SimpleNamespace(type=3, buttons=(1,), pos=(200, 50)), 0.1)
        cmds = ci.handle_event(types.SimpleNamespace(type=2, button=1, pos=(250, 20)), 0.2)
        self.assertEqual(len(cmds), 1)
        self.assertIsInstance(cmds[0], StrokeCommand)
        self.assertEqual(cmds[0].modifier, "crush")


class CooldownValuesTests(unittest.TestCase):
    def test_cooldowns_shorter_than_stage5_initial(self):
        # old: 8, 7, 10 — new must be lower
        self.assertLess(SPECIALS["crush"]["cooldown"], 8.0)
        self.assertLess(SPECIALS["launch"]["cooldown"], 7.0)
        self.assertLess(SPECIALS["drain"]["cooldown"], 10.0)
        self.assertGreater(SPECIALS["crush"]["cooldown"], 1.0)  # not spam


if __name__ == "__main__":
    unittest.main()
