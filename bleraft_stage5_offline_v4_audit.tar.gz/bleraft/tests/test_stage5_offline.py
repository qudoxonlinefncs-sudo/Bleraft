"""Проверка offline-механик Stage 5: жизни, возрождение, арена 4x4, блок, heal, dummy, жесты."""

import unittest

import settings
from arena.arena import Arena
from arena.floor import ArenaFloor
from combat.combo_rush import ComboRush
from combat.specials import BLOCK, SPECIALS
from core.gameplay import GameplayState
from core.match_rules import MatchRules, DRAW, TIME_UP, VICTORY, DEFEAT
from core.match_setup import MODE_TRAINING, build_scene, DUMMY_HP
from entities.fighter import Fighter, FighterState
from input.gesture_recognizer import GestureRecognizer
from tests.helpers import shape_stroke


class Idle:
    def direction(self, i):
        return (0, 0)


def make_fighters(gap=60):
    arena = Arena.from_settings()
    blue = Fighter("blue", arena.center_x - gap, arena.center_y, 36, 280)
    red = Fighter("red", arena.center_x + gap, arena.center_y, 36, 280)
    return arena, blue, red


class LivesAndRespawnTests(unittest.TestCase):
    def test_respawn_takes_about_10_seconds(self):
        arena, blue, red = make_fighters()
        s = GameplayState(Idle(), arena=arena, fighters=[blue, red], rules=MatchRules(0, None))
        blue.lives = 2
        blue.lose_life("ko")
        self.assertEqual(blue.state, FighterState.RESPAWNING)
        self.assertAlmostEqual(blue.respawn_timer, settings.RESPAWN_TIME, places=2)
        # 9.5 с — ещё ждём
        for _ in range(int(9.5 * 60)):
            s.update(1 / 60)
        self.assertEqual(blue.state, FighterState.RESPAWNING)
        # ещё ~1 с
        for _ in range(60):
            s.update(1 / 60)
        self.assertEqual(blue.state, FighterState.IDLE)
        self.assertEqual(blue.lives, 1)
        self.assertEqual(blue.hp, blue.max_hp)

    def test_dead_fighter_has_no_hitbox_and_takes_no_damage(self):
        arena, blue, red = make_fighters()
        s = GameplayState(Idle(), arena=arena, fighters=[blue, red])
        red.lose_life("ko")  # RESPAWNING, lives left
        self.assertFalse(red.alive)
        hp = red.hp
        blue.x = red.x - 50
        s.perform_gesture(0, "slash")
        for _ in range(30):
            s.update(1 / 60)
        # мёртвый/возрождающийся не должен получать урон
        self.assertEqual(red.hp, hp)

    def test_dead_fighter_cannot_attack(self):
        arena, blue, red = make_fighters()
        s = GameplayState(Idle(), arena=arena, fighters=[blue, red])
        red.lose_life("ko")
        result = s.perform_gesture(1, "slash")
        self.assertNotEqual(getattr(result, "value", result), "started")
        self.assertIsNone(red.attack)

    def test_safe_respawn_prefers_center_if_spawn_unsafe(self):
        arena = Arena.from_settings()
        floor = ArenaFloor(arena, enabled=True, min_cols=4, min_rows=4)
        arena.attach_floor(floor)
        blue = Fighter("blue", arena.left + 15, arena.center_y, 36, 280)  # у края
        red = Fighter("red", arena.center_x, arena.center_y, 36, 280)
        s = GameplayState(Idle(), arena=arena, fighters=[blue, red])
        # обрушить внешние кольца
        for _ in range(int(90 * 60)):
            s.update(1 / 60)
        blue.lives = 2
        blue.lose_life("ring_out")
        for _ in range(int(settings.RESPAWN_TIME * 60) + 5):
            s.update(1 / 60)
        self.assertEqual(blue.state, FighterState.IDLE)
        self.assertTrue(floor.is_safe(blue.x, blue.y))


class ArenaCenterTests(unittest.TestCase):
    def test_center_4x4_never_destroyed(self):
        arena = Arena.from_settings()
        floor = ArenaFloor(arena, enabled=True, min_cols=4, min_rows=4)
        arena.attach_floor(floor)
        for _ in range(floor.max_rings):
            for __ in range(int(30 * 60)):
                floor.update(1 / 60)
        l, t, r, b = arena.bounds
        cols = (r - l) // 30
        rows = (b - t) // 30
        self.assertEqual((cols, rows), (4, 4))
        cx, cy = arena.center_x, arena.center_y
        self.assertTrue(floor.is_safe(cx, cy))


class BlockAndHealTests(unittest.TestCase):
    def test_block_window_duration(self):
        arena, blue, red = make_fighters()
        s = GameplayState(Idle(), arena=arena, fighters=[blue, red])
        s.perform_special(0, "block")
        self.assertAlmostEqual(s.blocking[0], BLOCK["window"], places=2)
        steps = int(BLOCK["window"] * 60) - 1
        for _ in range(steps):
            s.update(1 / 60)
        self.assertTrue(blue.blocking_active)
        s.update(1 / 60)
        s.update(1 / 60)
        self.assertFalse(blue.blocking_active)

    def test_heal_only_on_successful_hit(self):
        arena, blue, red = make_fighters(gap=200)  # далеко — промах
        s = GameplayState(Idle(), arena=arena, fighters=[blue, red])
        blue.hp = 40.0
        s.perform_gesture(0, "slash", modifier="drain")
        for _ in range(40):
            s.update(1 / 60)
        self.assertEqual(blue.hp, 40.0)  # без попадания нет heal
        # теперь в упор
        red.x = red.prev_x = blue.x + 55
        red.y = red.prev_y = blue.y
        s.cooldowns[0].remaining["drain"] = 0.0
        s.energy[0].current = 100.0
        s.perform_gesture(0, "slash", modifier="drain")
        for _ in range(40):
            s.update(1 / 60)
        self.assertGreater(blue.hp, 40.0)


class GestureAndComboStillWork(unittest.TestCase):
    def test_four_gestures_still_work(self):
        arena, blue, red = make_fighters()
        s = GameplayState(Idle(), arena=arena, fighters=[blue, red])
        for name in ("slash", "sweep", "thrust", "double"):
            # ждём recovery
            for _ in range(90):
                s.update(1 / 60)
            s.perform_gesture(0, name)
            self.assertIsNotNone(blue.attack)
            self.assertEqual(blue.attack.spec.name, name)

    def test_combo_rush_still_counts_gestures(self):
        arena, blue, red = make_fighters()
        s = GameplayState(Idle(), arena=arena, fighters=[blue, red])
        for i in range(3):
            for _ in range(90):
                s.update(1 / 60)
            s.perform_gesture(0, "slash")
        self.assertGreaterEqual(s.rush[0].count, 3)
        self.assertTrue(s.rush[0].combo_active)


class TrainingStatsIsolation(unittest.TestCase):
    def test_dummy_damage_not_in_match_stats_file(self):
        from core.profile import Profile, Storage
        import tempfile
        from core.match_rules import MatchResult
        tmp = tempfile.mkdtemp()
        p = Profile(Storage(tmp))
        # имитация: тренировка не пишет
        r = MatchResult("victory", "ko", 5.0, 100, 0, stats={"damage_dealt": 500})
        self.assertIsNone(p.record_match(r, "training", "normal"))
        self.assertEqual(len(p.matches), 0)


if __name__ == "__main__":
    unittest.main()
