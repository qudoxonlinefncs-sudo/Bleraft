"""Stage 5: тренировочный манекен."""

import unittest

from core.match_setup import MODE_TRAINING, build_scene, DUMMY_HP
from core.match_rules import MatchRules
from entities.fighter import FighterState


class FakeCtx:
    def __init__(self, pg):
        self.pygame = pg
        from core.profile import Profile, Storage
        import tempfile, os
        self._tmp = tempfile.mkdtemp()
        self.profile = Profile(Storage(self._tmp))
        self.font = None


class TrainingDummyTests(unittest.TestCase):
    def setUp(self):
        from tests.fake_pygame import FakePygame
        self.pg = FakePygame()
        self.ctx = FakeCtx(self.pg)

    def scene(self):
        return build_scene(self.ctx, mode=MODE_TRAINING)

    def test_dummy_is_immobile_and_high_hp(self):
        s = self.scene()
        self.assertEqual(len(s.fighters), 2)
        dummy = s.fighters[1]
        self.assertTrue(dummy.is_dummy)
        self.assertTrue(dummy.no_knockback)
        self.assertEqual(dummy.speed, 0.0)
        self.assertGreaterEqual(dummy.max_hp, 1000)
        self.assertIsNone(s.rules)
        self.assertFalse(s.floor.enabled)

    def test_dummy_takes_damage_without_knockback(self):
        s = self.scene()
        player, dummy = s.fighters
        dummy.x = dummy.prev_x = player.x + 55
        dummy.y = dummy.prev_y = player.y
        before = (dummy.x, dummy.y)
        s.perform_gesture(0, "slash")
        for _ in range(30):
            s.update(1 / 60)
        self.assertLess(dummy.hp, dummy.max_hp)
        self.assertEqual((dummy.x, dummy.y), before)
        self.assertEqual(dummy.knock_vx, 0.0)
        self.assertGreater(s.stats.damage_dealt, 0)

    def test_dummy_hp_restores_at_zero(self):
        s = self.scene()
        dummy = s.fighters[1]
        dummy.hp = 1.0
        player = s.fighters[0]
        dummy.x = dummy.prev_x = player.x + 55
        dummy.y = dummy.prev_y = player.y
        s.perform_gesture(0, "slash")
        for _ in range(30):
            s.update(1 / 60)
        self.assertEqual(dummy.hp, float(dummy.max_hp))
        self.assertEqual(dummy.state, FighterState.IDLE)

    def test_training_has_no_time_limit_or_match_end(self):
        s = self.scene()
        for _ in range(60 * 5):
            s.update(1 / 60)
        self.assertIsNone(s.result)
        self.assertGreater(s.time, 4.0)

    def test_training_does_not_record_stats(self):
        from core.profile import Profile, Storage
        import tempfile
        from core.match_rules import MatchResult
        tmp = tempfile.mkdtemp()
        p = Profile(Storage(tmp))
        r = MatchResult("victory", "ko", 10.0, 100.0, 0.0, stats={})
        self.assertIsNone(p.record_match(r, "training", "normal"))
        self.assertEqual(p.summary()["played"], 0)
        self.assertEqual(p.summary()["training"], 0)


if __name__ == "__main__":
    unittest.main()
