"""Прогон ВСЕГО приложения через настоящий Game.run() на подделке pygame.

Сценарий - генератор: на каждый кадр он отдаёт события (мышь, клавиши) и между
кадрами проверяет состояние. Поток: главное меню -> лобби -> отсчёт -> бой ->
победа -> реванш -> пауза -> лобби -> главное меню -> выход.
"""

import shutil
import sys
import tempfile
import unittest

from app import build_game
from core.flow import Phase
from tests.fake_pygame import (
    FakePygame, key_down, mouse_down, mouse_move, mouse_up, quit_event,
)


class AppTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.pg = FakePygame()
        sys.modules["pygame"] = self.pg       # Game.run() импортирует pygame сам
        self.addCleanup(sys.modules.pop, "pygame", None)
        self.game, self.ctx = build_game(self.pg, self.tmp)
        self.flow = self.ctx.flow

    # --- запуск сценария: один настоящий Game.run() ---

    def play(self, scenario, max_frames=6000):
        gen = scenario()
        frames = {"n": 0}

        def script(frame):
            frames["n"] += 1
            assert frames["n"] < max_frames, "сценарий завис"
            events = next(gen, None)
            return [quit_event()] if events is None else events

        self.pg.script = script
        self.game.run()

    # --- шаги сценария (генераторы) ---

    def wait(self, n):
        for _ in range(n):
            yield []

    def press(self, name, settle=30):
        yield [key_down(self.pg, name)]
        yield from self.wait(settle)

    def wait_phase(self, phase, limit=900):
        for _ in range(limit):
            if self.flow.phase is phase and not self.flow.transitioning:
                return
            yield []
        self.fail("не дождались фазы %s (сейчас %s)" % (phase, self.flow.phase))

    def draw_slash(self, x0=300, y0=520, frames=20, step=14):
        pts = [(x0 + i * step, y0 - i * step) for i in range(frames)]
        yield [mouse_down(*pts[0])]
        for p in pts[1:-1]:
            yield [mouse_move(*p)]
        yield [mouse_up(*pts[-1])]

    @property
    def screen(self):
        return self.flow.current


class AppFlowTests(AppTestCase):
    def test_full_game_cycle(self):
        def scenario():
            # --- запуск: главное меню ---
            yield from self.wait(30)
            self.assertEqual(self.flow.phase, Phase.MAIN_MENU)
            self.assertEqual(self.pg.screen.size, (1280, 720))

            # --- ИГРАТЬ -> лобби ---
            yield from self.press("K_RETURN")
            self.assertEqual(self.flow.phase, Phase.LOBBY)

            # --- В БОЙ -> отсчёт -> бой ---
            yield [key_down(self.pg, "K_RETURN")]
            yield from self.wait_phase(Phase.MATCH_START)
            yield from self.wait_phase(Phase.FIGHT)
            scene = self.screen.scene
            self.assertEqual(scene.fighters[0].hp, 100)

            # --- бой идёт: бот самостоятельно двигается ---
            bot_start = (scene.fighters[1].x, scene.fighters[1].y)
            yield from self.wait(90)
            self.assertNotEqual(bot_start, (scene.fighters[1].x, scene.fighters[1].y))
            self.assertGreater(scene.time, 1.0)

            # --- настоящий жест мышью `/` по почти побеждённому боту ---
            scene.controllers = {}                   # бот стоит: цель предсказуема
            me, bot = scene.fighters
            me.x, me.y = 600.0, 360.0
            bot.x, bot.y = 660.0, 360.0
            bot.hp = 1.0
            bot.lives = bot.max_lives = 1
            yield from self.draw_slash()
            yield from self.wait(60)
            self.assertEqual(self.flow.phase, Phase.VICTORY)
            self.assertEqual(scene.result.reason, "ko")
            self.assertEqual(len(self.ctx.profile.matches), 1)

            # --- победа: бой остановлен ---
            frozen = (me.x, me.y, bot.x, bot.y, scene.time)
            yield from self.wait(30)
            self.assertEqual((me.x, me.y, bot.x, bot.y, scene.time), frozen)

            # --- РЕВАНШ: новый чистый матч ---
            yield from self.wait(40)                 # задержка ввода на экране результата
            yield [key_down(self.pg, "K_RETURN")]
            yield from self.wait_phase(Phase.MATCH_START)
            fresh = self.screen.scene
            self.assertIsNot(fresh, scene)
            self.assertEqual([f.hp for f in fresh.fighters], [100.0, 100.0])
            self.assertEqual(fresh.time, 0.0)
            self.assertEqual(fresh.floor.rings_fallen, 0)
            self.assertEqual(fresh.stats.damage_dealt, 0.0)
            self.assertTrue(all(not r.active for r in fresh.rush))
            yield from self.wait_phase(Phase.FIGHT)

            # --- пауза: время стоит ---
            yield from self.press("K_ESCAPE", settle=3)
            self.assertTrue(self.screen.paused)
            t_pause = fresh.time
            yield from self.wait(30)
            self.assertEqual(fresh.time, t_pause)

            # --- В ЛОББИ из паузы ---
            yield from self.press("K_s", settle=2)
            yield from self.press("K_RETURN", settle=40)
            self.assertEqual(self.flow.phase, Phase.LOBBY)

            # --- НАЗАД -> главное меню ---
            yield from self.press("K_ESCAPE", settle=40)
            self.assertEqual(self.flow.phase, Phase.MAIN_MENU)

            # --- ВЫХОД (пятая кнопка) ---
            for _ in range(4):
                yield from self.press("K_s", settle=2)
            yield [key_down(self.pg, "K_RETURN")]
            yield from self.wait(60)
            self.fail("игра должна была завершиться по кнопке ВЫХОД")

        self.play(scenario)
        self.assertTrue(self.pg.quit_called)

    def test_defeat_is_decided_by_real_match_state_and_recorded(self):
        def scenario():
            yield from self.wait(5)
            self.flow.go("match", mode="match", difficulty="easy")
            yield from self.wait_phase(Phase.FIGHT)
            scene = self.screen.scene
            self.assertIsNone(scene.result)
            # игрок получает смертельный урон в бою (бот бьёт), а не по таймеру
            scene.controllers = {}
            me, bot = scene.fighters
            me.hp = 1.0
            me.lives = me.max_lives = 1
            bot.x, bot.y = me.x + 60, me.y
            scene.perform_gesture(1, "slash", "medium")
            yield from self.wait(60)
            self.assertEqual(self.flow.phase, Phase.DEFEAT)
            self.assertEqual(scene.result.outcome, "defeat")
            summary = self.ctx.profile.summary()
            self.assertEqual((summary["played"], summary["wins"], summary["losses"]), (1, 0, 1))
            yield from self.wait(40)
            self.flow.go("stats")
            yield from self.wait_phase(Phase.STATS)
            self.assertEqual(self.screen.summary["played"], 1)
            yield from self.wait(5)

        self.play(scenario)

    def test_training_has_no_time_limit_and_no_collapse(self):
        def scenario():
            yield from self.wait(5)
            self.flow.go("match", mode="training", difficulty="normal")
            yield from self.wait_phase(Phase.FIGHT)
            scene = self.screen.scene
            self.assertIsNone(scene.rules)  # Stage 5: no match rules in training
            self.assertFalse(scene.floor.enabled)
            scene.update(300.0 / 60)          # 5 минут игрового времени
            self.assertIsNone(scene.result)
            yield from self.wait(3)

        self.play(scenario)

    def test_bot_match_runs_for_a_while_without_errors(self):
        def scenario():
            yield from self.wait(5)
            self.flow.go("match", mode="match", difficulty="hard")
            yield from self.wait_phase(Phase.FIGHT)
            yield from self.wait(600)
            self.assertIn(self.flow.phase, (Phase.FIGHT, Phase.DEFEAT, Phase.VICTORY))

        self.play(scenario)

    def test_window_close_event_stops_game_from_any_screen(self):
        def scenario():
            yield from self.wait(5)
            yield [quit_event()]
            self.fail("игра должна была завершиться")

        self.play(scenario)
        self.assertTrue(self.pg.quit_called)

    def test_main_function_starts_the_game(self):
        import app
        import main
        fake = FakePygame()
        fake.script = lambda frame: [quit_event()] if frame >= 20 else []
        sys.modules["pygame"] = fake
        original = app.build_game
        app.build_game = lambda pg, storage_dir=None: original(pg, self.tmp)
        self.addCleanup(setattr, app, "build_game", original)
        self.assertEqual(main.main(), 0)
        self.assertTrue(fake.quit_called)
        self.assertEqual(fake.screen.size, (1280, 720))


if __name__ == "__main__":
    unittest.main()
