import types
import unittest

from input.command_input import CommandInput
from input.commands import AttackKeyCommand, ResetCommand, StrokeCommand
from input.gesture_recorder import GestureRecorder


def fake_pygame():
    return types.SimpleNamespace(
        MOUSEBUTTONDOWN=1, MOUSEBUTTONUP=2, MOUSEMOTION=3, KEYDOWN=4,
        K_r=114, K_z=122, K_x=120, K_c=99, K_v=118, K_q=113, K_e=101, K_f=102, K_F5=1073741920,
    )


def down(x, y, button=1):
    return types.SimpleNamespace(type=1, pos=(x, y), button=button)


def up(x, y, button=1):
    return types.SimpleNamespace(type=2, pos=(x, y), button=button)


def move(x, y, left=True):
    return types.SimpleNamespace(type=3, pos=(x, y), buttons=(1 if left else 0, 0, 0))


def key(k):
    return types.SimpleNamespace(type=4, key=k)


class CommandInputTests(unittest.TestCase):
    def setUp(self):
        self.ci = CommandInput(fake_pygame(), recorder=GestureRecorder(spacing=1.0))

    def test_draw_gesture_with_left_button(self):
        self.assertEqual(self.ci.handle_event(down(100, 400), 1.0), [])
        self.assertTrue(self.ci.recorder.active)
        self.assertEqual(self.ci.handle_event(move(200, 300), 1.1), [])
        self.assertEqual(self.ci.handle_event(move(300, 200), 1.2), [])
        commands = self.ci.handle_event(up(400, 100), 1.3)
        self.assertEqual(len(commands), 1)
        cmd = commands[0]
        self.assertIsInstance(cmd, StrokeCommand)
        self.assertEqual(cmd.player_index, 0)
        self.assertEqual([p[2] for p in cmd.stroke.points], [1.0, 1.1, 1.2, 1.3])
        self.assertFalse(self.ci.recorder.active)

    def test_right_button_does_not_draw(self):
        self.ci.handle_event(down(0, 0, button=3), 0.0)
        self.assertFalse(self.ci.recorder.active)
        self.assertEqual(self.ci.handle_event(up(5, 5, button=3), 0.1), [])

    def test_motion_without_drawing_is_ignored(self):
        self.assertEqual(self.ci.handle_event(move(10, 10), 0.0), [])
        self.assertEqual(self.ci.recorder.points, [])

    def test_release_outside_window_is_detected_by_motion_without_button(self):
        self.ci.handle_event(down(0, 0), 0.0)
        self.ci.handle_event(move(50, 0), 0.1)
        commands = self.ci.handle_event(move(90, 0, left=False), 0.2)
        self.assertEqual(len(commands), 1)
        self.assertFalse(self.ci.recorder.active)

    def test_button_up_without_down_gives_nothing(self):
        self.assertEqual(self.ci.handle_event(up(1, 1), 0.0), [])

    def test_second_press_restarts_gesture(self):
        self.ci.handle_event(down(0, 0), 0.0)
        self.ci.handle_event(move(100, 0), 0.1)
        self.ci.handle_event(down(500, 500), 1.0)
        self.assertEqual(len(self.ci.recorder.points), 1)

    def test_attack_keys_for_second_player(self):
        # Keyboard attacks only when explicitly enabled (local PvP); not in PvE
        self.ci.enable_keyboard_attacks = True
        self.ci.attack_keys = {1: {122: "slash", 120: "sweep", 99: "thrust", 118: "double"}}
        for code, gesture in ((122, "slash"), (120, "sweep"), (99, "thrust"), (118, "double")):
            commands = self.ci.handle_event(key(code), 0.0)
            self.assertEqual(commands, [AttackKeyCommand(1, gesture, None)])

    def test_reset_key(self):
        self.assertEqual(self.ci.handle_event(key(1073741920), 0.0), [ResetCommand()])  # F5

    def test_unrelated_events_are_ignored(self):
        self.assertEqual(self.ci.handle_event(key(1), 0.0), [])
        self.assertEqual(self.ci.handle_event(types.SimpleNamespace(type=999), 0.0), [])

    def test_custom_mouse_player_and_keys(self):
        ci = CommandInput(fake_pygame(), mouse_player=1, attack_keys={0: {5: "thrust"}}, enable_keyboard_attacks=True)
        ci.handle_event(down(0, 0), 0.0)
        ci.handle_event(move(100, 0), 0.1)
        cmd = ci.handle_event(up(200, 0), 0.2)[0]
        self.assertEqual(cmd.player_index, 1)
        self.assertEqual(ci.handle_event(key(5), 0.0), [AttackKeyCommand(0, "thrust", None)])


if __name__ == "__main__":
    unittest.main()
