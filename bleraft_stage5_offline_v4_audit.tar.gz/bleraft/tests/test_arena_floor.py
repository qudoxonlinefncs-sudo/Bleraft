import unittest

import settings
from arena.arena import Arena
from arena.floor import CRACKED, FALLING, GONE, INTACT, ArenaFloor
from core.gameplay import GameplayState, create_fighters
from core.match_rules import MatchRules
from entities.fighter import Fighter, FighterState as S
from physics.collision import limit_motion


def make_floor(**kw):
    arena = Arena.from_settings()
    floor = ArenaFloor(arena, tile_size=30, **kw)
    arena.attach_floor(floor)
    return arena, floor


def advance(floor, seconds, dt=1 / 60):
    for _ in range(int(round(seconds / dt))):
        floor.update(dt)


class FloorScheduleTests(unittest.TestCase):
    def test_grid_and_ring_sizes(self):
        arena, floor = make_floor()
        self.assertEqual((floor.cols, floor.rows), (32, 18))
        self.assertEqual(len(floor.ring_tiles(0)), 2 * (32 + 18) - 4)
        self.assertEqual(len(floor.ring_tiles(1)), 2 * (30 + 16) - 4)
        self.assertEqual(floor.max_rings, 14)        # 32x18 -> center 4x4 Stage 5

    def test_invalid_tile_size_is_rejected(self):
        with self.assertRaises(ValueError):
            ArenaFloor(Arena(0, 0, 100, 100), tile_size=30)

    def test_everything_is_safe_at_start_and_bounds_equal_arena(self):
        arena, floor = make_floor()
        self.assertEqual(arena.bounds, (arena.left, arena.top, arena.right, arena.bottom))
        self.assertTrue(floor.is_safe(arena.center_x, arena.center_y))
        self.assertTrue(floor.is_safe(arena.left + 1, arena.top + 1))
        self.assertFalse(floor.is_safe(arena.left - 1, arena.center_y))
        self.assertFalse(floor.is_safe(arena.center_x, arena.bottom + 1))

    def test_cracks_appear_three_seconds_before_the_collapse(self):
        arena, floor = make_floor()
        advance(floor, 26.9)
        self.assertFalse(floor.warning_active)
        self.assertEqual(floor.tiles_in_state(CRACKED), [])
        advance(floor, 0.2)                           # 27.1 с
        self.assertTrue(floor.warning_active)
        self.assertEqual(set(floor.tiles_in_state(CRACKED)), set(floor.ring_tiles(0)))

    def test_cracked_tiles_are_still_safe_to_stand_on(self):
        arena, floor = make_floor()
        advance(floor, 28.0)
        self.assertTrue(floor.is_safe(arena.left + 5, arena.top + 5))     # угловая плитка
        self.assertEqual(arena.bounds, (arena.left, arena.top, arena.right, arena.bottom))

    def test_collapse_at_thirty_seconds_moves_the_border_inside(self):
        arena, floor = make_floor()
        advance(floor, 29.9)
        self.assertEqual(arena.bounds[0], arena.left)
        advance(floor, 0.2)                           # 30.1 с
        self.assertEqual(set(floor.tiles_in_state(FALLING)), set(floor.ring_tiles(0)))
        self.assertEqual(arena.bounds, (arena.left + 30, arena.top + 30, arena.right - 30, arena.bottom - 30))
        self.assertFalse(floor.is_safe(arena.left + 5, arena.top + 5))     # падающая плитка небезопасна
        self.assertTrue(floor.is_safe(arena.left + 35, arena.top + 35))

    def test_fallen_tiles_become_gone_after_fall_time(self):
        arena, floor = make_floor()
        advance(floor, 30.0 + settings.COLLAPSE_FALL_TIME + 0.1)
        self.assertEqual(floor.tiles_in_state(FALLING), [])
        self.assertEqual(len(floor.tiles_in_state(GONE)), len(floor.ring_tiles(0)))

    def test_every_thirty_seconds_another_ring_until_minimum(self):
        arena, floor = make_floor()
        sizes = []
        # сжимаем, пока не останется центральная 4x4
        for ring in range(floor.max_rings):
            advance(floor, 30.0)
            l, top, r, b = arena.bounds
            sizes.append(((r - l) // 30, (b - top) // 30))
        self.assertEqual(sizes[0], (30, 16))
        self.assertEqual(sizes[-1], (4, 4))                 # Stage 5 min 4x4
        self.assertIsNone(floor.time_to_collapse)
        # центр 4x4 никогда не уходит ниже
        for cols, rows in sizes:
            self.assertGreaterEqual(cols, 4)
            self.assertGreaterEqual(rows, 4)

    def test_schedule_does_not_depend_on_frame_rate(self):
        results = []
        for dt in (1 / 30, 1 / 60, 1 / 144, 1 / 240):
            arena, floor = make_floor()
            advance(floor, 75.0, dt)
            results.append((arena.bounds, len(floor.tiles_in_state(CRACKED)),
                            len(floor.tiles_in_state(GONE)), floor.rings_fallen))
        self.assertEqual(len(set(results)), 1)

    def test_time_to_collapse_counts_down(self):
        arena, floor = make_floor()
        advance(floor, 10.0)
        self.assertAlmostEqual(floor.time_to_collapse, 20.0, delta=0.05)

    def test_version_changes_only_when_tiles_change(self):
        arena, floor = make_floor()
        v = floor.version
        advance(floor, 5.0)
        self.assertEqual(floor.version, v)
        advance(floor, 23.0)
        self.assertGreater(floor.version, v)

    def test_events_for_sound_and_effects(self):
        arena, floor = make_floor()
        seen = []
        for _ in range(int(31 * 60)):
            floor.update(1 / 60)
            seen += floor.events
        self.assertEqual(seen, ["crack", "fall"])

    def test_disabled_floor_never_changes(self):
        arena, floor = make_floor(enabled=False)
        advance(floor, 200.0)
        self.assertEqual(floor.tiles_in_state(INTACT), [(r, c) for r in range(18) for c in range(32)])

    def test_reset_restores_a_fresh_floor(self):
        arena, floor = make_floor()
        advance(floor, 70.0)
        floor.reset()
        self.assertEqual((floor.time, floor.rings_fallen), (0.0, 0))
        self.assertEqual(arena.bounds, (arena.left, arena.top, arena.right, arena.bottom))
        self.assertEqual(floor.tiles_in_state(GONE), [])

    def test_fall_progress(self):
        arena, floor = make_floor()
        advance(floor, 30.0 + settings.COLLAPSE_FALL_TIME / 2)
        tile = floor.ring_tiles(0)[0]
        self.assertAlmostEqual(floor.fall_progress(tile), 0.5, delta=0.05)


class LimitMotionTests(unittest.TestCase):
    def test_inside_is_free_and_edges_stop_movement(self):
        self.assertEqual(limit_motion(50, 60, 0, 100), 60)
        self.assertEqual(limit_motion(95, 120, 0, 100), 100)
        self.assertEqual(limit_motion(5, -20, 0, 100), 0)

    def test_outside_object_is_not_pulled_back_but_cannot_go_further(self):
        self.assertEqual(limit_motion(130, 140, 0, 100), 130)       # дальше наружу нельзя
        self.assertEqual(limit_motion(130, 120, 0, 100), 120)       # внутрь можно
        self.assertEqual(limit_motion(-30, -50, 0, 100), -30)

    def test_region_smaller_than_object_centers_it(self):
        self.assertEqual(limit_motion(0, 5, 60, 40), 50)


class WallsAndRingOutTests(unittest.TestCase):
    def scene(self, rules=None):
        arena, floor = make_floor()
        fighters = create_fighters(arena)

        class NoMove:
            def direction(self, i):
                return (0, 0)

        s = GameplayState(NoMove(), arena=arena, fighters=fighters, rules=rules)
        return s, arena, floor

    def test_walking_into_the_border_stops_and_does_not_fall(self):
        s, arena, floor = self.scene()
        me = s.fighters[0]
        s.input = type("I", (), {"direction": staticmethod(lambda i: (-1, 0) if i == 0 else (0, 0))})()
        for _ in range(60 * 6):        # раньше первого предупреждения
            s.update(1 / 60)
        self.assertTrue(me.alive)
        self.assertFalse(me.ring_out)
        self.assertAlmostEqual(me.x - 18, arena.bounds[0], places=6)       # упёрся в границу

    def test_walls_do_not_let_fighter_walk_off_in_any_direction(self):
        for direction in ((1, 0), (0, 1), (0, -1), (1, 1), (-1, -1)):
            s, arena, floor = self.scene()
            s.input = type("I", (), {"direction": staticmethod(lambda i, d=direction: d if i == 0 else (0, 0))})()
            for _ in range(60 * 8):    # раньше первого предупреждения
                s.update(1 / 60)
            self.assertTrue(s.fighters[0].alive, direction)

    def test_border_shifts_inward_after_collapse_and_blocks_at_new_position(self):
        s, arena, floor = self.scene()
        me = s.fighters[0]
        me.x = me.prev_x = arena.left + 300          # стоит в центре, на внешнее кольцо не заходит
        for _ in range(int(31 * 60)):
            s.update(1 / 60)
        self.assertEqual(arena.bounds[0], arena.left + 30)
        s.input = type("I", (), {"direction": staticmethod(lambda i: (-1, 0) if i == 0 else (0, 0))})()
        for _ in range(3 * 60):
            s.update(1 / 60)
        self.assertTrue(me.alive)
        self.assertAlmostEqual(me.x - 18, arena.left + 30, places=6)    # новая граница - новая стена

    def test_knockback_over_the_edge_is_a_ring_out(self):
        s, arena, floor = self.scene()
        blue, red = s.fighters
        red.x = red.prev_x = arena.right - 30.0
        blue.x = blue.prev_x = red.x - 60
        red.y = blue.y = red.prev_y = blue.prev_y = arena.center_y
        s.perform_gesture(0, "thrust", "slow")
        for _ in range(120):
            s.update(1 / 60)
        self.assertTrue(red.ring_out)
        self.assertFalse(red.alive)
        self.assertIn(red.state, (S.DEAD, S.RESPAWNING))
        self.assertTrue(blue.alive)
        self.assertIn("ringout", s.sound_events)

    def test_wall_does_not_drag_a_knocked_out_fighter_back(self):
        arena, floor = make_floor()
        f = Fighter("blue", arena.right - 20.0, arena.center_y, 36, 280.0)
        f.knock_vx = 600.0
        for _ in range(30):
            f.update(1 / 60, (0, 0), arena.bounds, knock_through=True)
        self.assertGreater(f.x, arena.right)                         # вылетел за край, не прижат стеной

    def test_default_mode_still_clamps_everything_stage2_behaviour(self):
        arena = Arena(0, 0, 300, 200)
        f = Fighter("blue", 280.0, 100.0, 36, 280.0)
        f.knock_vx = 900.0
        for _ in range(30):
            f.update(1 / 60, (0, 0), arena.bounds)
        self.assertLessEqual(f.x + 18, 300)

    def test_standing_on_a_collapsing_ring_is_a_ring_out_after_the_warning(self):
        s, arena, floor = self.scene()
        me = s.fighters[0]
        me.x = me.prev_x = arena.left + 18
        me.y = me.prev_y = arena.center_y
        for _ in range(int(29 * 60)):                  # предупреждение идёт, но можно стоять
            s.update(1 / 60)
        self.assertTrue(me.alive)
        for _ in range(int(2 * 60)):
            s.update(1 / 60)
        self.assertTrue(me.ring_out)

    def test_player_has_time_to_run_to_safety_during_the_warning(self):
        s, arena, floor = self.scene()
        me = s.fighters[0]
        me.x = me.prev_x = arena.left + 18
        me.y = me.prev_y = arena.center_y
        run_until = int(28.0 * 60)                     # бежит вправо, когда уже идёт предупреждение
        for i in range(int(33 * 60)):
            go = (1, 0) if 28.0 * 60 <= i < 28.0 * 60 + 90 else (0, 0)
            s.input = type("I", (), {"direction": staticmethod(lambda idx, d=go: d if idx == 0 else (0, 0))})()
            s.update(1 / 60)
        self.assertTrue(me.alive)
        self.assertGreater(me.x - 18, arena.left + 30)

    def test_ring_out_decides_the_match(self):
        s, arena, floor = self.scene(rules=MatchRules(0, None))
        for f in s.fighters:
            f.lives = f.max_lives = 1
        red = s.fighters[1]
        red.x = red.prev_x = arena.right - 20.0
        red.knock_vx = 800.0
        for _ in range(120):
            s.update(1 / 60)
        self.assertEqual((s.result.outcome, s.result.reason), ("victory", "ring_out"))

    def test_fall_animation_timer_runs_for_ring_out_fighter(self):
        s, arena, floor = self.scene()
        red = s.fighters[1]
        red.x = red.prev_x = arena.right - 20.0
        red.knock_vx = 800.0
        for _ in range(90):
            s.update(1 / 60)
        self.assertGreater(red.ring_out_time, 0.0)


if __name__ == "__main__":
    unittest.main()
