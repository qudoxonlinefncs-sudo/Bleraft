"""HUD матча: таймер, жизни, возрождение, предупреждение об обрушении, Combo Rush."""

from ui import palette


def format_time(seconds):
    seconds = max(0, int(seconds + 0.999))
    return "%d:%02d" % (seconds // 60, seconds % 60)


class MatchHud:
    def __init__(self, pygame, font):
        self._pg = pygame
        self._font = font

    def draw(self, surface, scene, time_limit=None, names=("ИГРОК", "БОТ")):
        arena = scene.arena
        f = self._font
        # подписи над полосками здоровья
        f.draw(surface, names[0], int(arena.left), 12, 2, palette.HP_FILL["blue"], palette.RIM_DARK)
        f.draw(surface, names[1], int(arena.right), 12, 2, palette.HP_FILL["red"],
               palette.RIM_DARK, anchor="topright")
        # жизни под именами
        self._draw_lives(surface, scene)
        # таймер
        if time_limit is None:
            f.draw(surface, "ТРЕНИРОВКА", 640, 10, 2, palette.UI_DIM, palette.RIM_DARK, "midtop")
        else:
            left = time_limit - scene.time
            color = palette.UI_RED if left < 30 else palette.UI_TEXT
            f.draw(surface, format_time(left), 640, 8, 4, color, palette.RIM_DARK, "midtop")
        self._draw_collapse(surface, scene)
        self._draw_respawn_timers(surface, scene)
        for index, rush in enumerate(scene.rush):
            self._draw_rush(surface, scene, index, rush)
        self._draw_energy(surface, scene)
        self._draw_special_cooldowns(surface, scene)
        self._draw_modifier_prompt(surface, scene)
        self._draw_control_hint(surface, scene)

    def _draw_lives(self, surface, scene):
        """Индикаторы жизней: заполненные / пустые ромбы рядом с именем."""
        pg, f = self._pg, self._font
        arena = scene.arena
        for index, fighter in enumerate(scene.fighters):
            if getattr(fighter, "is_dummy", False):
                continue
            max_l = max(1, getattr(fighter, "max_lives", 3))
            cur = max(0, getattr(fighter, "lives", max_l))
            left_side = index == 0
            # под полоской HP
            base_x = int(arena.left) + 4 if left_side else int(arena.right) - 4
            y = 56
            size = 10
            gap = 14
            for i in range(max_l):
                if left_side:
                    cx = base_x + i * gap + size // 2
                else:
                    cx = base_x - i * gap - size // 2
                filled = i < cur
                color = palette.HP_FILL[fighter.team] if filled else palette.HP_BACK
                # ромб
                pts = [(cx, y), (cx + size // 2, y + size // 2),
                       (cx, y + size), (cx - size // 2, y + size // 2)]
                pg.draw.polygon(surface, color, pts)
                pg.draw.polygon(surface, palette.HP_BORDER, pts, 1)

    def _draw_respawn_timers(self, surface, scene):
        """Таймер возрождения над бойцом, если он в RESPAWNING."""
        from entities.fighter import FighterState
        f = self._font
        for fighter in scene.fighters:
            if fighter.state is not FighterState.RESPAWNING:
                continue
            left = max(0.0, fighter.respawn_timer)
            text = "ВОЗРОЖДЕНИЕ %d" % int(left + 0.999)
            x, y = int(fighter.x), int(fighter.y - fighter.height // 2 - 28)
            f.draw(surface, text, x, y, 2, palette.UI_GOLD, palette.RIM_DARK, "center")

    def _draw_collapse(self, surface, scene):
        floor = scene.floor
        if floor is None or not floor.has_next_ring:
            return
        left = floor.time_to_collapse
        if floor.warning_active:
            color = palette.WARN_A if int(scene.time * 4) % 2 == 0 else palette.WARN_B
            text = "ВНИМАНИЕ! КРАЙ АРЕНЫ РАЗРУШИТСЯ ЧЕРЕЗ %d" % int(left + 0.999)
            self._font.draw(surface, text, 640, 52, 2, color, palette.RIM_DARK, "midtop")
        elif left is not None and left < 10:
            self._font.draw(surface, "КРАЙ ЧЕРЕЗ %d" % int(left + 0.999), 640, 52, 2,
                            palette.UI_DIM, palette.RIM_DARK, "midtop")

    def _draw_rush(self, surface, scene, index, rush):
        if not rush.active:
            return
        pg, f, arena = self._pg, self._font, scene.arena
        now = scene.time
        left_side = index == 0
        x = int(arena.left) + 56 if left_side else int(arena.right) - 56
        y = 66
        event = rush.last_event
        age = now - event.time if event is not None else 9.0
        flash = age < 0.2 and event is not None and event.kind != "reset"
        label = "СЕРИЯ x%d" % rush.count
        color = palette.UI_GOLD if rush.combo_active else palette.UI_TEXT
        anchor = "topleft" if left_side else "topright"
        f.draw(surface, label, x, y, 3 if flash else 2, palette.UI_GREEN if flash else color,
               palette.RIM_DARK, anchor)
        width, height = 150, 8
        bx = x if left_side else x - width
        frac = rush.remaining(now) / rush.limit if rush.limit else 0.0
        frac = max(0.0, min(1.0, frac))
        bar_color = palette.UI_GREEN if frac > 0.5 else (palette.UI_ORANGE if frac > 0.25 else palette.UI_RED)
        pg.draw.rect(surface, palette.HP_BACK, (bx, y + 22, width, height))
        if frac > 0:
            pg.draw.rect(surface, bar_color, (bx, y + 22, int(width * frac), height))
        pg.draw.rect(surface, palette.HP_BORDER, (bx, y + 22, width, height), 1)
        f.draw(surface, "%.1f" % rush.remaining(now), bx + (width + 6 if left_side else -6),
               y + 20, 2, palette.UI_DIM, None, "topleft" if left_side else "topright")
        if rush.combo_active:
            pop = 8 if age < 0.12 else (7 if age < 0.25 else 6)
            cx = 640 + (-260 if left_side else 260)
            tint = palette.UI_GOLD if rush.count < 5 else palette.UI_ORANGE
            f.draw(surface, "COMBO!", cx, 150, pop, tint, palette.RIM_DARK, "center")
            f.draw(surface, "x%d" % rush.count, cx, 150 + 7 * pop // 2 + 18, 4, palette.UI_TEXT,
                   palette.RIM_DARK, "center")

    def _draw_special_cooldowns(self, surface, scene):
        """Индикаторы Q/E/R/F: готовность и оставшийся кулдаун."""
        if not hasattr(scene, "cooldowns") or not scene.cooldowns:
            return
        from combat.specials import SPECIALS, BLOCK
        pg, f = self._pg, self._font
        # только для игрока (index 0); бот/манекен не показываем
        index = getattr(scene, "player_index", 0)
        if index >= len(scene.cooldowns):
            return
        cd = scene.cooldowns[index]
        labels = {"crush": "Q", "launch": "E", "drain": "R", "block": "F"}
        ci = getattr(scene, "command_input", None)
        if ci is not None and hasattr(ci, "key_labels"):
            labels.update(ci.key_labels)
        slots = [
            (labels["crush"], "crush", SPECIALS["crush"]["cooldown"], SPECIALS["crush"]["label"][:4]),
            (labels["launch"], "launch", SPECIALS["launch"]["cooldown"], SPECIALS["launch"]["label"][:4]),
            (labels["drain"], "drain", SPECIALS["drain"]["cooldown"], SPECIALS["drain"]["label"][:4]),
            (labels["block"], "block", BLOCK["cooldown"], "БЛОК"),
        ]
        box, gap = 48, 8
        total_w = len(slots) * box + (len(slots) - 1) * gap
        x0 = 640 - total_w // 2
        y = 668
        for i, (key, name, max_cd, short) in enumerate(slots):
            x = x0 + i * (box + gap)
            remaining = cd.remaining.get(name, 0.0)
            ready = remaining <= 0.0
            # энергия для Q/E/R
            if name != "block" and hasattr(scene, "energy") and index < len(scene.energy):
                from combat.specials import SPECIALS as _SP
                cost = _SP.get(name, {}).get("energy_cost", 0)
                if not scene.energy[index].can_afford(cost):
                    ready = False
            # фон
            bg = palette.UI_PANEL_LIGHT if ready else palette.HP_BACK
            pg.draw.rect(surface, bg, (x, y, box, box))
            border = palette.UI_GREEN if ready else palette.HP_BORDER
            # активный блок подсвечиваем
            if name == "block" and getattr(scene.fighters[index], "blocking_active", False):
                border = palette.UI_GOLD
            pg.draw.rect(surface, border, (x, y, box, box), 2)
            # клавиша
            f.draw(surface, key, x + box // 2, y + 4, 2,
                   palette.UI_GOLD if ready else palette.UI_DIM, None, "midtop")
            if ready:
                f.draw(surface, "OK", x + box // 2, y + box - 14, 1,
                       palette.UI_GREEN, None, "midtop")
            else:
                # полоска перезарядки снизу вверх
                frac = 1.0 - min(1.0, remaining / max(0.01, max_cd))
                fill_h = int((box - 4) * frac)
                if fill_h > 0:
                    pg.draw.rect(surface, palette.UI_ACCENT,
                                 (x + 2, y + box - 2 - fill_h, box - 4, fill_h))
                f.draw(surface, "%.0f" % remaining, x + box // 2, y + box - 14, 1,
                       palette.UI_TEXT, None, "midtop")

    def _draw_energy(self, surface, scene):
        """Общая шкала энергии игрока."""
        if not hasattr(scene, "energy") or not scene.energy:
            return
        index = getattr(scene, "player_index", 0)
        if index >= len(scene.energy):
            return
        pool = scene.energy[index]
        pg, f = self._pg, self._font
        width, height = 220, 14
        x = 640 - width // 2
        y = 640
        frac = 0.0 if pool.maximum <= 0 else max(0.0, min(1.0, pool.current / pool.maximum))
        pg.draw.rect(surface, palette.HP_BACK, (x, y, width, height))
        fill = int(width * frac)
        color = palette.UI_ACCENT if frac > 0.3 else palette.UI_ORANGE
        if fill > 0:
            pg.draw.rect(surface, color, (x, y, fill, height))
        pg.draw.rect(surface, palette.HP_BORDER, (x, y, width, height), 2)
        f.draw(surface, "ЭНЕРГИЯ %d/%d" % (int(pool.current), int(pool.maximum)),
               640, y - 16, 2, palette.UI_TEXT, palette.RIM_DARK, "midtop")

    def _draw_modifier_prompt(self, surface, scene):
        """Показывает активную подготовку Q/E/R и оставшееся время."""
        ci = getattr(scene, "command_input", None)
        if ci is None or not hasattr(ci, "pending_modifier_info"):
            return
        info = ci.pending_modifier_info(scene.time)
        if info is None:
            return
        name, remaining = info
        labels = {"crush": "СОКРУШИТЕЛЬНЫЙ", "launch": "ОТБРАСЫВАЮЩИЙ",
                  "drain": "ВОССТАНАВЛИВАЮЩИЙ"}
        keys = {"crush": "Q", "launch": "E", "drain": "R"}
        self._font.draw(
            surface,
            "%s — НАРИСУЙ ЖЕСТ!  %.1f c" % (labels[name], remaining),
            640, 610, 2, palette.UI_GOLD, palette.RIM_DARK, "midtop"
        )

    def _draw_control_hint(self, surface, scene):
        """Краткая подсказка управления (не перекрывает бой)."""
        f = self._font
        labels = {"crush": "Q", "launch": "E", "drain": "R", "block": "F"}
        ci = getattr(scene, "command_input", None)
        if ci is not None and hasattr(ci, "key_labels"):
            labels.update(ci.key_labels)
        text = "/ - | V  |  %s+жест СОКР  %s+жест ОТБР  %s+жест ВОССТ  |  %s БЛОК" % (
            labels.get("crush", "Q"), labels.get("launch", "E"),
            labels.get("drain", "R"), labels.get("block", "F"))
        f.draw(surface, text, 640, 708, 1, palette.UI_DIM, None, "midbottom")

