"""Боевая система: атаки, попадания, отбрасывание. Чистая логика, без Pygame.

Порядок одного тика update(dt):
  1. таймеры (вспышка, оглушение), тайм-аут комбо;
  2. продвижение фаз атак (Windup -> Active -> Recovery);
  3. взгляд свободных бойцов на ближайшего врага;
  4. сбор ВСЕХ попаданий этого тика, и только потом их применение
     (при одновременных ударах оба бойца получают урон - без преимущества
     "кто раньше в списке");
  5. множители движения по состояниям.

Время считается накоплением dt (секунды), поэтому результат не зависит
от FPS и от того, как кадры разбиты на тики.
"""

import math
from dataclasses import dataclass, replace

import settings
from combat.attacks import resolve_attack, ATTACKS
from combat.combo_system import ComboTracker
from combat.hitbox import attack_hitbox
from entities.fighter import FighterState

# Результаты request_attack
STARTED = "started"
UNKNOWN_GESTURE = "unknown_gesture"
DEAD = "dead"
HITSTUN = "hitstun"
BUSY = "busy"

_EPS = 1e-12


@dataclass(frozen=True)
class HitEvent:
    attacker: object
    target: object
    damage: float
    x: float            # точка попадания (центр цели)
    y: float
    dir_x: float        # направление отбрасывания
    dir_y: float
    finisher: bool
    time: float


class AttackInstance:
    """Выполняемая атака бойца."""

    def __init__(self, spec, facing):
        self.spec = spec
        self.facing = facing                     # направление зафиксировано на старте
        self.phase = FighterState.WINDUP
        self.phase_time = 0.0                    # время внутри текущей фазы
        self.active_span = None                  # (t0, t1) активной фазы в этом тике
        self.hit_targets = [set() for _ in spec.hit_windows]

    @property
    def phase_duration(self):
        return {
            FighterState.WINDUP: self.spec.windup,
            FighterState.ACTIVE: self.spec.active,
            FighterState.RECOVERY: self.spec.recovery,
        }[self.phase]

    @property
    def progress(self):
        return min(1.0, self.phase_time / self.phase_duration)

    def in_hit_window(self):
        """Идёт ли сейчас окно попадания (для анимации)."""
        if self.phase is not FighterState.ACTIVE:
            return False
        d = self.spec.active
        return any(a * d <= self.phase_time < b * d for a, b in self.spec.hit_windows)


class CombatSystem:
    def __init__(self, fighters):
        self.fighters = fighters      # общий список (может изменяться снаружи)
        self.time = 0.0
        self.events = []              # HitEvent текущего тика
        self._pending = {}            # id бойца -> (жест, скорость, масштаб урона, срок)

    # ---------- запуск атак ----------

    def _tracker(self, fighter):
        if fighter.combo is None:
            fighter.combo = ComboTracker()
        return fighter.combo


    def request_special(self, fighter, action, spec):
        """Запуск специальной атаки из combat.specials (конфиг-словарь)."""
        if not fighter.alive:
            return DEAD
        if fighter.state is FighterState.HITSTUN:
            return HITSTUN
        if fighter.state in (FighterState.WINDUP, FighterState.ACTIVE, FighterState.RECOVERY):
            return BUSY
        from combat.attacks import AttackDefinition, resolve_attack
        # базовая атака slash как каркас, модифицируем числами special
        base = resolve_attack("slash", "medium")
        # создаём временный spec-like object
        class _Spec:
            pass
        s = _Spec()
        s.name = action
        s.windup = spec["windup"]
        s.active = spec["active"]
        s.recovery = spec["recovery"]
        s.damage = base.damage * spec["damage_mult"]
        s.knockback = base.knockback * spec["knockback_mult"]
        s.hitstun = base.hitstun
        s.reach = spec["reach"]
        s.width = spec["width"]
        s.start_offset = base.start_offset
        s.hit_windows = ((0.0, 1.0),)
        s.is_finisher = False
        s.heal_on_hit = spec.get("heal_on_hit", 0.0)
        fighter.attack = AttackInstance(s, fighter.facing)
        fighter.state = FighterState.WINDUP
        fighter.move_factor = settings.MOVE_FACTOR_BY_STATE["windup"]
        return STARTED


    def request_special_gesture(self, fighter, gesture, tier, special_spec, damage_scale=1.0):
        """Обычный жест + модификатор Q/E/R: форма от gesture, эффект от special_spec."""
        if not fighter.alive:
            return DEAD
        if fighter.state is FighterState.HITSTUN:
            return HITSTUN
        if fighter.state in (FighterState.WINDUP, FighterState.ACTIVE, FighterState.RECOVERY):
            return BUSY
        base = resolve_attack(gesture, tier)
        class _Spec:
            pass
        s = _Spec()
        s.name = gesture
        s.windup = base.windup
        s.active = base.active
        s.recovery = base.recovery
        s.damage = base.damage * damage_scale  # уже включает special damage_mult
        s.knockback = base.knockback * float(special_spec.get("knockback_mult", 1.0))
        s.hitstun = base.hitstun
        s.reach = base.reach
        s.width = base.width
        s.start_offset = base.start_offset
        s.hit_windows = base.hit_windows
        s.is_finisher = getattr(base, "is_finisher", False)
        s.heal_on_hit = float(special_spec.get("heal_on_hit", 0.0))
        s.special_id = special_spec.get("id")
        fighter.attack = AttackInstance(s, fighter.facing)
        fighter.state = FighterState.WINDUP
        fighter.move_factor = settings.MOVE_FACTOR_BY_STATE["windup"]
        return STARTED

    def buffer_attack(self, fighter, gesture, tier="medium", damage_scale=1.0,
                      special_spec=None):
        """Буфер жеста. special_spec сохраняет спец-эффект (Q/E/R) при BUSY."""
        self._pending[id(fighter)] = (
            gesture, tier, damage_scale, self.time + settings.INPUT_BUFFER_TIME,
            special_spec)

    def request_attack(self, fighter, gesture, tier="medium", damage_scale=1.0):
        """Пытается начать атаку. Возвращает STARTED или причину отказа.

        Атаку нельзя начать в Windup/Active, в оглушении и мёртвым. В
        Recovery можно только продолжить комбо в окне комбо (это и есть
        награда за цепочку); вне окна ввод отклоняется - спам невозможен.
        """
        if gesture not in ATTACKS:
            return UNKNOWN_GESTURE
        if not fighter.alive:
            return DEAD
        if fighter.state is FighterState.HITSTUN:
            return HITSTUN
        tracker = self._tracker(fighter)
        if fighter.state in (FighterState.WINDUP, FighterState.ACTIVE):
            return BUSY
        if fighter.state is FighterState.RECOVERY:
            if not tracker.can_continue(gesture, self.time):
                return BUSY

        step = tracker.register(gesture, self.time)
        spec = resolve_attack(gesture, tier, step.finished)
        if damage_scale != 1.0:
            spec = replace(spec, damage=spec.damage * damage_scale)

        self._face_enemy(fighter)
        fighter.attack = AttackInstance(spec, fighter.facing)
        fighter.state = FighterState.WINDUP
        return STARTED

    # ---------- тик ----------

    def update(self, dt):
        self.time += dt
        self.events = []

        for f in self.fighters:
            f.hit_flash = max(0.0, f.hit_flash - dt)
            if f.state is FighterState.HITSTUN:
                f.hitstun_remaining -= dt
                if f.hitstun_remaining <= 0.0:
                    f.hitstun_remaining = 0.0
                    f.state = FighterState.IDLE
            if f.combo is not None:
                f.combo.update(self.time)

        for f in self.fighters:
            if f.attack is not None:
                self._advance_attack(f, dt)

        self._run_buffered()

        for f in self.fighters:
            if f.state is FighterState.IDLE:
                self._face_enemy(f)

        hits = []
        for f in self.fighters:
            if f.attack is not None and f.alive:
                hits.extend(self._collect_hits(f))
        for hit in hits:
            self._apply_hit(*hit)

        for f in self.fighters:
            f.move_factor = settings.MOVE_FACTOR_BY_STATE[f.state.value]

    def _run_buffered(self):
        for f in self.fighters:
            item = self._pending.get(id(f))
            if item is None:
                continue
            if len(item) == 5:
                gesture, tier, scale, expires, special_spec = item
            else:
                gesture, tier, scale, expires = item
                special_spec = None
            if self.time > expires or not f.alive or f.state is FighterState.HITSTUN:
                del self._pending[id(f)]
                continue
            if special_spec is not None:
                result = self.request_special_gesture(f, gesture, tier, special_spec, scale)
            else:
                result = self.request_attack(f, gesture, tier, scale)
            if result != BUSY:
                del self._pending[id(f)]

    # ---------- фазы атаки ----------

    def _advance_attack(self, fighter, dt):
        atk = fighter.attack
        atk.active_span = None
        remaining = dt
        while fighter.attack is not None and remaining > _EPS:
            atk = fighter.attack
            left = atk.phase_duration - atk.phase_time
            start = atk.phase_time
            if remaining < left - _EPS:
                atk.phase_time += remaining
                self._note_span(atk, start, atk.phase_time)
                remaining = 0.0
            else:
                self._note_span(atk, start, atk.phase_duration)
                remaining -= left
                self._next_phase(fighter, self.time - remaining)

    @staticmethod
    def _note_span(atk, t0, t1):
        if atk.phase is not FighterState.ACTIVE:
            return
        if atk.active_span is None:
            atk.active_span = (t0, t1)
        else:
            atk.active_span = (min(atk.active_span[0], t0), t1)

    def _next_phase(self, fighter, at_time):
        atk = fighter.attack
        atk.phase_time = 0.0
        if atk.phase is FighterState.WINDUP:
            atk.phase = fighter.state = FighterState.ACTIVE
        elif atk.phase is FighterState.ACTIVE:
            atk.phase = fighter.state = FighterState.RECOVERY
            tracker = self._tracker(fighter)
            if tracker.history:  # цепочка продолжается: открываем окно комбо
                tracker.open_window(at_time, atk.spec.recovery)
        else:  # конец восстановления
            fighter.attack = None
            fighter.state = FighterState.IDLE

    # ---------- попадания ----------

    def _enemies(self, fighter):
        return [o for o in self.fighters if o.team != fighter.team and o.alive]

    def _face_enemy(self, fighter):
        enemies = self._enemies(fighter)
        if not enemies:
            return
        nearest = min(enemies, key=lambda o: math.hypot(o.x - fighter.x, o.y - fighter.y))
        dx, dy = nearest.x - fighter.x, nearest.y - fighter.y
        length = math.hypot(dx, dy)
        if length > 1e-6:
            fighter.facing = (dx / length, dy / length)

    def _collect_hits(self, attacker):
        atk = attacker.attack
        if atk.active_span is None:
            return []
        t0, t1 = atk.active_span
        d = atk.spec.active
        hitbox = attack_hitbox(attacker.x, attacker.y, atk.facing, atk.spec)
        hits = []
        for i, (a, b) in enumerate(atk.spec.hit_windows):
            if not (a * d <= t1 and b * d > t0):
                continue
            for target in self._enemies(attacker):
                if id(target) in atk.hit_targets[i]:
                    continue  # один удар - одно попадание по цели
                if hitbox.intersects_box(target.box):
                    atk.hit_targets[i].add(id(target))
                    hits.append((attacker, target, atk.spec))
        return hits

    def _apply_hit(self, attacker, target, spec):
        dx, dy = target.x - attacker.x, target.y - attacker.y
        length = math.hypot(dx, dy)
        if length < 1e-6:
            dx, dy = attacker.facing
            length = math.hypot(dx, dy) or 1.0
        dx, dy = dx / length, dy / length

        # Блок полностью отменяет входящий урон
        if getattr(target, "blocking_active", False):
            target.hit_flash = settings.HIT_FLASH_TIME * 0.5
            self.events.append(HitEvent(attacker, target, 0.0, target.x, target.y,
                                        0.0, 0.0, False, self.time))
            return

        damage = float(spec.damage)
        target.hp = max(0.0, target.hp - damage)

        # Восстанавливающий удар: heal атакующему
        heal = float(getattr(spec, "heal_on_hit", 0.0) or 0.0)
        if heal > 0 and attacker.alive:
            attacker.hp = min(float(attacker.max_hp), attacker.hp + heal)

        if getattr(target, "no_knockback", False):
            # тренировочный манекен: только урон
            target.hit_flash = settings.HIT_FLASH_TIME
            self.events.append(HitEvent(attacker, target, damage, target.x, target.y,
                                        dx, dy, getattr(spec, "is_finisher", False), self.time))
            return

        target.hit_flash = settings.HIT_FLASH_TIME
        target.attack = None
        self._pending.pop(id(target), None)
        if target.combo is not None:
            target.combo.reset()
        target.knock_vx = dx * spec.knockback
        target.knock_vy = dy * spec.knockback
        if target.hp <= 0.0:
            target.state = FighterState.DEAD
            target.hitstun_remaining = 0.0
        else:
            target.state = FighterState.HITSTUN
            target.hitstun_remaining = spec.hitstun
        self.events.append(HitEvent(attacker, target, damage, target.x, target.y,
                                    dx, dy, getattr(spec, "is_finisher", False), self.time))
