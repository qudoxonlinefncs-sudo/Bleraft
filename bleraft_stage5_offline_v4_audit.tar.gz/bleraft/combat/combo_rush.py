"""Combo Rush: динамическая серия правильно распознанных жестов. Чистая логика.

Правила (числа - в settings.py):
  - первый распознанный жест открывает серию и запускает таймер на следующий;
  - каждый следующий распознанный жест продлевает серию, а время на очередной
    жест уменьшается по таблице COMBO_RUSH_TIMES (не ниже COMBO_RUSH_MIN_TIME);
  - с COMBO_RUSH_ACTIVATE_AT-го жеста серия становится COMBO и продолжает расти;
  - неправильный жест, истечение времени и попадание по бойцу сбрасывают серию.
Не зависит от скорости рисования отдельного жеста (она меняет силу атаки).
Засчитывается правильно распознанный жест, а не попадание по противнику.
"""

from dataclasses import dataclass

import settings


@dataclass(frozen=True)
class RushEvent:
    kind: str        # start / continue / combo / extend / reset
    count: int       # длина серии (после события)
    time: float
    limit: float     # время на следующий жест (для reset - 0)
    reason: str = ""  # для reset: wrong / timeout / interrupted / manual


class ComboRush:
    def __init__(self, times=None, min_time=None, activate_at=None):
        self.times = tuple(settings.COMBO_RUSH_TIMES if times is None else times)
        self.min_time = settings.COMBO_RUSH_MIN_TIME if min_time is None else min_time
        self.activate_at = (settings.COMBO_RUSH_ACTIVATE_AT
                            if activate_at is None else activate_at)
        self.count = 0
        self.peak = 0
        self.limit = 0.0
        self.deadline = None
        self.last_event = None
        self.events = []          # накопленные события (забирает сцена)

    # --- параметры ---

    def limit_for(self, next_number):
        """Время на жест с номером next_number (2, 3, 4...)."""
        index = max(0, next_number - 2)
        value = self.times[index] if index < len(self.times) else self.times[-1]
        return max(value, self.min_time)

    @property
    def active(self):
        return self.count > 0

    @property
    def combo_active(self):
        return self.count >= self.activate_at

    def remaining(self, now):
        if self.deadline is None:
            return 0.0
        return max(0.0, self.deadline - now)

    def damage_multiplier(self):
        """Combo Rush не усиливает урон/скорость/knockback — только визуальная серия."""
        return 1.0

    # --- события ---

    def _emit(self, kind, now, reason=""):
        event = RushEvent(kind, self.count, now, self.limit if kind != "reset" else 0.0, reason)
        self.last_event = event
        self.events.append(event)
        return event

    def register(self, now):
        """Правильно распознанный жест. Возвращает RushEvent."""
        if self.count and now > self.deadline:
            self._reset(now, "timeout")
        self.count += 1
        self.peak = max(self.peak, self.count)
        self.limit = self.limit_for(self.count + 1)
        self.deadline = now + self.limit
        if self.count == 1:
            kind = "start"
        elif self.count == self.activate_at:
            kind = "combo"
        elif self.count > self.activate_at:
            kind = "extend"
        else:
            kind = "continue"
        return self._emit(kind, now)

    def update(self, now):
        """Тайм-аут. Возвращает True, если серия только что сброшена."""
        if self.count and now > self.deadline:
            self._reset(now, "timeout")
            return True
        return False

    def fail(self, now):
        """Неправильный (не распознанный) жест."""
        return self._reset(now, "wrong")

    def interrupt(self, now):
        """Боец получил удар."""
        return self._reset(now, "interrupted")

    def reset(self, now=0.0):
        return self._reset(now, "manual")

    def _reset(self, now, reason):
        if not self.count:
            return None
        self.count = 0
        self.limit = 0.0
        self.deadline = None
        return self._emit("reset", now, reason)
