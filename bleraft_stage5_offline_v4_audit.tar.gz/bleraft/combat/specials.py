"""Специальные атаки и блок (Stage 5).

Управление:
  Q + жест — CRUSH (сокрушительный)
  E + жест — LAUNCH (отбрасывающий)
  R + жест — DRAIN (восстанавливающий)
  F       — BLOCK (без жеста)

Жест задаёт форму атаки; Q/E/R — модификатор эффекта.
Простое нажатие Q/E/R без жеста ничего не запускает.

Числовые параметры — предварительные, НЕ финальный баланс.
"""

from dataclasses import dataclass, field

# --- Энергия (общая шкала для Q/E/R) ---
SPECIAL_GESTURE_WINDOW = 4.0  # seconds from Q/E/R key press to completed gesture

ENERGY_MAX = 100.0
ENERGY_REGEN_PER_SEC = 6.0          # автовосстановление
ENERGY_ON_HIT = 8.0                 # за успешное попадание обычной/спец атакой
ENERGY_COST = {                     # расход на спец-атаку
    "crush": 35.0,
    "launch": 30.0,
    "drain": 40.0,
}

# --- Спец-атаки: старые cooldown были 8 / 7 / 10 с ---
# Новые (короче, но не спам): 4.5 / 4.0 / 5.0 с
CRUSH = {
    "id": "crush",
    "label": "СОКРУШИТЕЛЬНЫЙ",
    "damage_mult": 1.8,
    "knockback_mult": 1.0,
    "heal_on_hit": 0.0,
    "cooldown": 4.5,
    "energy_cost": ENERGY_COST["crush"],
}

LAUNCH = {
    "id": "launch",
    "label": "ОТБРАСЫВАЮЩИЙ",
    "damage_mult": 0.9,
    "knockback_mult": 2.2,
    "heal_on_hit": 0.0,
    "cooldown": 4.0,
    "energy_cost": ENERGY_COST["launch"],
}

DRAIN = {
    "id": "drain",
    "label": "ВОССТАНАВЛИВАЮЩИЙ",
    "damage_mult": 0.85,
    "knockback_mult": 0.8,
    "heal_on_hit": 12.0,
    "cooldown": 5.0,
    "energy_cost": ENERGY_COST["drain"],
}

BLOCK = {
    "id": "block",
    "label": "БЛОК",
    "window": 0.25,
    "recovery": 0.40,
    "cooldown": 1.2,
}

SPECIALS = {
    "crush": CRUSH,
    "launch": LAUNCH,
    "drain": DRAIN,
}

MODIFIER_KEYS = ("crush", "launch", "drain")  # Q/E/R modifiers
SPECIAL_ACTIONS = ("special_crush", "special_launch", "special_drain", "block")
ACTION_TO_SPECIAL = {
    "special_crush": "crush",
    "special_launch": "launch",
    "special_drain": "drain",
    "block": "block",
}


@dataclass
class CooldownState:
    remaining: dict = None

    def __post_init__(self):
        if self.remaining is None:
            self.remaining = {k: 0.0 for k in list(SPECIALS) + ["block"]}

    def ready(self, name):
        return self.remaining.get(name, 0.0) <= 0.0

    def trigger(self, name, duration):
        self.remaining[name] = float(duration)

    def update(self, dt):
        for k in list(self.remaining):
            self.remaining[k] = max(0.0, self.remaining[k] - dt)


@dataclass
class EnergyPool:
    """Общая шкала энергии для специальных атак Q/E/R."""
    current: float = ENERGY_MAX
    maximum: float = ENERGY_MAX

    def can_afford(self, cost):
        return self.current >= cost

    def spend(self, cost):
        if not self.can_afford(cost):
            return False
        self.current = max(0.0, self.current - cost)
        return True

    def gain(self, amount):
        self.current = min(self.maximum, self.current + amount)

    def regen(self, dt):
        self.gain(ENERGY_REGEN_PER_SEC * dt)
