"""Точка входа Bleraft: python main.py"""

import sys


def main():
    try:
        import pygame
    except ImportError:
        print("Pygame не установлен. Выполните: pip install -r requirements.txt")
        return 1

    from app import build_game

    game, _ = build_game(pygame)
    game.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
