"""Пол арены из плиток, который разрушается кольцами. Чистая логика, без Pygame.

Расписание: кольцо k (0, 1, ...) обрушивается в момент (k + 1) * interval.
За `warning` секунд до этого плитки кольца покрываются трещинами (CRACKED),
по ним ещё можно ходить. В момент обрушения плитки переходят в FALLING:
они уже не безопасны, а граница безопасной зоны сдвигается внутрь.
Через `fall_time` плитки исчезают (GONE) - это нужно только анимации.
Арена не сжимается меньше min_cols x min_rows плиток.
"""

INTACT, CRACKED, FALLING, GONE = 0, 1, 2, 3
_EPS = 1e-9    # накопление float за тысячи тиков не должно сдвигать расписание


class ArenaFloor:
    def __init__(self, arena, tile_size=30, interval=30.0, warning=3.0, fall_time=0.9,
                 min_cols=14, min_rows=8, enabled=True):
        if arena.width % tile_size or arena.height % tile_size:
            raise ValueError("Размер арены должен делиться на размер плитки")
        self.arena = arena
        self.tile = tile_size
        self.interval = interval
        self.warning = warning
        self.fall_time = fall_time
        self.min_cols = min_cols
        self.min_rows = min_rows
        self.enabled = enabled
        self.cols = arena.width // tile_size
        self.rows = arena.height // tile_size
        self.reset()

    def reset(self):
        self.state = [[INTACT] * self.cols for _ in range(self.rows)]
        self.time = 0.0
        self.rings_fallen = 0       # сколько колец уже обрушилось
        self.warned = False         # трещины для ближайшего кольца уже показаны
        self.version = 0            # растёт при любом изменении плиток (для кэша отрисовки)
        self.fall_started = {}      # (row, col) -> время начала падения
        self.events = []            # "crack" / "fall" - забирает сцена (звук, эффекты)
        self.c0, self.c1, self.r0, self.r1 = 0, self.cols, 0, self.rows  # безопасные плитки

    # ---------- расписание ----------

    @property
    def max_rings(self):
        k = 0
        while (self.cols - 2 * (k + 1) >= self.min_cols
               and self.rows - 2 * (k + 1) >= self.min_rows):
            k += 1
        return k

    @property
    def has_next_ring(self):
        return self.enabled and self.rings_fallen < self.max_rings

    @property
    def next_collapse_time(self):
        return (self.rings_fallen + 1) * self.interval

    @property
    def time_to_collapse(self):
        """Секунды до ближайшего обрушения (None, если больше колец нет)."""
        if not self.has_next_ring:
            return None
        return max(0.0, self.next_collapse_time - self.time)

    @property
    def warning_active(self):
        return self.has_next_ring and self.warned

    def ring_tiles(self, k):
        """Плитки кольца k: те, что на границе прямоугольника k..cols-1-k."""
        last_c, last_r = self.cols - 1 - k, self.rows - 1 - k
        tiles = []
        for r in range(k, last_r + 1):
            for c in range(k, last_c + 1):
                if r in (k, last_r) or c in (k, last_c):
                    tiles.append((r, c))
        return tiles

    def update(self, dt):
        self.events = []
        self.time += dt
        if self.enabled and self.has_next_ring:
            nxt = self.next_collapse_time
            if not self.warned and self.time >= nxt - self.warning - _EPS:
                self._crack(self.rings_fallen)
            if self.time >= nxt - _EPS:
                if not self.warned:
                    self._crack(self.rings_fallen)
                self._collapse(self.rings_fallen)
        done = [t for t, start in self.fall_started.items()
                if self.time - start >= self.fall_time - _EPS]
        for r, c in done:
            self.state[r][c] = GONE
            del self.fall_started[(r, c)]
        if done:
            self.version += 1

    def _crack(self, k):
        for r, c in self.ring_tiles(k):
            self.state[r][c] = CRACKED
        self.warned = True
        self.version += 1
        self.events.append("crack")

    def _collapse(self, k):
        for r, c in self.ring_tiles(k):
            self.state[r][c] = FALLING
            self.fall_started[(r, c)] = self.time
        self.rings_fallen += 1
        self.c0, self.c1, self.r0, self.r1 = k + 1, self.cols - k - 1, k + 1, self.rows - k - 1
        self.warned = False
        self.version += 1
        self.events.append("fall")

    # ---------- запросы ----------

    @property
    def safe_bounds(self):
        """(left, top, right, bottom) в пикселях: граница, о которую упираются бойцы."""
        a, t = self.arena, self.tile
        return (a.left + self.c0 * t, a.top + self.r0 * t,
                a.left + self.c1 * t, a.top + self.r1 * t)

    def tile_at(self, x, y):
        c = int((x - self.arena.left) // self.tile)
        r = int((y - self.arena.top) // self.tile)
        if 0 <= r < self.rows and 0 <= c < self.cols:
            return r, c
        return None

    def is_safe(self, x, y):
        """Есть ли под точкой плитка, на которой можно стоять."""
        tile = self.tile_at(x, y)
        if tile is None:
            return False
        return self.state[tile[0]][tile[1]] in (INTACT, CRACKED)

    def tiles_in_state(self, wanted):
        return [(r, c) for r in range(self.rows) for c in range(self.cols)
                if self.state[r][c] == wanted]

    def fall_progress(self, tile):
        """0..1 для падающей плитки."""
        start = self.fall_started.get(tile)
        if start is None:
            return 1.0
        return min(1.0, (self.time - start) / self.fall_time)
