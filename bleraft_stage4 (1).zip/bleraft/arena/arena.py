"""Прямоугольная арена. Чистая логика, без Pygame."""

import settings


class Arena:
    def __init__(self, left, top, width, height):
        if width <= 0 or height <= 0:
            raise ValueError("Размеры арены должны быть > 0")
        self.left = left
        self.top = top
        self.width = width
        self.height = height
        self.floor = None   # ArenaFloor: если задан, границы = безопасная зона пола

    @classmethod
    def from_settings(cls):
        """Арена из settings.py, по центру окна."""
        left = (settings.WINDOW_WIDTH - settings.ARENA_WIDTH) // 2
        top = (settings.WINDOW_HEIGHT - settings.ARENA_HEIGHT) // 2
        return cls(left, top, settings.ARENA_WIDTH, settings.ARENA_HEIGHT)

    @property
    def right(self):
        return self.left + self.width

    @property
    def bottom(self):
        return self.top + self.height

    @property
    def center_x(self):
        return self.left + self.width / 2

    @property
    def center_y(self):
        return self.top + self.height / 2

    @property
    def bounds(self):
        """(left, top, right, bottom). С полом - текущая безопасная зона."""
        if self.floor is not None:
            return self.floor.safe_bounds
        return (self.left, self.top, self.right, self.bottom)

    def attach_floor(self, floor):
        self.floor = floor
        return floor
