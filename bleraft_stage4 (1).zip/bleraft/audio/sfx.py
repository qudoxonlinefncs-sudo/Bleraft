"""Простые звуки, синтезируемые кодом (без звуковых файлов и numpy).

Если звуковое устройство недоступно, звук просто отключается: игра работает дальше.
"""

import math
from array import array

RATE = 22050

# имя: (частота начала, частота конца, длительность, громкость, форма)
SOUND_DEFS = {
    "click": (660, 880, 0.05, 0.5, "square"),
    "swing": (420, 160, 0.09, 0.35, "noise"),
    "hit": (200, 70, 0.14, 0.7, "noise"),
    "combo": (520, 1040, 0.16, 0.5, "square"),
    "crack": (140, 90, 0.20, 0.5, "noise"),
    "fall": (260, 60, 0.45, 0.5, "sine"),
    "ringout": (500, 60, 0.55, 0.6, "sine"),
    "win": (440, 880, 0.55, 0.5, "square"),
    "lose": (330, 110, 0.60, 0.5, "square"),
}


def synth(freq_start, freq_end, duration, volume=0.5, shape="square"):
    """16-битный моно PCM (bytes). Чистая функция: проверяется без звуковой карты."""
    n = max(1, int(RATE * duration))
    out = array("h")
    phase, noise_state = 0.0, 12345
    for i in range(n):
        t = i / n
        freq = freq_start + (freq_end - freq_start) * t
        phase += freq / RATE
        if shape == "sine":
            value = math.sin(2 * math.pi * phase)
        elif shape == "noise":
            noise_state = (noise_state * 1103515245 + 12345) & 0x7FFFFFFF
            value = (noise_state / 0x7FFFFFFF) * 2 - 1
            value = 0.6 * value + 0.4 * math.sin(2 * math.pi * phase)
        else:
            value = 1.0 if (phase % 1.0) < 0.5 else -1.0
        envelope = (1.0 - t) ** 1.5 * min(1.0, i / 80)
        out.append(int(max(-1.0, min(1.0, value * volume * envelope)) * 32000))
    return out.tobytes()


class SoundBank:
    def __init__(self, pygame, profile):
        self._pg = pygame
        self._profile = profile
        self._sounds = None      # None - ещё не инициализировано; {} - звук недоступен

    def _init(self):
        self._sounds = {}
        try:
            pg = self._pg
            if not pg.mixer.get_init():
                pg.mixer.init(RATE, -16, 1, 512)
            for name, args in SOUND_DEFS.items():
                self._sounds[name] = pg.mixer.Sound(buffer=synth(*args))
        except Exception:        # нет аудиоустройства и т.п.: играем без звука
            self._sounds = {}

    @property
    def available(self):
        if self._sounds is None:
            self._init()
        return bool(self._sounds)

    def play(self, name):
        if not self._profile.sound_on or not self.available:
            return False
        sound = self._sounds.get(name)
        if sound is None:
            return False
        try:
            sound.set_volume(self._profile.volume)
            sound.play()
        except Exception:
            return False
        return True
