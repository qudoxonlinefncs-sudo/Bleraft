import unittest

from input.gesture_recorder import GestureRecorder, Stroke


class RecorderTests(unittest.TestCase):
    def test_records_points_with_times(self):
        rec = GestureRecorder(spacing=1.0)
        rec.begin(10, 10, 1.0)
        rec.add_point(20, 10, 1.1)
        rec.add_point(30, 10, 1.2)
        stroke = rec.end(40, 10, 1.3)
        self.assertEqual([p[2] for p in stroke.points], [1.0, 1.1, 1.2, 1.3])
        self.assertEqual(stroke.points[0][:2], (10.0, 10.0))
        self.assertFalse(rec.active)

    def test_close_points_are_ignored(self):
        rec = GestureRecorder(spacing=5.0)
        rec.begin(0, 0, 0)
        rec.add_point(1, 1, 0.1)
        rec.add_point(2, 0, 0.2)
        self.assertEqual(len(rec.points), 1)

    def test_point_limit(self):
        rec = GestureRecorder(spacing=0.1, max_points=5)
        rec.begin(0, 0, 0)
        for i in range(1, 50):
            rec.add_point(i * 10, 0, i * 0.01)
        self.assertEqual(len(rec.points), 5)

    def test_end_without_begin_returns_none(self):
        self.assertIsNone(GestureRecorder().end(0, 0, 0))

    def test_points_added_when_not_active_are_ignored(self):
        rec = GestureRecorder()
        rec.add_point(5, 5, 1)
        self.assertEqual(rec.points, [])

    def test_release_time_is_kept_even_if_mouse_did_not_move(self):
        rec = GestureRecorder(spacing=1.0)
        rec.begin(0, 0, 0.0)
        rec.add_point(50, 0, 0.1)
        stroke = rec.end(50, 0, 0.5)  # мышь стояла 0.4 с перед отпусканием
        self.assertAlmostEqual(stroke.duration, 0.5)

    def test_cancel_discards_gesture(self):
        rec = GestureRecorder()
        rec.begin(0, 0, 0)
        rec.cancel()
        self.assertFalse(rec.active)
        self.assertIsNone(rec.end(1, 1, 1))

    def test_new_begin_discards_unfinished_gesture(self):
        rec = GestureRecorder(spacing=1.0)
        rec.begin(0, 0, 0)
        rec.add_point(100, 0, 0.1)
        rec.begin(5, 5, 1.0)
        self.assertEqual(len(rec.points), 1)

    def test_stroke_length_and_duration(self):
        stroke = Stroke(((0.0, 0.0, 1.0), (3.0, 4.0, 1.5), (3.0, 14.0, 2.0)))
        self.assertAlmostEqual(stroke.length, 15.0)
        self.assertAlmostEqual(stroke.duration, 1.0)

    def test_empty_stroke_has_zero_metrics(self):
        stroke = Stroke(())
        self.assertEqual((stroke.length, stroke.duration), (0.0, 0.0))


if __name__ == "__main__":
    unittest.main()
