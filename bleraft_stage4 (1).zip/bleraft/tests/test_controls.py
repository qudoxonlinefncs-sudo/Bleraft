import types
import unittest

from input.controls import ControlScheme, read_direction
from input.keyboard import KeyboardInput, default_schemes

SCHEME = ControlScheme(up="u", down="d", left="l", right="r")


def pressed(*keys):
    return lambda key: key in keys


class ReadDirectionTests(unittest.TestCase):
    def test_single_keys(self):
        self.assertEqual(read_direction(SCHEME, pressed("u")), (0, -1))
        self.assertEqual(read_direction(SCHEME, pressed("d")), (0, 1))
        self.assertEqual(read_direction(SCHEME, pressed("l")), (-1, 0))
        self.assertEqual(read_direction(SCHEME, pressed("r")), (1, 0))

    def test_diagonal(self):
        self.assertEqual(read_direction(SCHEME, pressed("u", "r")), (1, -1))
        self.assertEqual(read_direction(SCHEME, pressed("d", "l")), (-1, 1))

    def test_nothing_pressed(self):
        self.assertEqual(read_direction(SCHEME, pressed()), (0, 0))

    def test_opposite_keys_cancel(self):
        self.assertEqual(read_direction(SCHEME, pressed("l", "r")), (0, 0))
        self.assertEqual(read_direction(SCHEME, pressed("u", "d", "r")), (1, 0))


def fake_pygame(held):
    """held - множество удерживаемых кодов клавиш."""
    class Pressed:
        def __getitem__(self, key):
            return key in held

    return types.SimpleNamespace(
        K_w=1, K_a=2, K_s=3, K_d=4, K_UP=5, K_LEFT=6, K_DOWN=7, K_RIGHT=8,
        key=types.SimpleNamespace(get_pressed=lambda: Pressed()),
    )


class KeyboardInputTests(unittest.TestCase):
    def test_default_schemes_use_wasd_and_arrows(self):
        p1, p2 = default_schemes(fake_pygame(set()))
        self.assertEqual((p1.up, p1.left, p1.down, p1.right), (1, 2, 3, 4))
        self.assertEqual((p2.up, p2.left, p2.down, p2.right), (5, 6, 7, 8))

    def test_players_are_independent(self):
        # W + D для первого игрока, стрелка влево для второго
        kb = KeyboardInput(fake_pygame({1, 4, 6}))
        self.assertEqual(kb.direction(0), (1, -1))
        self.assertEqual(kb.direction(1), (-1, 0))

    def test_player_one_ignores_arrows_and_player_two_ignores_wasd(self):
        kb = KeyboardInput(fake_pygame({5, 8}))   # стрелки вверх и вправо
        self.assertEqual(kb.direction(0), (0, 0))
        self.assertEqual(kb.direction(1), (1, -1))
        kb = KeyboardInput(fake_pygame({1, 2}))   # W и A
        self.assertEqual(kb.direction(0), (-1, -1))
        self.assertEqual(kb.direction(1), (0, 0))

    def test_custom_schemes_allow_remapping(self):
        custom = [ControlScheme(up=9, down=9, left=9, right=9)]
        kb = KeyboardInput(fake_pygame({9}), schemes=custom)
        self.assertEqual(kb.direction(0), (0, 0))  # лево и право гасятся


if __name__ == "__main__":
    unittest.main()
