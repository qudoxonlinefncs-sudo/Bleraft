import math
import unittest

from physics.movement import clamp_direction_length, step_position


class DirectionTests(unittest.TestCase):
    def test_diagonal_is_normalized(self):
        dx, dy = clamp_direction_length(1, 1)
        self.assertAlmostEqual(math.hypot(dx, dy), 1.0)
        self.assertAlmostEqual(dx, dy)

    def test_all_diagonals_have_length_one(self):
        for sx in (-1, 1):
            for sy in (-1, 1):
                dx, dy = clamp_direction_length(sx, sy)
                self.assertAlmostEqual(math.hypot(dx, dy), 1.0)

    def test_straight_direction_unchanged(self):
        self.assertEqual(clamp_direction_length(1, 0), (1.0, 0.0))
        self.assertEqual(clamp_direction_length(0, -1), (0.0, -1.0))

    def test_zero_direction_stays_zero(self):
        self.assertEqual(clamp_direction_length(0, 0), (0.0, 0.0))

    def test_short_analog_vector_is_kept(self):
        self.assertEqual(clamp_direction_length(0.5, 0.0), (0.5, 0.0))

    def test_long_vector_is_limited(self):
        self.assertEqual(clamp_direction_length(3, 0), (1.0, 0.0))


class StepPositionTests(unittest.TestCase):
    def test_straight_step_distance(self):
        x, y = step_position(10, 20, (1, 0), speed=100, dt=0.5)
        self.assertAlmostEqual(x, 60)
        self.assertAlmostEqual(y, 20)

    def test_diagonal_speed_equals_straight_speed(self):
        x, y = step_position(0, 0, (1, 1), speed=100, dt=1.0)
        self.assertAlmostEqual(math.hypot(x, y), 100.0)

    def test_no_direction_no_movement(self):
        self.assertEqual(step_position(5, 7, (0, 0), 100, 1.0), (5.0, 7.0))

    def test_distance_does_not_depend_on_step_size(self):
        for steps in (30, 60, 144, 240):
            x = 0.0
            for _ in range(steps):
                x, _ = step_position(x, 0, (1, 0), speed=200, dt=1.0 / steps)
            self.assertAlmostEqual(x, 200.0, places=6)


if __name__ == "__main__":
    unittest.main()
