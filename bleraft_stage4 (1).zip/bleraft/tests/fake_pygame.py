"""Подробная подделка pygame для проверки всего приложения без экрана.

Это НЕ настоящий pygame: подделка проверяет, что наш код вызывает функции
рисования с разумными аргументами (числа, цвета 0..255, непустые поверхности) и
что весь поток экранов работает. Внешний вид и совместимость с настоящим pygame-ce
она не доказывает.
"""

import math
import types

QUIT, KEYDOWN, KEYUP = 256, 768, 769
MOUSEMOTION, MOUSEBUTTONDOWN, MOUSEBUTTONUP = 1024, 1025, 1026
SRCALPHA = 65536

_KEYS = {}


def key_code(name):
    if name == "K_ESCAPE":
        return 27
    if name == "K_RETURN":
        return 13
    if name not in _KEYS:
        _KEYS[name] = 2000 + len(_KEYS)
    return _KEYS[name]


def _number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _check_color(color):
    assert len(color) in (3, 4), color
    assert all(isinstance(c, int) and 0 <= c <= 255 for c in color), color


def _check_rect(rect):
    assert len(rect) == 4 and all(_number(v) for v in rect), rect


def _check_point(p):
    assert len(p) == 2 and all(_number(v) for v in p), p


class FakeSurface:
    def __init__(self, size, flags=0):
        assert len(size) == 2 and all(isinstance(v, int) and v > 0 for v in size), size
        self.size = tuple(size)
        self.flags = flags
        self.blits = []
        self.fills = []
        self.alpha = None

    def fill(self, color, rect=None):
        _check_color(color)
        if rect is not None:
            _check_rect(rect)
        self.fills.append((color, rect))

    def blit(self, source, pos, area=None):
        assert isinstance(source, FakeSurface), type(source)
        _check_point(pos)
        self.blits.append((source, pos))

    def set_at(self, pos, color):
        _check_color(color)

    def get_size(self):
        return self.size

    def get_width(self):
        return self.size[0]

    def get_height(self):
        return self.size[1]

    def set_alpha(self, value):
        assert isinstance(value, int) and 0 <= value <= 255, value
        self.alpha = value


class Clock:
    def __init__(self, ms=16):
        self.ms = ms

    def tick(self, fps=0):
        return self.ms

    def get_fps(self):
        return 60.0


class FakePygame:
    """Модуль-подделка. Клавиши K_* создаются по имени."""

    QUIT, KEYDOWN, KEYUP = QUIT, KEYDOWN, KEYUP
    MOUSEMOTION, MOUSEBUTTONDOWN, MOUSEBUTTONUP = MOUSEMOTION, MOUSEBUTTONDOWN, MOUSEBUTTONUP
    SRCALPHA = SRCALPHA

    def __init__(self, frame_ms=16):
        self.script = lambda frame: []
        self.frame = 0
        self.held = set()
        self.draw_calls = {"rect": 0, "line": 0, "lines": 0, "circle": 0, "polygon": 0, "ellipse": 0}
        self.screen = None
        self.caption = None
        self.quit_called = False
        self.surfaces_created = 0
        pg = self

        def surface_factory(size, flags=0):
            pg.surfaces_created += 1
            return FakeSurface(size, flags)

        self.Surface = surface_factory

        def counted(name, check):
            def fn(surface, color, *args, **kwargs):
                assert isinstance(surface, FakeSurface)
                _check_color(color)
                check(*args)
                pg.draw_calls[name] += 1
            return fn

        def check_rect(rect, width=0):
            _check_rect(rect)
            assert isinstance(width, int) and width >= 0

        def check_line(a, b, width=1):
            _check_point(a)
            _check_point(b)

        def check_lines(closed, points, width=1):
            assert len(points) >= 2
            for p in points:
                _check_point(p)

        def check_circle(center, radius, width=0):
            _check_point(center)
            assert _number(radius) and radius >= 1, radius
            assert width <= radius

        def check_polygon(points, width=0):
            assert len(points) >= 3
            for p in points:
                _check_point(p)

        self.draw = types.SimpleNamespace(
            rect=counted("rect", check_rect), line=counted("line", check_line),
            lines=counted("lines", check_lines), circle=counted("circle", check_circle),
            polygon=counted("polygon", check_polygon), ellipse=counted("ellipse", check_rect))
        self.transform = types.SimpleNamespace(
            scale=lambda surf, size: FakeSurface((int(size[0]), int(size[1]))))

        def set_mode(size, flags=0):
            pg.screen = FakeSurface(size)
            return pg.screen

        def flip():
            pg.frame += 1

        self.display = types.SimpleNamespace(
            set_mode=set_mode, set_caption=lambda text: setattr(pg, "caption", text), flip=flip)
        self.time = types.SimpleNamespace(Clock=lambda: Clock(frame_ms))
        self.event = types.SimpleNamespace(get=lambda: pg.script(pg.frame))

        class Pressed:
            def __getitem__(inner, code):
                return code in pg.held

        self.key = types.SimpleNamespace(
            get_pressed=lambda: Pressed(),
            name=lambda code: next((n[2:].lower() for n, c in _KEYS.items() if c == code), "key"))
        self.mouse = types.SimpleNamespace(get_pos=lambda: (0, 0))

    def __getattr__(self, name):
        if name.startswith("K_"):
            return key_code(name)
        raise AttributeError(name)      # например, mixer: приложение должно это пережить

    def init(self):
        pass

    def quit(self):
        self.quit_called = True


# ---- события ----

def key_down(pg, name):
    return types.SimpleNamespace(type=KEYDOWN, key=getattr(pg, name))


def mouse_down(x, y, button=1):
    return types.SimpleNamespace(type=MOUSEBUTTONDOWN, pos=(x, y), button=button)


def mouse_up(x, y, button=1):
    return types.SimpleNamespace(type=MOUSEBUTTONUP, pos=(x, y), button=button)


def mouse_move(x, y, left=True):
    return types.SimpleNamespace(type=MOUSEMOTION, pos=(x, y), buttons=(1 if left else 0, 0, 0))


def quit_event():
    return types.SimpleNamespace(type=QUIT)
