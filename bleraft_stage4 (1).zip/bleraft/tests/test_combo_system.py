import unittest

import settings
from combat.attacks import COMBOS
from combat.combo_system import ComboTracker

RECOVERY = 0.28
OPEN_FROM = lambda t: t + settings.COMBO_CANCEL_FRACTION * RECOVERY
DEADLINE = lambda t: t + RECOVERY + settings.COMBO_WINDOW_AFTER


class ComboTrackerTests(unittest.TestCase):
    def setUp(self):
        self.t = ComboTracker()

    def test_first_gesture_starts_a_chain(self):
        step = self.t.register("slash", 0.0)
        self.assertEqual((step.index, step.continued, step.finished), (0, False, None))
        self.assertEqual(self.t.history, ["slash"])

    def test_gesture_without_any_combo_leaves_no_chain(self):
        t = ComboTracker(combos=())
        t.register("slash", 0.0)
        self.assertEqual(t.history, [])

    def test_window_is_closed_while_attack_is_running(self):
        self.t.register("slash", 0.0)
        for now in (0.0, 0.2, 5.0):
            self.assertFalse(self.t.can_continue("sweep", now))

    def test_chain_does_not_time_out_while_attack_is_running(self):
        self.t.register("slash", 0.0)
        self.t.update(100.0)           # окно ещё не открывалось - сбрасывать нечего
        self.assertEqual(self.t.history, ["slash"])

    def test_window_opens_late_in_recovery_and_closes_after_grace(self):
        self.t.register("slash", 0.0)
        self.t.open_window(1.0, RECOVERY)
        self.assertFalse(self.t.can_continue("sweep", OPEN_FROM(1.0) - 0.01))   # рано
        self.assertTrue(self.t.can_continue("sweep", OPEN_FROM(1.0) + 0.001))
        self.assertTrue(self.t.can_continue("sweep", 1.0 + RECOVERY))           # после конца восстановления
        self.assertTrue(self.t.can_continue("sweep", DEADLINE(1.0) - 0.001))
        self.assertFalse(self.t.can_continue("sweep", DEADLINE(1.0) + 0.001))   # поздно

    def test_only_valid_continuations_are_accepted(self):
        self.t.register("slash", 0.0)
        self.t.open_window(1.0, RECOVERY)
        now = OPEN_FROM(1.0) + 0.01
        self.assertTrue(self.t.can_continue("sweep", now))     # slash -> sweep есть в комбо
        self.assertFalse(self.t.can_continue("double", now))   # slash -> double нет
        self.assertEqual(self.t.next_gestures(), {"sweep"})

    def test_continuing_extends_the_chain(self):
        self.t.register("slash", 0.0)
        self.t.open_window(1.0, RECOVERY)
        step = self.t.register("sweep", OPEN_FROM(1.0) + 0.01)
        self.assertEqual((step.index, step.continued), (1, True))
        self.assertEqual(self.t.history, ["slash", "sweep"])

    def test_full_combo_slash_sweep_double_ends_with_finisher(self):
        now = 0.0
        self.t.register("slash", now)
        for gesture in ("sweep", "double"):
            self.t.open_window(now, RECOVERY)
            now = OPEN_FROM(now) + 0.01
            step = self.t.register(gesture, now)
        self.assertTrue(step.continued)
        self.assertIsNotNone(step.finished)
        self.assertEqual(step.finished.name, "classic")
        self.assertEqual(self.t.history, [])           # цепочка закрыта

    def test_chain_times_out_after_window_closes(self):
        self.t.register("slash", 0.0)
        self.t.open_window(1.0, RECOVERY)
        self.t.update(DEADLINE(1.0) - 0.01)
        self.assertEqual(self.t.history, ["slash"])
        self.t.update(DEADLINE(1.0) + 0.01)
        self.assertEqual(self.t.history, [])

    def test_late_gesture_after_timeout_starts_a_fresh_chain(self):
        self.t.register("slash", 0.0)
        self.t.open_window(1.0, RECOVERY)
        step = self.t.register("sweep", DEADLINE(1.0) + 1.0)
        self.assertEqual((step.index, step.continued), (0, False))
        self.assertEqual(self.t.history, ["sweep"])

    def test_wrong_gesture_in_window_starts_a_new_chain_instead_of_breaking(self):
        self.t.register("slash", 0.0)
        self.t.open_window(1.0, RECOVERY)
        step = self.t.register("thrust", OPEN_FROM(1.0) + 0.01)
        self.assertEqual((step.index, step.continued), (0, False))
        self.assertEqual(self.t.history, ["thrust"])

    def test_reset_clears_everything(self):
        self.t.register("slash", 0.0)
        self.t.open_window(1.0, RECOVERY)
        self.t.reset()
        self.assertEqual(self.t.history, [])
        self.assertFalse(self.t.window_open(1.2))

    def test_every_configured_combo_can_be_executed(self):
        for combo in COMBOS:
            t = ComboTracker()
            now, step = 0.0, None
            for i, gesture in enumerate(combo.steps):
                step = t.register(gesture, now)
                if i < len(combo.steps) - 1:
                    t.open_window(now, RECOVERY)
                    now = OPEN_FROM(now) + 0.01
            self.assertIs(step.finished, combo)


if __name__ == "__main__":
    unittest.main()
