import os
import shutil
import tempfile
import types
import unittest

from audio.sfx import RATE, SOUND_DEFS, SoundBank, synth
from core.match_rules import MatchResult
from core.profile import MAX_MATCHES, Profile, Storage
from input.controls import ControlScheme
from tests.fake_pygame import FakePygame
from ui.pixel_font import GLYPH_H, GLYPH_W, GLYPHS, PixelFont, glyph


def result(outcome="victory", reason="ko", duration=62.4, dealt=80.0, taken=35.0, combo=4):
    return MatchResult(outcome, reason, duration, 40.0, 0.0,
                       {"damage_dealt": dealt, "damage_taken": taken, "max_combo": combo})


class TmpCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp, True)


class StorageTests(TmpCase):
    def test_save_and_load_roundtrip(self):
        st = Storage(self.tmp)
        self.assertTrue(st.save("a.json", {"x": [1, 2]}))
        self.assertEqual(st.load("a.json", {}), {"x": [1, 2]})

    def test_missing_corrupt_and_wrong_type_files_give_defaults(self):
        st = Storage(self.tmp)
        self.assertEqual(st.load("nope.json", {"d": 1}), {"d": 1})
        with open(os.path.join(self.tmp, "bad.json"), "w") as f:
            f.write("{ not json")
        self.assertEqual(st.load("bad.json", []), [])
        st.save("list.json", [1, 2])
        self.assertEqual(st.load("list.json", {}), {})

    def test_unwritable_location_does_not_raise(self):
        blocker = os.path.join(self.tmp, "file")
        open(blocker, "w").close()
        self.assertFalse(Storage(os.path.join(blocker, "sub")).save("a.json", {}))


class ProfileTests(TmpCase):
    def profile(self):
        return Profile(Storage(self.tmp))

    def test_defaults(self):
        p = self.profile()
        self.assertTrue(p.sound_on)
        self.assertAlmostEqual(p.volume, 0.7)
        self.assertEqual(p.difficulty, "normal")
        self.assertEqual(p.matches, [])

    def test_settings_persist_between_runs(self):
        p = self.profile()
        p.settings["sound_on"] = False
        p.set_volume(0.3)
        p.set_difficulty("hard")
        p.save_settings()
        q = self.profile()
        self.assertFalse(q.sound_on)
        self.assertAlmostEqual(q.volume, 0.3)
        self.assertEqual(q.difficulty, "hard")

    def test_volume_is_clamped_and_bad_values_ignored(self):
        p = self.profile()
        p.set_volume(5)
        self.assertEqual(p.volume, 1.0)
        p.set_volume(-1)
        self.assertEqual(p.volume, 0.0)
        Storage(self.tmp).save("settings.json", {"volume": "loud", "sound_on": 3, "junk": 1})
        q = self.profile()
        self.assertAlmostEqual(q.volume, 0.7)
        self.assertTrue(q.sound_on)

    def test_bindings_default_remap_swap_and_reset(self):
        pg = FakePygame()
        p = self.profile()
        self.assertEqual(p.bindings(pg)["p1_up"], pg.K_w)
        p.set_binding(pg, "p1_up", pg.K_i)
        self.assertEqual(p.bindings(pg)["p1_up"], pg.K_i)
        p.set_binding(pg, "p1_down", pg.K_i)               # занята -> действия меняются местами
        b = p.bindings(pg)
        self.assertEqual((b["p1_down"], b["p1_up"]), (pg.K_i, pg.K_s))
        self.assertFalse(p.set_binding(pg, "nonsense", 5))
        p.reset_bindings()
        self.assertEqual(p.bindings(pg)["p1_up"], pg.K_w)

    def test_bindings_persist_and_make_schemes(self):
        pg = FakePygame()
        p = self.profile()
        p.set_binding(pg, "p2_left", pg.K_j)
        p.save_settings()
        q = self.profile()
        one, two = q.schemes(pg)
        self.assertIsInstance(one, ControlScheme)
        self.assertEqual(one.up, pg.K_w)
        self.assertEqual(two.left, pg.K_j)
        self.assertEqual(two.right, pg.K_RIGHT)

    def test_record_and_summarize_real_matches(self):
        p = self.profile()
        p.record_match(result("victory", "ko"), "match", "normal")
        p.record_match(result("defeat", "ring_out", duration=30.0, dealt=10, taken=60, combo=2), "match", "hard")
        p.record_match(result("victory", "ring_out", duration=90.0, dealt=50, taken=0, combo=6), "match", "easy")
        p.record_match(result("victory", "ko", combo=9), "training", "normal")
        s = p.summary()
        self.assertEqual((s["played"], s["wins"], s["losses"], s["winrate"]), (3, 2, 1, 67))
        self.assertEqual(s["best_combo"], 9)
        self.assertEqual((s["damage_dealt"], s["damage_taken"]), (140, 95))
        self.assertEqual((s["ring_out_wins"], s["ring_out_losses"]), (1, 1))
        self.assertEqual(s["training"], 1)
        self.assertEqual(s["avg_duration"], 61)
        self.assertEqual(len(s["recent"]), 4)
        self.assertEqual(s["recent"][0]["mode"], "training")        # новые сверху

    def test_stats_survive_restart_and_are_limited(self):
        p = self.profile()
        for _ in range(MAX_MATCHES + 25):
            p.record_match(result(), "match", "normal")
        self.assertEqual(len(p.matches), MAX_MATCHES)
        self.assertEqual(len(self.profile().matches), MAX_MATCHES)

    def test_empty_summary(self):
        s = self.profile().summary()
        self.assertEqual((s["played"], s["winrate"], s["avg_duration"], s["best_combo"]), (0, 0, 0, 0))


class SynthTests(unittest.TestCase):
    def test_every_sound_has_valid_pcm(self):
        for name, args in SOUND_DEFS.items():
            data = synth(*args)
            self.assertEqual(len(data), int(RATE * args[2]) * 2, name)
            import array
            samples = array.array("h")
            samples.frombytes(data)
            self.assertGreater(max(abs(v) for v in samples), 500, name)
            self.assertLessEqual(max(abs(v) for v in samples), 32000, name)

    def test_synth_is_deterministic(self):
        self.assertEqual(synth(200, 70, 0.1, 0.5, "noise"), synth(200, 70, 0.1, 0.5, "noise"))

    def test_expected_game_sounds_exist(self):
        for name in ("click", "swing", "hit", "combo", "crack", "fall", "ringout", "win", "lose"):
            self.assertIn(name, SOUND_DEFS)


class SoundBankTests(TmpCase):
    def fake_mixer(self, fail=False):
        played = []

        class Sound:
            def __init__(self, buffer=None):
                self.volume = None

            def set_volume(self, v):
                self.volume = v

            def play(self):
                played.append(self.volume)

        def init(*a):
            if fail:
                raise RuntimeError("нет аудиоустройства")

        pg = FakePygame()
        pg.mixer = types.SimpleNamespace(get_init=lambda: None, init=init, Sound=Sound)
        return pg, played

    def test_no_mixer_means_silence_not_a_crash(self):
        bank = SoundBank(FakePygame(), Profile(Storage(self.tmp)))
        self.assertFalse(bank.available)
        self.assertFalse(bank.play("hit"))

    def test_init_failure_is_survived(self):
        pg, played = self.fake_mixer(fail=True)
        bank = SoundBank(pg, Profile(Storage(self.tmp)))
        self.assertFalse(bank.play("hit"))
        self.assertEqual(played, [])

    def test_plays_with_profile_volume_and_respects_mute(self):
        pg, played = self.fake_mixer()
        profile = Profile(Storage(self.tmp))
        bank = SoundBank(pg, profile)
        profile.set_volume(0.4)
        self.assertTrue(bank.play("hit"))
        self.assertEqual(played, [0.4])
        profile.settings["sound_on"] = False
        self.assertFalse(bank.play("hit"))
        self.assertEqual(len(played), 1)
        self.assertFalse(bank.play("unknown"))


class PixelFontTests(unittest.TestCase):
    def test_all_glyphs_are_5x7(self):
        for ch, rows in GLYPHS.items():
            self.assertEqual(len(rows), GLYPH_H, ch)
            self.assertTrue(all(len(r) == GLYPH_W for r in rows), ch)

    def test_cyrillic_and_latin_alphabets_are_complete(self):
        for ch in "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯЁ":
            self.assertIn(ch, GLYPHS, ch)
        for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 .,:!?-%/":
            self.assertIn(ch, GLYPHS, ch)

    def test_all_ui_strings_can_be_drawn(self):
        text = ("ИГРАТЬ ТРЕНИРОВКА СТАТИСТИКА НАСТРОЙКИ ВЫХОД ПОБЕДА! ПОРАЖЕНИЕ В ЛОББИ РЕВАНШ "
                "ЗВУК ГРОМКОСТЬ УПРАВЛЕНИЕ СБРОСИТЬ КЛАВИШИ НАЗАД ВКЛ ВЫКЛ ЛЁГКИЙ СРЕДНИЙ СЛОЖНЫЙ "
                "БОЙ ВНИМАНИЕ КРАЙ АРЕНЫ РАЗРУШИТСЯ ЧЕРЕЗ НОКАУТ РИНГ АУТ ПО ВРЕМЕНИ ПАУЗА "
                "ПРОДОЛЖИТЬ МАТЧ ЛОББИ COMBO! СЕРИЯ ИГРОК БОТ ЖЕСТОВ ВЕРНО ПОПАДАНИЙ")
        for ch in set(text.upper()):
            self.assertIn(ch, GLYPHS, "нет глифа " + ch)

    def test_unknown_char_falls_back_to_question_mark(self):
        self.assertEqual(glyph("~"), GLYPHS["?"])

    def test_measure(self):
        self.assertEqual(PixelFont.measure("", 3), (0, 21))
        self.assertEqual(PixelFont.measure("AB", 2), ((2 * 6 - 1) * 2, 14))

    def test_render_is_cached_and_sized(self):
        pg = FakePygame()
        font = PixelFont(pg)
        a = font.render("Привет", 3, (255, 255, 255))
        b = font.render("ПРИВЕТ", 3, (255, 255, 255))
        self.assertIs(a, b)
        self.assertEqual(a.size, PixelFont.measure("ПРИВЕТ", 3))

    def test_draw_anchors_and_shadow(self):
        pg = FakePygame()
        font = PixelFont(pg)
        screen = pg.Surface((400, 200))
        x, y, w, h = font.draw(screen, "ABC", 200, 100, 2, (255, 255, 255), (0, 0, 0), "center")
        self.assertEqual((x, y), (200 - w // 2, 100 - h // 2))
        self.assertEqual(len(screen.blits), 2)                         # тень и текст
        x, y, w, h = font.draw(screen, "ABC", 300, 10, 2, (255, 255, 255), None, "topright")
        self.assertEqual(x + w, 300)

    def test_cache_is_bounded(self):
        font = PixelFont(FakePygame())
        for i in range(600):
            font.render("N%d" % i, 1, (255, 255, 255))
        self.assertLessEqual(len(font._cache), 401)


if __name__ == "__main__":
    unittest.main()
