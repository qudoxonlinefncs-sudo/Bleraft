import unittest

import settings
from arena.arena import Arena


class ArenaTests(unittest.TestCase):
    def test_derived_properties(self):
        arena = Arena(100, 50, 400, 200)
        self.assertEqual(arena.right, 500)
        self.assertEqual(arena.bottom, 250)
        self.assertEqual(arena.center_x, 300)
        self.assertEqual(arena.center_y, 150)
        self.assertEqual(arena.bounds, (100, 50, 500, 250))

    def test_invalid_size_rejected(self):
        with self.assertRaises(ValueError):
            Arena(0, 0, 0, 100)
        with self.assertRaises(ValueError):
            Arena(0, 0, 100, -1)

    def test_from_settings_is_centered_and_inside_window(self):
        arena = Arena.from_settings()
        self.assertEqual(arena.width, settings.ARENA_WIDTH)
        self.assertEqual(arena.height, settings.ARENA_HEIGHT)
        self.assertEqual(arena.center_x, settings.WINDOW_WIDTH / 2)
        self.assertEqual(arena.center_y, settings.WINDOW_HEIGHT / 2)
        frame = settings.ARENA_FRAME
        self.assertGreaterEqual(arena.left - frame, 0)
        self.assertGreaterEqual(arena.top - frame, 0)
        self.assertLessEqual(arena.right + frame, settings.WINDOW_WIDTH)
        self.assertLessEqual(arena.bottom + frame, settings.WINDOW_HEIGHT)


if __name__ == "__main__":
    unittest.main()
