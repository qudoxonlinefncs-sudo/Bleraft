import math
import random
import unittest

import settings
from combat.attacks import tier_for_speed
from input.gesture_recognizer import (
    GestureRecognizer, normalize_path, path_length, resample,
)
from input.gesture_templates import DEFAULT_TEMPLATES, GestureTemplate
from tests.helpers import SHAPES, circle_points, polyline, shape_stroke, make_stroke

KNOWN = ("slash", "sweep", "thrust", "double")


class TemplateRecognitionTests(unittest.TestCase):
    def setUp(self):
        self.rec = GestureRecognizer()

    def test_each_template_is_recognized(self):
        for name in KNOWN:
            result = self.rec.recognize(shape_stroke(name))
            self.assertEqual(result.name, name, name)
            self.assertEqual(result.reason, "ok")
            self.assertLess(result.distance, 0.05)

    def test_each_template_is_recognized_when_drawn_backwards(self):
        for name in KNOWN:
            self.assertEqual(self.rec.recognize(shape_stroke(name, reverse=True)).name, name)

    def test_four_default_templates_exist(self):
        self.assertEqual({t.name for t in DEFAULT_TEMPLATES}, set(KNOWN))

    def test_gesture_can_be_drawn_anywhere_on_screen(self):
        for origin in ((150, 150), (640, 360), (1100, 600), (300, 650)):
            for name in KNOWN:
                self.assertEqual(
                    self.rec.recognize(shape_stroke(name, origin=origin)).name, name)

    def test_gesture_size_does_not_matter(self):
        for scale in (90, 200, 450, 900):
            for name in KNOWN:
                self.assertEqual(
                    self.rec.recognize(shape_stroke(name, scale=scale)).name, name)


class SlightlyDistortedTests(unittest.TestCase):
    def setUp(self):
        self.rec = GestureRecognizer()

    def test_small_rotation_is_tolerated(self):
        for name in ("slash", "sweep", "thrust"):
            for rot in (-10, -5, 5, 10):
                self.assertEqual(
                    self.rec.recognize(shape_stroke(name, rot_deg=rot)).name, name, (name, rot))
        for rot in (-12, -6, 6, 12):
            self.assertEqual(self.rec.recognize(shape_stroke("double", rot_deg=rot)).name, "double")

    def test_hand_jitter_is_tolerated(self):
        for name in KNOWN:
            for seed in range(5):
                result = self.rec.recognize(shape_stroke(name, noise=0.012, seed=seed))
                self.assertEqual(result.name, name, (name, seed))

    def test_v_with_different_proportions_is_tolerated(self):
        for sx, sy in ((1.4, 1.0), (0.8, 1.0), (1.0, 0.8), (1.0, 1.3)):
            self.assertEqual(
                self.rec.recognize(shape_stroke("double", sx=sx, sy=sy)).name, "double", (sx, sy))

    def test_uneven_drawing_speed_is_tolerated(self):
        # точки собраны неравномерно: сначала медленно, потом быстро
        pts = polyline(SHAPES["slash"], per_segment=80)
        uneven = [pts[i] for i in range(0, 40)] + [pts[i] for i in range(40, 81, 8)]
        stroke = make_stroke(uneven)
        self.assertEqual(self.rec.recognize(stroke).name, "slash")


class RejectionTests(unittest.TestCase):
    def setUp(self):
        self.rec = GestureRecognizer()

    def assertRejected(self, stroke, reasons=None):
        result = self.rec.recognize(stroke)
        self.assertIsNone(result.name)
        self.assertFalse(result.ok)
        if reasons:
            self.assertIn(result.reason, reasons)

    def test_unknown_shapes_are_rejected(self):
        for name in ("backslash", "L", "lambda", "zigzag"):
            for rot in (-10, 0, 10):
                self.assertRejected(shape_stroke(name, rot_deg=rot, noise=0.01),
                                    ("no_match", "ambiguous"))

    def test_circle_is_rejected(self):
        self.assertRejected(make_stroke(circle_points()), ("no_match", "ambiguous"))

    def test_scribble_is_rejected(self):
        rng = random.Random(3)
        for _ in range(10):
            scribble = [(rng.random(), rng.random()) for _ in range(60)]
            self.assertRejected(make_stroke(scribble), ("no_match", "ambiguous"))

    def test_too_short_gesture_is_rejected(self):
        self.assertRejected(shape_stroke("slash", scale=30), ("too_short",))

    def test_click_is_rejected(self):
        self.assertRejected([(100, 100, 0.0)], ("too_few_points",))
        self.assertRejected([(100, 100, 0.0), (100, 100, 0.05)], ("too_few_points",))

    def test_tiny_motion_with_many_points_is_rejected(self):
        wiggle = [(100 + (i % 3), 100 + (i % 2), i * 0.01) for i in range(30)]
        self.assertRejected(wiggle, ("too_short",))

    def test_instant_mouse_jump_is_rejected(self):
        pts = [(100 + i * 20, 100, 0.0) for i in range(20)]  # всё в один момент
        self.assertRejected(pts, ("too_quick",))

    def test_garbage_input_never_raises(self):
        for garbage in (
            [], None, 5, "abc", [(1, 2)], [None, None], [("a", "b", "c")],
            [(float("nan"), 0, 0)] * 10, [(float("inf"), 0, 0)] * 10,
            [(0, 0, 0)] * 100, [(1e308, 1e308, 0), (-1e308, -1e308, 1)] * 5,
        ):
            result = self.rec.recognize(garbage)
            self.assertIsNone(result.name, garbage)

    def test_nan_points_are_dropped_but_rest_is_used(self):
        stroke = shape_stroke("slash")
        stroke.insert(10, (float("nan"), 5.0, 0.1))
        self.assertEqual(self.rec.recognize(stroke).name, "slash")

    def test_ambiguous_gesture_between_two_templates_is_rejected(self):
        # ~21 градус от горизонтали: между `-` и `/`, надёжно не определить
        result = self.rec.recognize(shape_stroke("slash", rot_deg=-24))
        self.assertEqual(result.reason, "ambiguous")
        self.assertIsNone(result.name)


class SpeedTests(unittest.TestCase):
    def setUp(self):
        self.rec = GestureRecognizer()

    def test_fast_and_slow_gestures_are_distinguished(self):
        fast = self.rec.recognize(shape_stroke("slash", scale=200, duration=0.15))
        slow = self.rec.recognize(shape_stroke("slash", scale=200, duration=0.9))
        self.assertEqual(fast.name, "slash")
        self.assertEqual(slow.name, "slash")
        self.assertGreater(fast.speed, slow.speed)
        self.assertEqual(tier_for_speed(fast.speed), "fast")
        self.assertEqual(tier_for_speed(slow.speed), "slow")

    def test_medium_gesture(self):
        mid = self.rec.recognize(shape_stroke("slash", scale=200, duration=0.5))
        self.assertEqual(tier_for_speed(mid.speed), "medium")

    def test_speed_is_length_over_time_not_point_count(self):
        sparse = [p for i, p in enumerate(shape_stroke("sweep", duration=0.4)) if i % 4 == 0]
        sparse.append(shape_stroke("sweep", duration=0.4)[-1])
        dense = shape_stroke("sweep", duration=0.4)
        a, b = self.rec.recognize(sparse), self.rec.recognize(dense)
        self.assertAlmostEqual(a.speed, b.speed, delta=0.03 * b.speed)
        self.assertAlmostEqual(b.speed, 300 / 720 / 0.4, places=3)

    def test_speed_does_not_depend_on_screen_resolution(self):
        small = GestureRecognizer(reference_size=720)
        big = GestureRecognizer(reference_size=1440)
        a = small.recognize(shape_stroke("slash", scale=300, duration=0.3))
        b = big.recognize(shape_stroke("slash", scale=600, duration=0.3))
        self.assertEqual((a.name, b.name), ("slash", "slash"))
        self.assertAlmostEqual(a.speed, b.speed, places=6)

    def test_min_length_scales_with_reference_size(self):
        pts = shape_stroke("slash", scale=70)   # 70 px: достаточно при 720, мало при 1440
        self.assertEqual(GestureRecognizer(reference_size=720).recognize(pts).name, "slash")
        self.assertEqual(GestureRecognizer(reference_size=1440).recognize(pts).reason, "too_short")

    def test_tier_thresholds(self):
        self.assertEqual(tier_for_speed(settings.GESTURE_SPEED_FAST), "fast")
        self.assertEqual(tier_for_speed(settings.GESTURE_SPEED_SLOW), "slow")
        self.assertEqual(tier_for_speed(
            (settings.GESTURE_SPEED_FAST + settings.GESTURE_SPEED_SLOW) / 2), "medium")


class NormalizationTests(unittest.TestCase):
    def test_diagonal_is_not_distorted_and_is_centered(self):
        pts = normalize_path([(100, 500), (400, 200)], 64)   # `/`
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        self.assertAlmostEqual(max(xs) - min(xs), 1.0)
        self.assertAlmostEqual(max(ys) - min(ys), 1.0)
        self.assertAlmostEqual(sum(xs) / 64, 0.0, places=9)
        self.assertAlmostEqual(sum(ys) / 64, 0.0, places=9)

    def test_diagonals_of_any_position_and_size_normalize_equally(self):
        a = normalize_path([(100, 500), (400, 200)], 64)
        b = normalize_path([(1000, 90), (1090, 0)], 64)  # другой размер и место, то же направление
        for p, q in zip(a, b):
            self.assertAlmostEqual(p[0], q[0], places=6)
            self.assertAlmostEqual(p[1], q[1], places=6)

    def test_horizontal_line_stays_flat(self):
        pts = normalize_path([(0, 50), (200, 50)], 64)
        self.assertAlmostEqual(max(p[1] for p in pts) - min(p[1] for p in pts), 0.0)
        self.assertAlmostEqual(max(p[0] for p in pts) - min(p[0] for p in pts), 1.0)

    def test_degenerate_path_returns_none(self):
        self.assertIsNone(normalize_path([(5, 5), (5, 5), (5, 5)], 64))

    def test_resample_gives_equal_spacing_and_exact_count(self):
        pts = resample([(0, 0), (100, 0), (100, 100)], 41)
        self.assertEqual(len(pts), 41)
        gaps = [math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(pts, pts[1:])]
        self.assertAlmostEqual(path_length(pts), 200.0, delta=0.5)
        self.assertLess(max(gaps) - min(gaps), 5.0 + 1e-6)  # на углу хорда чуть короче


class ConfigurableTemplatesTests(unittest.TestCase):
    def test_new_template_can_be_added_without_changing_recognizer(self):
        rec = GestureRecognizer()
        rec.add_template(GestureTemplate("zig", ((0, 0), (1, 0.5), (0, 1), (1, 1.5)), "Z"))
        zig = shape_stroke(((0, 0), (1, 0.5), (0, 1), (1, 1.5)), noise=0.005)
        self.assertEqual(rec.recognize(make_stroke(polyline(((0, 0), (1, 0.5), (0, 1), (1, 1.5))))).name, "zig")
        self.assertEqual(rec.recognize(shape_stroke("slash")).name, "slash")
        self.assertTrue(zig)

    def test_recognizer_with_custom_template_set_only_knows_those(self):
        only_sweep = GestureRecognizer(templates=(DEFAULT_TEMPLATES[1],))
        self.assertEqual(only_sweep.recognize(shape_stroke("sweep")).name, "sweep")
        self.assertIsNone(only_sweep.recognize(shape_stroke("thrust")).name)

    def test_degenerate_template_is_rejected(self):
        with self.assertRaises(ValueError):
            GestureRecognizer().add_template(GestureTemplate("dot", ((1, 1), (1, 1)), "."))

    def test_non_reversible_template_matches_only_one_direction(self):
        rec = GestureRecognizer(templates=(
            GestureTemplate("down", ((0, 0), (0, 1)), "v", allow_reverse=False),))
        self.assertEqual(rec.recognize(shape_stroke("thrust")).name, "down")
        self.assertIsNone(rec.recognize(shape_stroke("thrust", reverse=True)).name)


if __name__ == "__main__":
    unittest.main()
