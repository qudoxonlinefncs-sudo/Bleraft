import math
import unittest

from combat.attacks import resolve_attack
from combat.hitbox import OrientedBox, attack_hitbox

THRUST = resolve_attack("thrust")       # reach 112, width 24, start_offset 10
SLASH = resolve_attack("slash")


def box_at(cx, cy, half=18):
    return (cx - half, cy - half, cx + half, cy + half)


class OrientedBoxTests(unittest.TestCase):
    def test_axis_aligned_corners(self):
        box = OrientedBox(100, 100, 1, 0, 50, 10)
        corners = sorted(box.corners())
        self.assertEqual(corners, [(50, 90), (50, 110), (150, 90), (150, 110)])

    def test_hits_target_in_front(self):
        hb = attack_hitbox(100, 100, (1, 0), THRUST)
        self.assertTrue(hb.intersects_box(box_at(180, 100)))

    def test_misses_target_too_far(self):
        hb = attack_hitbox(100, 100, (1, 0), THRUST)
        self.assertFalse(hb.intersects_box(box_at(300, 100)))

    def test_misses_target_behind(self):
        hb = attack_hitbox(100, 100, (1, 0), THRUST)
        self.assertFalse(hb.intersects_box(box_at(40, 100)))

    def test_misses_target_far_to_the_side(self):
        hb = attack_hitbox(100, 100, (1, 0), THRUST)
        self.assertFalse(hb.intersects_box(box_at(180, 140)))

    def test_hits_target_partly_overlapping_the_side(self):
        hb = attack_hitbox(100, 100, (1, 0), THRUST)
        self.assertTrue(hb.intersects_box(box_at(180, 125)))

    def test_touching_counts_as_a_hit(self):
        hb = attack_hitbox(100, 100, (1, 0), THRUST)   # правый край x = 222
        self.assertTrue(hb.intersects_box(box_at(240, 100)))
        self.assertFalse(hb.intersects_box(box_at(240.5, 100)))

    def test_all_four_directions(self):
        for facing, target in (((1, 0), (180, 100)), ((-1, 0), (20, 100)),
                               ((0, 1), (100, 180)), ((0, -1), (100, 20))):
            hb = attack_hitbox(100, 100, facing, THRUST)
            self.assertTrue(hb.intersects_box(box_at(*target)), facing)
            opposite = (200 - target[0], 200 - target[1])
            self.assertFalse(hb.intersects_box(box_at(*opposite)), facing)

    def test_diagonal_hitbox_hits_on_axis(self):
        c = math.sqrt(0.5)
        hb = attack_hitbox(100, 100, (c, c), THRUST)
        self.assertTrue(hb.intersects_box(box_at(100 + c * 100, 100 + c * 100)))

    def test_rotated_box_does_not_hit_in_empty_corner_of_its_bounding_rectangle(self):
        # простая проверка по габаритам дала бы здесь ложное попадание
        c = math.sqrt(0.5)
        hb = attack_hitbox(100, 100, (c, c), THRUST)
        tx = 100 + c * 100 + (-c) * 45
        ty = 100 + c * 100 + c * 45
        self.assertFalse(hb.intersects_box(box_at(tx, ty)))
        # а габаритный прямоугольник повёрнутого хитбокса с целью пересекается
        xs = [p[0] for p in hb.corners()]
        ys = [p[1] for p in hb.corners()]
        left, top, right, bottom = box_at(tx, ty)
        overlaps_bounding = (min(xs) <= right and left <= max(xs)
                             and min(ys) <= bottom and top <= max(ys))
        self.assertTrue(overlaps_bounding)

    def test_scale_shortens_the_box_from_the_near_edge(self):
        full = attack_hitbox(0, 0, (1, 0), THRUST)
        half = attack_hitbox(0, 0, (1, 0), THRUST, scale=0.5)
        self.assertAlmostEqual(half.half_length * 2, full.half_length)
        near_full = full.cx - full.half_length
        near_half = half.cx - half.half_length
        self.assertAlmostEqual(near_full, near_half)

    def test_zero_facing_falls_back_to_right(self):
        hb = attack_hitbox(0, 0, (0, 0), SLASH)
        self.assertEqual((hb.fx, hb.fy), (1.0, 0.0))

    def test_unnormalized_facing_is_normalized(self):
        hb = attack_hitbox(0, 0, (5, 0), SLASH)
        self.assertAlmostEqual(math.hypot(hb.fx, hb.fy), 1.0)


if __name__ == "__main__":
    unittest.main()
