import math
import unittest

import settings
from arena.arena import Arena
from combat.attacks import resolve_attack
from combat.combat_system import (
    BUSY, DEAD, HITSTUN, STARTED, UNKNOWN_GESTURE, CombatSystem,
)
from entities.fighter import Fighter, FighterState as S

ARENA = Arena(0, 0, 2000, 1000)   # большая арена: стены не мешают


def world(gap=60.0, y=500.0):
    blue = Fighter("blue", 500.0, y, 36, 280.0)
    red = Fighter("red", 500.0 + gap, y, 36, 280.0)
    return blue, red, CombatSystem([blue, red])


def tick(cs, dt=1 / 60):
    cs.update(dt)
    for f in cs.fighters:
        f.update(dt, (0, 0), ARENA.bounds)


def run_until(cs, predicate, limit=6.0, dt=1 / 60):
    for _ in range(int(limit / dt)):
        if predicate():
            return True
        tick(cs, dt)
    return predicate()


def run_for(cs, seconds, dt=1 / 60):
    for _ in range(int(round(seconds / dt))):
        tick(cs, dt)


class PhaseTests(unittest.TestCase):
    def test_request_starts_windup_without_any_damage(self):
        blue, red, cs = world()
        self.assertEqual(cs.request_attack(blue, "slash"), STARTED)
        self.assertEqual(blue.state, S.WINDUP)
        self.assertEqual(red.hp, red.max_hp)

    def test_phases_follow_windup_active_recovery_idle(self):
        blue, red, cs = world(gap=2000)
        cs.request_attack(blue, "slash")
        spec = blue.attack.spec
        seen = []
        started = {}
        for _ in range(240):
            tick(cs, 1 / 120)
            if not seen or seen[-1] != blue.state:
                seen.append(blue.state)
                started[blue.state] = cs.time
        self.assertEqual(seen, [S.WINDUP, S.ACTIVE, S.RECOVERY, S.IDLE])
        self.assertAlmostEqual(started[S.ACTIVE] - 0.0, spec.windup, delta=0.02)
        self.assertAlmostEqual(started[S.RECOVERY] - started[S.ACTIVE], spec.active, delta=0.02)
        self.assertAlmostEqual(started[S.IDLE] - started[S.RECOVERY], spec.recovery, delta=0.02)

    def test_no_damage_during_windup_only_in_active(self):
        blue, red, cs = world()
        cs.request_attack(blue, "slash")
        spec = blue.attack.spec
        dt = 1 / 120
        first_damage = None
        for _ in range(240):
            before = red.hp
            tick(cs, dt)
            if blue.state is S.WINDUP:
                self.assertEqual(red.hp, red.max_hp)      # в подготовке урона нет
            if red.hp < before and first_damage is None:
                first_damage = (cs.time, blue.state)
        self.assertIsNotNone(first_damage)
        time, state = first_damage
        self.assertIs(state, S.ACTIVE)
        self.assertGreaterEqual(time, spec.windup - 1e-9)
        self.assertLessEqual(time, spec.windup + dt + 1e-9)

    def test_attack_that_misses_deals_no_damage(self):
        blue, red, cs = world(gap=400)
        cs.request_attack(blue, "slash")
        run_for(cs, 1.0)
        self.assertEqual(red.hp, red.max_hp)

    def test_target_behind_attacker_is_not_hit(self):
        blue, red, cs = world(gap=60)
        cs.request_attack(blue, "slash")           # blue смотрит на red (вправо)
        red.x = blue.x - 60                        # ушёл за спину до конца подготовки
        run_for(cs, 1.0)
        self.assertEqual(red.hp, red.max_hp)


class SingleHitTests(unittest.TestCase):
    def pinned_run(self, gesture, tier="medium", dt=1 / 240):
        blue, red, cs = world(gap=50)
        cs.request_attack(blue, gesture, tier)
        x0 = red.x
        hits = 0
        for _ in range(int(1.5 / dt)):
            cs.update(dt)
            hits += len(cs.events)
            red.x, red.y, red.knock_vx, red.knock_vy = x0, 500.0, 0.0, 0.0  # цель не уходит
            red.state = S.IDLE if red.state is S.HITSTUN else red.state
        return blue, red, hits

    def test_one_hit_per_active_phase_even_if_target_stays_inside(self):
        for gesture in ("slash", "sweep", "thrust"):
            blue, red, hits = self.pinned_run(gesture)
            spec = resolve_attack(gesture)
            self.assertEqual(hits, 1, gesture)
            self.assertAlmostEqual(red.hp, red.max_hp - spec.damage, msg=gesture)

    def test_slow_attack_with_long_active_phase_still_hits_once(self):
        blue, red, hits = self.pinned_run("sweep", "slow")
        self.assertEqual(hits, 1)

    def test_double_strike_hits_once_per_window_so_twice(self):
        blue, red, hits = self.pinned_run("double")
        spec = resolve_attack("double")
        self.assertEqual(hits, 2)
        self.assertAlmostEqual(red.hp, red.max_hp - 2 * spec.damage)

    def test_next_attack_can_hit_again(self):
        blue, red, cs = world(gap=50)
        for _ in range(2):
            cs.request_attack(blue, "thrust")
            for _ in range(180):
                cs.update(1 / 60)
                red.x, red.knock_vx, red.knock_vy = 550.0, 0.0, 0.0
                if blue.state is S.IDLE:
                    break
        self.assertAlmostEqual(red.hp, red.max_hp - 2 * resolve_attack("thrust").damage)


class KnockbackTests(unittest.TestCase):
    def hit_and_settle(self, attacker_pos, target_pos):
        blue = Fighter("blue", attacker_pos[0], attacker_pos[1], 36, 280.0)
        red = Fighter("red", target_pos[0], target_pos[1], 36, 280.0)
        cs = CombatSystem([blue, red])
        cs.request_attack(blue, "thrust")
        run_for(cs, 1.2)
        return blue, red

    def test_target_is_pushed_away_to_the_right(self):
        blue, red = self.hit_and_settle((500, 500), (560, 500))
        self.assertGreater(red.x, 560 + 30)
        self.assertAlmostEqual(red.y, 500.0, places=6)

    def test_target_is_pushed_away_to_the_left(self):
        blue, red = self.hit_and_settle((500, 500), (440, 500))
        self.assertLess(red.x, 440 - 30)
        self.assertAlmostEqual(red.y, 500.0, places=6)

    def test_target_is_pushed_down_and_up(self):
        _, red = self.hit_and_settle((500, 500), (500, 560))
        self.assertGreater(red.y, 590)
        self.assertAlmostEqual(red.x, 500.0, places=6)
        _, red = self.hit_and_settle((500, 500), (500, 440))
        self.assertLess(red.y, 410)

    def test_diagonal_knockback_follows_attacker_to_target_line(self):
        blue, red = self.hit_and_settle((500, 500), (545, 545))
        self.assertGreater(red.x, 545 + 15)
        self.assertGreater(red.y, 545 + 15)
        self.assertAlmostEqual(red.x - 545, red.y - 545, places=6)

    def test_hit_event_carries_direction_and_data(self):
        blue, red, cs = world(gap=60)
        cs.request_attack(blue, "slash")
        events = []
        for _ in range(60):
            cs.update(1 / 60)
            events += cs.events
        self.assertEqual(len(events), 1)
        ev = events[0]
        self.assertIs(ev.attacker, blue)
        self.assertIs(ev.target, red)
        self.assertAlmostEqual(ev.dir_x, 1.0)
        self.assertAlmostEqual(ev.dir_y, 0.0)
        self.assertFalse(ev.finisher)

    def test_knockback_distance_matches_physics_and_is_stronger_for_slow(self):
        distances = {}
        for tier in ("fast", "slow"):
            blue, red, cs = world(gap=50)
            cs.request_attack(blue, "slash", tier)
            x0 = None
            for _ in range(240):
                cs.update(1 / 60)
                if x0 is None and cs.events:
                    x0 = red.x
                red.update(1 / 60, (0, 0), ARENA.bounds)
            distances[tier] = red.x - x0
            v = resolve_attack("slash", tier).knockback
            self.assertAlmostEqual(distances[tier], v * v / (2 * settings.KNOCKBACK_DECEL), delta=1.0)
        self.assertGreater(distances["slow"], distances["fast"])

    def test_knockback_cannot_push_through_arena_wall(self):
        arena = Arena(0, 0, 300, 200)
        blue = Fighter("blue", 200.0, 100.0, 36, 280.0)
        red = Fighter("red", 260.0, 100.0, 36, 280.0)
        cs = CombatSystem([blue, red])
        cs.request_attack(blue, "thrust", "slow")
        for _ in range(120):
            cs.update(1 / 60)
            for f in (blue, red):
                f.update(1 / 60, (0, 0), arena.bounds)
        self.assertLessEqual(red.x + 18, 300 + 1e-9)


class HitstunTests(unittest.TestCase):
    def test_hit_target_loses_control_for_hitstun_time(self):
        blue, red, cs = world(gap=60)
        cs.request_attack(blue, "slash")
        spec = blue.attack.spec
        self.assertTrue(run_until(cs, lambda: red.state is S.HITSTUN))
        t_hit = cs.time
        self.assertEqual(cs.request_attack(red, "thrust"), HITSTUN)
        self.assertEqual(red.move_factor, 0.0)
        self.assertTrue(run_until(cs, lambda: red.state is S.IDLE))
        self.assertAlmostEqual(cs.time - t_hit, spec.hitstun, delta=0.03)
        self.assertEqual(cs.request_attack(red, "thrust"), STARTED)

    def test_hit_interrupts_targets_attack_and_it_deals_no_damage(self):
        blue, red, cs = world(gap=60)
        cs.request_attack(red, "slash", "slow")        # красный долго готовится
        cs.request_attack(blue, "thrust", "fast")      # синий бьёт быстрее
        run_for(cs, 2.0)
        self.assertLess(red.hp, red.max_hp)
        self.assertEqual(blue.hp, blue.max_hp)
        self.assertIsNone(red.attack)

    def test_hit_resets_targets_combo_chain(self):
        blue, red, cs = world(gap=60)
        cs.request_attack(red, "slash", "slow")
        self.assertEqual(red.combo.history, ["slash"])
        cs.request_attack(blue, "thrust", "fast")
        run_until(cs, lambda: red.state is S.HITSTUN)
        self.assertEqual(red.combo.history, [])

    def test_simultaneous_hits_trade_damage_fairly(self):
        blue, red, cs = world(gap=60)
        cs.request_attack(blue, "slash")
        cs.request_attack(red, "slash")
        run_for(cs, 1.0)
        self.assertEqual(blue.hp, red.hp)
        self.assertLess(blue.hp, blue.max_hp)

    def test_hit_flash_is_set_and_fades(self):
        blue, red, cs = world(gap=60)
        cs.request_attack(blue, "slash")
        run_until(cs, lambda: red.hit_flash > 0)
        self.assertAlmostEqual(red.hit_flash, settings.HIT_FLASH_TIME)
        run_for(cs, settings.HIT_FLASH_TIME + 0.05)
        self.assertEqual(red.hit_flash, 0.0)


class SpamTests(unittest.TestCase):
    def collect_starts(self, gestures, seconds, dt=1 / 60):
        blue, red, cs = world(gap=3000)
        starts = []
        results = {}
        for i in range(int(seconds / dt)):
            gesture = gestures[i % len(gestures)] if len(gestures) > 1 else gestures[0]
            res = cs.request_attack(blue, gesture)
            results[res] = results.get(res, 0) + 1
            if res == STARTED:
                starts.append((cs.time, blue.attack.spec))
            tick(cs, dt)
        return starts, results

    def test_same_attack_cannot_be_repeated_without_recovery(self):
        for gesture in ("slash", "sweep", "thrust", "double"):
            starts, results = self.collect_starts([gesture], 6.0)
            cycle = resolve_attack(gesture).total_time
            gaps = [b[0] - a[0] for a, b in zip(starts, starts[1:])]
            self.assertTrue(gaps)
            self.assertGreaterEqual(min(gaps), cycle - 1 / 60 - 1e-9, gesture)
            self.assertLessEqual(len(starts), int(6.0 / cycle) + 1, gesture)
            self.assertGreater(results[BUSY], results[STARTED], gesture)

    def test_every_request_in_first_phases_is_rejected(self):
        blue, red, cs = world(gap=3000)
        cs.request_attack(blue, "thrust")
        spec = blue.attack.spec
        while blue.state in (S.WINDUP, S.ACTIVE):
            self.assertEqual(cs.request_attack(blue, "thrust"), BUSY)
            self.assertEqual(cs.request_attack(blue, "slash"), BUSY)
            tick(cs)
        self.assertEqual(blue.state, S.RECOVERY)

    def test_spamming_a_combo_sequence_is_still_limited(self):
        # самый быстрый возможный цикл: каждый следующий ввод в самом начале окна
        starts, _ = self.collect_starts(["slash", "sweep", "double"], 10.0)
        for (t0, spec), (t1, _) in zip(starts, starts[1:]):
            if spec.is_finisher:
                self.assertGreaterEqual(t1 - t0, spec.total_time - 1 / 60 - 1e-9)
            else:
                earliest = spec.windup + spec.active + settings.COMBO_CANCEL_FRACTION * spec.recovery
                self.assertGreaterEqual(t1 - t0, earliest - 1 / 60 - 1e-9)
        self.assertLess(len(starts), 10.0 / 0.4)    # заведомо меньше "по атаке на тик"

    def test_unknown_gesture_is_rejected_and_changes_nothing(self):
        blue, red, cs = world()
        self.assertEqual(cs.request_attack(blue, "banana"), UNKNOWN_GESTURE)
        self.assertEqual(cs.request_attack(blue, None), UNKNOWN_GESTURE)
        self.assertEqual(blue.state, S.IDLE)
        self.assertIsNone(blue.attack)
        run_for(cs, 0.5)


class ComboFlowTests(unittest.TestCase):
    def to_recovery(self, cs, f):
        self.assertTrue(run_until(cs, lambda: f.state is S.RECOVERY))
        return cs.time

    def test_followup_is_rejected_before_window_and_accepted_inside(self):
        blue, red, cs = world(gap=3000)
        cs.request_attack(blue, "slash")
        spec = blue.attack.spec
        t_rec = self.to_recovery(cs, blue)
        self.assertEqual(cs.request_attack(blue, "sweep"), BUSY)         # окно закрыто
        run_until(cs, lambda: cs.time >= t_rec + settings.COMBO_CANCEL_FRACTION * spec.recovery + 1 / 60)
        self.assertEqual(blue.state, S.RECOVERY)
        self.assertEqual(cs.request_attack(blue, "sweep"), STARTED)      # окно открыто
        self.assertEqual(blue.state, S.WINDUP)
        self.assertEqual(blue.combo.history, ["slash", "sweep"])

    def test_chain_input_cuts_recovery_short(self):
        blue, red, cs = world(gap=3000)
        cs.request_attack(blue, "slash")
        spec = blue.attack.spec
        t_rec = self.to_recovery(cs, blue)
        run_until(cs, lambda: cs.time >= t_rec + settings.COMBO_CANCEL_FRACTION * spec.recovery + 1 / 60)
        self.assertLess(cs.time - t_rec, spec.recovery)

    def test_wrong_gesture_in_window_is_rejected_during_recovery(self):
        blue, red, cs = world(gap=3000)
        cs.request_attack(blue, "slash")
        spec = blue.attack.spec
        t_rec = self.to_recovery(cs, blue)
        run_until(cs, lambda: cs.time >= t_rec + settings.COMBO_CANCEL_FRACTION * spec.recovery + 1 / 60)
        self.assertEqual(cs.request_attack(blue, "double"), BUSY)        # slash -> double не комбо
        self.assertEqual(blue.state, S.RECOVERY)

    def test_chain_resets_after_timeout(self):
        blue, red, cs = world(gap=3000)
        cs.request_attack(blue, "slash")
        spec = blue.attack.spec
        t_rec = self.to_recovery(cs, blue)
        deadline = t_rec + spec.recovery + settings.COMBO_WINDOW_AFTER
        run_until(cs, lambda: cs.time > deadline - 0.05)
        self.assertEqual(blue.combo.history, ["slash"])                  # ещё не сброшено
        run_until(cs, lambda: cs.time > deadline + 0.05)
        self.assertEqual(blue.combo.history, [])                         # сброшено тайм-аутом
        self.assertEqual(cs.request_attack(blue, "sweep"), STARTED)
        self.assertEqual(blue.combo.history, ["sweep"])                  # новая цепочка, не шаг 2
        self.assertFalse(blue.attack.spec.is_finisher)

    def test_window_after_recovery_still_continues_chain(self):
        blue, red, cs = world(gap=3000)
        cs.request_attack(blue, "slash")
        run_until(cs, lambda: blue.state is S.IDLE)
        self.assertEqual(cs.request_attack(blue, "sweep"), STARTED)
        self.assertEqual(blue.combo.history, ["slash", "sweep"])

    def run_classic(self, cs, blue):
        for gesture in ("slash", "sweep", "double"):
            run_until(cs, lambda: blue.state in (S.IDLE, S.RECOVERY) and cs.request_attack(blue, gesture) == STARTED)

    def test_full_combo_ends_in_finisher_with_its_own_longer_recovery(self):
        blue, red, cs = world(gap=3000)
        self.run_classic(cs, blue)
        spec = blue.attack.spec
        normal = resolve_attack("double")
        self.assertTrue(spec.is_finisher)
        self.assertEqual(spec.combo_name, "classic")
        self.assertGreater(spec.recovery, normal.recovery * 1.5)
        self.assertGreater(spec.damage, normal.damage)
        self.assertEqual(blue.combo.history, [])

    def test_finisher_recovery_cannot_be_cancelled(self):
        blue, red, cs = world(gap=3000)
        self.run_classic(cs, blue)
        spec = blue.attack.spec
        t_rec = self.to_recovery(cs, blue)
        run_until(cs, lambda: cs.time >= t_rec + 0.9 * spec.recovery)
        for gesture in ("slash", "sweep", "thrust", "double"):
            self.assertEqual(cs.request_attack(blue, gesture), BUSY)
        run_until(cs, lambda: blue.state is S.IDLE)
        self.assertEqual(cs.request_attack(blue, "slash"), STARTED)
        self.assertFalse(blue.attack.spec.is_finisher)

    def test_finisher_hit_event_is_marked(self):
        blue, red, cs = world(gap=50)
        self.run_classic(cs, blue)
        events = []
        for _ in range(180):
            cs.update(1 / 60)
            events += [e for e in cs.events if e.finisher]
        self.assertTrue(events or red.hp < red.max_hp)

    def test_combo_is_not_guaranteed_defender_acts_before_followup_and_it_whiffs(self):
        blue, red, cs = world(gap=60)
        cs.request_attack(blue, "slash")
        free_at = followup_active_at = None
        followup_started = False
        for _ in range(240):
            if not followup_started and cs.request_attack(blue, "sweep") == STARTED:
                followup_started = True
            tick(cs)
            if free_at is None and red.hp < red.max_hp and red.state is S.IDLE:
                free_at = cs.time
            if followup_started and followup_active_at is None and blue.state is S.ACTIVE:
                followup_active_at = cs.time
        self.assertIsNotNone(free_at)
        self.assertIsNotNone(followup_active_at)
        self.assertLess(free_at, followup_active_at - 0.1)    # защитник свободен заметно раньше
        self.assertAlmostEqual(red.hp, red.max_hp - resolve_attack("slash").damage)  # второй удар не достал

    def test_defender_can_sidestep_a_telegraphed_attack(self):
        blue, red, cs = world(gap=60)
        cs.request_attack(blue, "thrust")
        facing = blue.attack.facing
        for _ in range(8):
            tick(cs)
        red.y += 60                                   # шаг в сторону во время подготовки
        run_for(cs, 1.0)
        self.assertEqual(red.hp, red.max_hp)
        self.assertEqual(blue.attack.facing if blue.attack else facing, facing)


class FacingAndStateTests(unittest.TestCase):
    def test_fighters_face_each_other(self):
        blue, red, cs = world(gap=200)
        cs.update(1 / 60)
        self.assertAlmostEqual(blue.facing[0], 1.0)
        self.assertAlmostEqual(red.facing[0], -1.0)

    def test_facing_follows_opponent_around(self):
        blue, red, cs = world(gap=100)
        red.x, red.y = 500.0, 400.0           # красный теперь выше синего
        cs.update(1 / 60)
        self.assertAlmostEqual(blue.facing[0], 0.0)
        self.assertAlmostEqual(blue.facing[1], -1.0)

    def test_fighter_faces_nearest_enemy(self):
        blue = Fighter("blue", 500.0, 500.0, 36, 280.0)
        far = Fighter("red", 1200.0, 500.0, 36, 280.0)
        near = Fighter("red", 500.0, 700.0, 36, 280.0)
        cs = CombatSystem([blue, far, near])
        cs.update(1 / 60)
        self.assertAlmostEqual(blue.facing[1], 1.0)

    def test_facing_is_locked_during_attack(self):
        blue, red, cs = world(gap=100)
        cs.request_attack(blue, "slash")
        locked = blue.facing
        red.y += 80
        for _ in range(6):
            tick(cs)
        self.assertEqual(blue.facing, locked)
        self.assertEqual(blue.attack.facing, locked)

    def test_movement_factor_depends_on_state(self):
        blue, red, cs = world(gap=3000)
        cs.update(1 / 60)
        self.assertEqual(blue.move_factor, settings.MOVE_FACTOR_BY_STATE["idle"])
        cs.request_attack(blue, "thrust")
        cs.update(1 / 60)
        self.assertEqual(blue.move_factor, settings.MOVE_FACTOR_BY_STATE["windup"])
        run_until(cs, lambda: blue.state is S.ACTIVE)
        self.assertEqual(blue.move_factor, settings.MOVE_FACTOR_BY_STATE["active"])
        run_until(cs, lambda: blue.state is S.RECOVERY)
        self.assertEqual(blue.move_factor, settings.MOVE_FACTOR_BY_STATE["recovery"])

    def test_dead_fighter_cannot_act_or_be_hit_again(self):
        blue, red, cs = world(gap=60)
        red.hp = 3.0
        cs.request_attack(blue, "slash")
        run_until(cs, lambda: red.state is S.DEAD)
        self.assertEqual(red.hp, 0.0)
        self.assertFalse(red.alive)
        self.assertEqual(cs.request_attack(red, "slash"), DEAD)
        run_for(cs, 0.1)
        self.assertEqual(red.move_factor, 0.0)
        cs.request_attack(blue, "thrust")
        events = []
        for _ in range(120):
            cs.update(1 / 60)
            events += cs.events
        self.assertEqual(events, [])

    def test_hp_never_goes_below_zero(self):
        blue, red, cs = world(gap=50)
        red.hp = 1.0
        cs.request_attack(blue, "double", "slow")
        run_for(cs, 2.0)
        self.assertEqual(red.hp, 0.0)


class FrameRateIndependenceTests(unittest.TestCase):
    def scenario(self, dt):
        blue, red, cs = world(gap=60)
        cs.request_attack(blue, "slash")
        first_hit = None
        x_at_hit = None
        for _ in range(int(round(1.5 / dt))):
            cs.update(dt)
            if cs.events and first_hit is None:
                first_hit, x_at_hit = cs.time, red.x
            for f in (blue, red):
                f.update(dt, (0, 0), ARENA.bounds)
        return red.hp, red.x - x_at_hit, first_hit

    def test_same_outcome_at_different_step_sizes(self):
        windup = resolve_attack("slash").windup
        damage = resolve_attack("slash").damage
        for dt in (1 / 30, 1 / 60, 1 / 120, 1 / 240, 1 / 480):
            hp, pushed, first_hit = self.scenario(dt)
            self.assertAlmostEqual(hp, 100 - damage, msg=str(dt))
            self.assertAlmostEqual(pushed, 380 ** 2 / (2 * settings.KNOCKBACK_DECEL),
                                   delta=0.01, msg=str(dt))
            self.assertGreaterEqual(first_hit, windup - 1e-9)
            self.assertLessEqual(first_hit, windup + dt + 1e-9)


if __name__ == "__main__":
    unittest.main()
