import math
import unittest

import settings
from entities.fighter import Fighter, FighterState

BOUNDS = (0, 0, 2000, 1000)


def fighter(x=500.0, y=500.0):
    return Fighter("blue", x, y, 36, 200.0)


class FighterCombatFieldsTests(unittest.TestCase):
    def test_defaults(self):
        f = fighter()
        self.assertEqual(f.hp, settings.MAX_HP)
        self.assertEqual(f.max_hp, settings.MAX_HP)
        self.assertTrue(f.alive)
        self.assertEqual(f.state, FighterState.IDLE)
        self.assertEqual(f.move_factor, 1.0)
        self.assertIsNone(f.attack)

    def test_dead_is_not_alive(self):
        f = fighter()
        f.state = FighterState.DEAD
        self.assertFalse(f.alive)

    def test_box(self):
        self.assertEqual(fighter(100, 200).box, (82, 182, 118, 218))

    def test_custom_max_hp(self):
        self.assertEqual(Fighter("red", 0, 0, 36, 100, max_hp=50).hp, 50)


class MoveFactorTests(unittest.TestCase):
    def test_factor_scales_speed(self):
        f = fighter()
        f.move_factor = 0.25
        f.update(1.0, (1, 0), BOUNDS)
        self.assertAlmostEqual(f.x - 500, 50.0)

    def test_zero_factor_means_no_movement(self):
        f = fighter()
        f.move_factor = 0.0
        f.update(1.0, (1, 1), BOUNDS)
        self.assertEqual((f.x, f.y), (500.0, 500.0))

    def test_diagonal_is_still_normalized_with_factor(self):
        f = fighter()
        f.move_factor = 0.35
        f.update(1.0, (1, 1), BOUNDS)
        self.assertAlmostEqual(math.hypot(f.x - 500, f.y - 500), 200 * 0.35)


class KnockbackMotionTests(unittest.TestCase):
    def total_distance(self, dt, speed=600.0):
        f = fighter()
        f.knock_vx = speed
        for _ in range(int(round(2.0 / dt))):
            f.update(dt, (0, 0), BOUNDS)
        return f.x - 500, f

    def test_distance_is_physical_and_independent_of_step(self):
        expected = 600.0 ** 2 / (2 * settings.KNOCKBACK_DECEL)
        for dt in (1 / 20, 1 / 30, 1 / 60, 1 / 144, 1 / 480):
            distance, f = self.total_distance(dt)
            self.assertAlmostEqual(distance, expected, places=6, msg=str(dt))
            self.assertEqual((f.knock_vx, f.knock_vy), (0.0, 0.0))

    def test_knockback_in_any_direction(self):
        f = fighter()
        f.knock_vx, f.knock_vy = 300.0, -400.0     # скорость 500
        for _ in range(120):
            f.update(1 / 60, (0, 0), BOUNDS)
        d = 500.0 ** 2 / (2 * settings.KNOCKBACK_DECEL)
        self.assertAlmostEqual(f.x - 500, d * 0.6, places=6)
        self.assertAlmostEqual(f.y - 500, -d * 0.8, places=6)

    def test_knockback_slows_down(self):
        f = fighter()
        f.knock_vx = 600.0
        f.update(0.1, (0, 0), BOUNDS)
        self.assertAlmostEqual(f.knock_vx, 600 - settings.KNOCKBACK_DECEL * 0.1)

    def test_knockback_stops_at_wall(self):
        f = fighter(x=1950.0)
        f.knock_vx = 900.0
        for _ in range(60):
            f.update(1 / 60, (0, 0), BOUNDS)
        self.assertAlmostEqual(f.x, 2000 - 18)

    def test_knockback_and_walking_combine(self):
        f = fighter()
        f.knock_vx = 300.0
        f.update(0.05, (0, 1), BOUNDS)
        self.assertGreater(f.x, 500)
        self.assertGreater(f.y, 500)


if __name__ == "__main__":
    unittest.main()
