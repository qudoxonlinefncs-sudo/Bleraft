import types
import unittest

from core.gameplay import GameplayState
from core.match_rules import (
    DEFEAT, KO, RING_OUT, TIMEOUT, VICTORY, MatchRules, MatchStats,
)
from entities.fighter import Fighter, FighterState as S


def scene(time=10.0, stats=None):
    blue = Fighter("blue", 500.0, 500.0, 36, 280.0)
    red = Fighter("red", 700.0, 500.0, 36, 280.0)
    return types.SimpleNamespace(fighters=[blue, red], time=time, stats=stats or MatchStats())


def kill(fighter, ring_out=False):
    fighter.hp = 0.0 if not ring_out else fighter.hp
    fighter.state = S.DEAD
    fighter.ring_out = ring_out


class RulesTests(unittest.TestCase):
    def test_nothing_happens_while_both_alive(self):
        self.assertIsNone(MatchRules(0, 240).evaluate(scene()))

    def test_ko_of_the_enemy_is_a_victory(self):
        s = scene()
        kill(s.fighters[1])
        r = MatchRules(0, None).evaluate(s)
        self.assertEqual((r.outcome, r.reason), (VICTORY, KO))

    def test_ko_of_the_player_is_a_defeat(self):
        s = scene()
        kill(s.fighters[0])
        r = MatchRules(0, None).evaluate(s)
        self.assertEqual((r.outcome, r.reason), (DEFEAT, KO))

    def test_ring_out_reasons(self):
        s = scene()
        kill(s.fighters[1], ring_out=True)
        self.assertEqual(MatchRules(0).evaluate(s).reason, RING_OUT)
        s = scene()
        kill(s.fighters[0], ring_out=True)
        r = MatchRules(0).evaluate(s)
        self.assertEqual((r.outcome, r.reason), (DEFEAT, RING_OUT))

    def test_simultaneous_elimination_is_a_defeat(self):
        s = scene()
        kill(s.fighters[0])
        kill(s.fighters[1])
        self.assertEqual(MatchRules(0).evaluate(s).outcome, DEFEAT)

    def test_timeout_higher_hp_wins(self):
        s = scene(time=240.0)
        s.fighters[1].hp = 40.0
        r = MatchRules(0, 240.0).evaluate(s)
        self.assertEqual((r.outcome, r.reason), (VICTORY, TIMEOUT))
        s = scene(time=240.0)
        s.fighters[0].hp = 30.0
        self.assertEqual(MatchRules(0, 240.0).evaluate(s).outcome, DEFEAT)

    def test_timeout_tie_is_decided_by_damage_then_defeat(self):
        s = scene(time=240.0, stats=MatchStats(damage_dealt=20.0, damage_taken=20.0))
        s.fighters[0].hp = s.fighters[1].hp = 80.0
        self.assertEqual(MatchRules(0, 240.0).evaluate(s).outcome, DEFEAT)
        s.stats.damage_dealt = 25.0
        self.assertEqual(MatchRules(0, 240.0).evaluate(s).outcome, VICTORY)

    def test_no_time_limit_means_training_never_times_out(self):
        self.assertIsNone(MatchRules(0, None).evaluate(scene(time=99999.0)))

    def test_not_over_just_before_time_limit(self):
        self.assertIsNone(MatchRules(0, 240.0).evaluate(scene(time=239.9)))

    def test_result_carries_stats_and_hp(self):
        s = scene(time=42.0, stats=MatchStats(damage_dealt=33.0, max_combo=4))
        kill(s.fighters[1])
        r = MatchRules(0).evaluate(s)
        self.assertEqual(r.duration, 42.0)
        self.assertEqual(r.stats["damage_dealt"], 33.0)
        self.assertEqual(r.stats["max_combo"], 4)
        self.assertEqual(r.player_hp, 100.0)


class NoMove:
    def direction(self, i):
        return (0, 0)


class CountingBot:
    def __init__(self):
        self.calls = 0

    def think(self, scene, index, dt):
        self.calls += 1
        from ai.bot import Intent
        return Intent((0, 0))

    def reset(self):
        pass


class MatchEndsForRealTests(unittest.TestCase):
    def make(self, limit=None):
        bot = CountingBot()
        s = GameplayState(NoMove(), controllers={1: bot}, rules=MatchRules(0, limit))
        blue, red = s.fighters
        red.x = red.prev_x = blue.x + 60
        red.y = red.prev_y = blue.y
        return s, bot

    def test_player_wins_by_dealing_real_damage(self):
        s, bot = self.make()
        s.fighters[1].hp = 5.0
        s.perform_gesture(0, "slash")
        for _ in range(60):
            s.update(1 / 60)
        self.assertEqual(s.result.outcome, VICTORY)
        self.assertEqual(s.result.reason, KO)
        self.assertEqual(s.stats.hits_landed, 1)

    def test_player_loses_when_the_bot_lands_the_last_hit(self):
        s, bot = self.make()
        s.fighters[0].hp = 5.0
        s.perform_gesture(1, "slash")
        for _ in range(60):
            s.update(1 / 60)
        self.assertEqual(s.result.outcome, DEFEAT)
        self.assertEqual(s.stats.hits_taken, 1)

    def test_everything_stops_after_the_result(self):
        s, bot = self.make()
        s.fighters[1].hp = 5.0
        s.perform_gesture(0, "slash")
        for _ in range(60):
            s.update(1 / 60)
        self.assertIsNotNone(s.result)
        calls = bot.calls
        frozen = [(f.x, f.y, f.hp, f.state) for f in s.fighters]
        t = s.time
        s.input = type("I", (), {"direction": staticmethod(lambda i: (1, 0))})()
        s.perform_gesture(0, "thrust")
        for _ in range(120):
            s.update(1 / 60)
        self.assertEqual(bot.calls, calls)                     # ИИ остановлен
        self.assertEqual([(f.x, f.y, f.hp, f.state) for f in s.fighters], frozen)
        self.assertEqual(s.time, t)                            # бой остановлен

    def test_input_is_ignored_after_the_result(self):
        s, _ = self.make()
        s.fighters[1].hp = 1.0
        s.perform_gesture(0, "slash")
        for _ in range(60):
            s.update(1 / 60)
        from input.commands import StrokeCommand
        from input.gesture_recorder import Stroke
        from tests.helpers import shape_stroke

        class FakeInput:
            def handle_event(self, event, now):
                return [StrokeCommand(0, Stroke(tuple(shape_stroke("sweep", scale=200))))]

        s.command_input = FakeInput()
        before = s.fighters[0].attack
        s.handle_event(object())
        self.assertIs(s.fighters[0].attack, before)

    def test_time_limit_ends_the_match_by_hp(self):
        s, bot = self.make(limit=10.0)
        s.fighters[1].hp = 50.0
        for _ in range(60 * 11):
            s.update(1 / 60)
        self.assertEqual((s.result.outcome, s.result.reason), (VICTORY, TIMEOUT))

    def test_reset_also_resets_the_bot(self):
        s, bot = self.make()
        bot.resets = 0
        bot.reset = lambda: setattr(bot, "resets", bot.resets + 1)
        s.reset()
        self.assertEqual(bot.resets, 1)

    def test_reset_also_restores_the_arena_floor(self):
        from arena.arena import Arena
        from arena.floor import ArenaFloor
        arena = Arena.from_settings()
        arena.attach_floor(ArenaFloor(arena))
        s = GameplayState(NoMove(), arena=arena)
        for _ in range(int(40 * 60)):
            s.update(1 / 60)
        self.assertEqual(arena.floor.rings_fallen, 1)
        s.reset()
        self.assertEqual((arena.floor.rings_fallen, arena.floor.time), (0, 0.0))
        self.assertEqual(arena.bounds, (arena.left, arena.top, arena.right, arena.bottom))

    def test_reset_starts_a_clean_match(self):
        s, bot = self.make()
        s.fighters[1].hp = 1.0
        s.perform_gesture(0, "slash")
        for _ in range(60):
            s.update(1 / 60)
        s.reset()
        self.assertIsNone(s.result)
        self.assertEqual([f.hp for f in s.fighters], [100.0, 100.0])
        self.assertEqual(s.time, 0.0)
        self.assertEqual(s.stats.hits_landed, 0)
        self.assertTrue(all(not r.active for r in s.rush))


if __name__ == "__main__":
    unittest.main()
