import math
import unittest

from core.loop import FixedStepLoop
from entities.fighter import Fighter

BOUNDS = (0, 0, 1000, 600)


def make_fighter(x=500, y=300):
    return Fighter("blue", x, y, size=40, speed=200.0)


class FighterMovementTests(unittest.TestCase):
    def test_moves_in_each_direction(self):
        for direction, expected in (
            ((1, 0), (600, 300)),
            ((-1, 0), (400, 300)),
            ((0, 1), (500, 400)),
            ((0, -1), (500, 200)),
        ):
            f = make_fighter()
            f.update(0.5, direction, BOUNDS)
            self.assertAlmostEqual(f.x, expected[0])
            self.assertAlmostEqual(f.y, expected[1])

    def test_diagonal_speed_equals_straight_speed(self):
        f = make_fighter()
        f.update(1.0, (1, 1), BOUNDS)
        self.assertAlmostEqual(math.hypot(f.x - 500, f.y - 300), 200.0)

    def test_standing_still(self):
        f = make_fighter()
        f.update(1.0, (0, 0), BOUNDS)
        self.assertEqual((f.x, f.y), (500, 300))

    def test_speed_independent_of_frame_rate(self):
        for fps in (30, 60, 144, 240):
            f = make_fighter(x=100)
            loop = FixedStepLoop(60, 0.25)
            for _ in range(fps):  # ровно 1 секунда кадров
                loop.advance(1.0 / fps, lambda dt: f.update(dt, (1, 0), BOUNDS))
            # допускается расхождение максимум в один тик логики
            self.assertAlmostEqual(f.x - 100, 200.0, delta=200.0 / 60 + 1e-6)


class FighterBoundaryTests(unittest.TestCase):
    def run_into(self, direction, start=(500, 300), seconds=10):
        f = make_fighter(*start)
        for _ in range(60 * seconds):
            f.update(1 / 60, direction, BOUNDS)
        return f

    def test_stops_at_each_wall(self):
        self.assertAlmostEqual(self.run_into((-1, 0)).x, 20)    # 0 + половина размера
        self.assertAlmostEqual(self.run_into((1, 0)).x, 980)
        self.assertAlmostEqual(self.run_into((0, -1)).y, 20)
        self.assertAlmostEqual(self.run_into((0, 1)).y, 580)

    def test_stops_in_each_corner(self):
        f = self.run_into((1, 1))
        self.assertAlmostEqual(f.x, 980)
        self.assertAlmostEqual(f.y, 580)
        f = self.run_into((-1, -1))
        self.assertAlmostEqual(f.x, 20)
        self.assertAlmostEqual(f.y, 20)

    def test_slides_along_wall_when_moving_diagonally(self):
        f = make_fighter(x=25, y=300)
        f.update(0.5, (-1, 1), BOUNDS)
        self.assertAlmostEqual(f.x, 20)   # упёрся в левую стену
        self.assertGreater(f.y, 300)      # но продолжил идти вниз

    def test_huge_step_cannot_tunnel_through_wall(self):
        f = make_fighter(x=900)
        f.update(100.0, (1, 0), BOUNDS)
        self.assertAlmostEqual(f.x, 980)

    def test_never_leaves_bounds_with_random_like_input(self):
        f = make_fighter()
        pattern = [(1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1), (0, -1), (1, -1)]
        for i in range(5000):
            f.update(1 / 60, pattern[(i // 17) % len(pattern)], BOUNDS)
            self.assertTrue(20 <= f.x <= 980)
            self.assertTrue(20 <= f.y <= 580)


class FighterInterpolationTests(unittest.TestCase):
    def test_render_position_interpolates_between_ticks(self):
        f = make_fighter(x=100)
        f.update(0.5, (1, 0), BOUNDS)  # 100 -> 200
        self.assertAlmostEqual(f.render_position(0.0)[0], 100)
        self.assertAlmostEqual(f.render_position(0.5)[0], 150)
        self.assertAlmostEqual(f.render_position(1.0)[0], 200)

    def test_render_position_before_any_update_is_spawn_point(self):
        f = make_fighter(x=123, y=45)
        self.assertEqual(f.render_position(0.7), (123, 45))


if __name__ == "__main__":
    unittest.main()
