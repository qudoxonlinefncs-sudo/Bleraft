"""Отрисовка этапа 4 на подделке pygame: что именно рисуется и в каких условиях."""

import types
import unittest

import settings
from arena.arena import Arena
from arena.floor import ArenaFloor
from combat.combo_rush import ComboRush
from core.gameplay import create_fighters
from entities.fighter import FighterState as S
from tests.fake_pygame import FakePygame
from ui import palette
from ui.combat_view import CombatView
from ui.effects import Effects
from ui.floor_view import FloorView
from ui.match_hud import MatchHud, format_time
from ui.renderer import SceneRenderer


def recording_pg():
    pg = FakePygame()
    pg.rects, pg.lines = [], []
    orig_rect, orig_line = pg.draw.rect, pg.draw.line

    def rect(surface, color, r, *a):
        pg.rects.append((tuple(color), tuple(r), a[0] if a else 0))
        orig_rect(surface, color, r, *a)

    def line(surface, color, p0, p1, *a):
        pg.lines.append((tuple(color), p0, p1))
        orig_line(surface, color, p0, p1, *a)

    pg.draw.rect, pg.draw.line = rect, line
    return pg


def arena_floor(**kw):
    arena = Arena.from_settings()
    floor = ArenaFloor(arena, **kw)
    arena.attach_floor(floor)
    return arena, floor


def run(floor, seconds):
    for _ in range(int(round(seconds * 60))):
        floor.update(1 / 60)


class FloorViewTests(unittest.TestCase):
    def setUp(self):
        self.pg = recording_pg()
        self.view = FloorView(self.pg)
        self.screen = self.pg.Surface((1280, 720))
        self.arena, self.floor = arena_floor()

    def test_layer_is_blitted_at_the_arena_position(self):
        self.view.draw(self.screen, self.floor)
        layer, pos = self.screen.blits[0]
        self.assertEqual(pos, (int(self.arena.left), int(self.arena.top)))
        self.assertEqual(layer.size, (self.arena.width, self.arena.height))

    def test_layer_is_cached_until_the_floor_changes(self):
        self.view.draw(self.screen, self.floor)
        made = self.pg.surfaces_created
        for _ in range(5):
            self.view.draw(self.screen, self.floor)
        self.assertEqual(self.pg.surfaces_created, made)
        run(self.floor, 28.0)                                  # появились трещины
        self.view.draw(self.screen, self.floor)
        self.assertEqual(self.pg.surfaces_created, made + 1)

    def test_visible_border_is_drawn_every_frame_at_the_safe_bounds(self):
        self.view.draw(self.screen, self.floor)
        l, t, r, b = self.arena.bounds
        rim = [x for x in self.pg.rects if x[0] in (palette.RIM_DARK, palette.RIM_LIGHT, palette.RIM_GLOW)]
        self.assertEqual(len(rim), 3)
        self.assertTrue(any(x[1] == (l - 1, t - 1, r - l + 2, b - t + 2) for x in rim))

    def test_border_moves_inward_after_collapse(self):
        run(self.floor, 31.0)
        self.pg.rects.clear()
        self.view.draw(self.screen, self.floor)
        l, t, r, b = self.arena.bounds
        self.assertEqual(l, self.arena.left + 30)
        self.assertTrue(any(x[1] == (l - 1, t - 1, r - l + 2, b - t + 2) for x in self.pg.rects))

    def test_cracks_are_drawn_on_cracked_tiles_only(self):
        self.view.draw(self.screen, self.floor)
        self.assertEqual([x for x in self.pg.lines if x[0] == palette.CRACK], [])
        run(self.floor, 28.0)
        self.pg.lines.clear()
        self.view.draw(self.screen, self.floor)
        cracks = [x for x in self.pg.lines if x[0] == palette.CRACK]
        self.assertEqual(len(cracks), 2 * len(self.floor.ring_tiles(0)))

    def test_warning_frame_blinks_between_two_colors(self):
        run(self.floor, 27.5)
        colors = set()
        for i in range(30):
            self.floor.update(1 / 60)
            self.pg.rects.clear()
            self.view.draw(self.screen, self.floor)
            colors |= {x[0] for x in self.pg.rects if x[0] in (palette.WARN_A, palette.WARN_B)}
        self.assertEqual(colors, {palette.WARN_A, palette.WARN_B})

    def test_no_warning_frame_when_nothing_is_about_to_fall(self):
        self.view.draw(self.screen, self.floor)
        self.assertEqual([x for x in self.pg.rects if x[0] in (palette.WARN_A, palette.WARN_B)], [])

    def test_falling_tiles_are_animated_and_then_disappear(self):
        run(self.floor, 30.3)
        self.pg.rects.clear()
        self.view.draw(self.screen, self.floor)
        falling = len(self.floor.fall_started)
        self.assertGreater(falling, 0)
        self.assertGreaterEqual(len(self.pg.rects), falling)
        run(self.floor, 1.2)
        self.pg.rects.clear()
        self.view.draw(self.screen, self.floor)
        self.assertEqual(len(self.floor.fall_started), 0)
        self.assertEqual(len(self.pg.rects), 3)                  # осталась только граница

    def test_drawing_cost_stays_small(self):
        run(self.floor, 30.3)
        self.pg.rects.clear()
        self.view.draw(self.screen, self.floor)
        self.assertLess(len(self.pg.rects), 150)


class RendererWithFloorTests(unittest.TestCase):
    def test_renderer_uses_the_floor_view_and_draws_fighters(self):
        pg = recording_pg()
        arena, floor = arena_floor()
        fighters = create_fighters(arena)
        screen = pg.Surface((1280, 720))
        SceneRenderer(pg).draw(screen, arena, fighters, 1.0)
        self.assertEqual(screen.blits[0][1], (int(arena.left), int(arena.top)))
        self.assertEqual(len(screen.blits), 1 + 2 * len(fighters))

    def test_ring_out_fighter_shrinks_and_then_is_hidden(self):
        pg = recording_pg()
        arena, floor = arena_floor()
        fighters = create_fighters(arena)
        red = fighters[1]
        red.state, red.ring_out = S.DEAD, True
        renderer = SceneRenderer(pg)
        sizes = []
        for t in (0.0, 0.3, 0.6):
            red.ring_out_time = t
            screen = pg.Surface((1280, 720))
            renderer.draw(screen, arena, fighters, 1.0)
            sizes.append(max(b[0].size[0] for b in screen.blits[-1:]))
        sprite_sizes = [s for s in sizes]
        self.assertGreater(sprite_sizes[0], 0)
        red.ring_out_time = settings.RING_OUT_FALL_TIME + 0.1
        screen = pg.Surface((1280, 720))
        renderer.draw(screen, arena, fighters, 1.0)
        self.assertEqual(len(screen.blits), 1 + 2)                 # пол + тень и спрайт живого бойца

    def test_stage2_static_arena_path_is_unchanged(self):
        pg = recording_pg()
        arena = Arena.from_settings()
        screen = pg.Surface((1280, 720))
        SceneRenderer(pg).draw(screen, arena, create_fighters(arena), 1.0)
        self.assertEqual(screen.blits[0][1], (int(arena.left) - settings.ARENA_FRAME,
                                               int(arena.top) - settings.ARENA_FRAME))


class StubFont:
    def __init__(self):
        self.texts = []

    def draw(self, surface, text, x, y, scale=2, color=(255, 255, 255), shadow=None, anchor="topleft"):
        self.texts.append((text, scale, tuple(color)))
        return (x, y, 1, 1)


def hud_scene(rush_counts=(0, 0), floor=True, time=0.0):
    arena, fl = arena_floor()
    fighters = create_fighters(arena)
    rushes = []
    for count in rush_counts:
        r = ComboRush()
        for i in range(count):
            r.register(time + 0.1 * i)
        rushes.append(r)
    return types.SimpleNamespace(arena=arena, floor=fl if floor else None, fighters=fighters,
                                 rush=rushes, time=time), fl


class HudTests(unittest.TestCase):
    def setUp(self):
        self.pg = recording_pg()
        self.font = StubFont()
        self.hud = MatchHud(self.pg, self.font)
        self.screen = self.pg.Surface((1280, 720))

    def texts(self):
        return [t[0] for t in self.font.texts]

    def draw(self, scene, limit=240.0):
        self.font.texts.clear()
        self.hud.draw(self.screen, scene, limit)

    def test_format_time(self):
        self.assertEqual(format_time(240), "4:00")
        self.assertEqual(format_time(59.2), "1:00")
        self.assertEqual(format_time(0), "0:00")
        self.assertEqual(format_time(-5), "0:00")

    def test_match_timer_counts_down_and_turns_red(self):
        scene, _ = hud_scene(time=0.0)
        self.draw(scene)
        self.assertIn("4:00", self.texts())
        scene.time = 215.0
        self.draw(scene)
        timer = [t for t in self.font.texts if t[0] == "0:25"]
        self.assertTrue(timer)
        self.assertEqual(timer[0][2], palette.UI_RED)

    def test_training_shows_label_instead_of_timer(self):
        scene, _ = hud_scene()
        self.draw(scene, limit=None)
        self.assertIn("ТРЕНИРОВКА", self.texts())
        self.assertFalse([t for t in self.texts() if ":" in t])

    def test_names_above_health_bars(self):
        scene, _ = hud_scene()
        self.draw(scene)
        self.assertIn("ИГРОК", self.texts())
        self.assertIn("БОТ", self.texts())

    def test_collapse_warning_shows_countdown_during_the_warning(self):
        scene, floor = hud_scene()
        run(floor, 27.4)
        scene.time = floor.time
        self.draw(scene)
        warning = [t for t in self.texts() if t.startswith("ВНИМАНИЕ")]
        self.assertEqual(len(warning), 1)
        self.assertTrue(warning[0].endswith("3"))

    def test_quiet_countdown_only_in_the_last_ten_seconds(self):
        scene, floor = hud_scene()
        run(floor, 5.0)
        self.draw(scene)
        self.assertFalse([t for t in self.texts() if t.startswith("КРАЙ")])
        run(floor, 17.0)
        self.draw(scene)
        self.assertTrue([t for t in self.texts() if t.startswith("КРАЙ")])

    def test_no_collapse_text_when_arena_does_not_collapse(self):
        arena, floor = arena_floor(enabled=False)
        scene = types.SimpleNamespace(arena=arena, floor=floor, fighters=create_fighters(arena),
                                      rush=[ComboRush(), ComboRush()], time=29.0)
        self.draw(scene)
        self.assertFalse([t for t in self.texts() if "КРАЙ" in t])

    def test_rush_panel_shows_count_and_time_but_no_combo_before_third(self):
        scene, _ = hud_scene(rush_counts=(2, 0), time=5.0)
        self.draw(scene)
        self.assertIn("СЕРИЯ x2", self.texts())
        self.assertNotIn("COMBO!", self.texts())

    def test_combo_banner_from_the_third_gesture(self):
        scene, _ = hud_scene(rush_counts=(3, 0), time=5.0)
        self.draw(scene)
        self.assertIn("COMBO!", self.texts())
        self.assertIn("x3", self.texts())

    def test_combo_banner_pops_on_continuation(self):
        scene, _ = hud_scene(rush_counts=(3, 0), time=5.0)
        rush = scene.rush[0]
        sizes = []
        for dt in (0.0, 0.2, 0.5):
            scene.time = rush.last_event.time + dt
            self.draw(scene)
            sizes.append(next(t[1] for t in self.font.texts if t[0] == "COMBO!"))
        self.assertEqual(sizes, [8, 7, 6])

    def test_no_rush_panel_without_a_chain(self):
        scene, _ = hud_scene()
        self.draw(scene)
        self.assertFalse([t for t in self.texts() if t.startswith("СЕРИЯ")])

    def test_time_bar_shrinks_as_time_runs_out(self):
        scene, _ = hud_scene(rush_counts=(1, 0), time=0.0)
        widths = []
        for t in (0.0, 1.5, 2.8):
            scene.time = t
            self.pg.rects.clear()
            self.draw(scene)
            fills = [r for r in self.pg.rects if r[0] in (palette.UI_GREEN, palette.UI_ORANGE, palette.UI_RED)
                     and r[1][3] == 8]
            widths.append(fills[0][1][2] if fills else 0)
        self.assertGreater(widths[0], widths[1])
        self.assertGreater(widths[1], widths[2])


class IndicatorFeedbackTests(unittest.TestCase):
    def draw(self, ind_args, age=0.0, font=None):
        pg = recording_pg()
        view = CombatView(pg, font=font)
        arena = Arena.from_settings()
        fx = Effects()
        fx.set_indicator(0, *ind_args)
        fx.indicators[0].age = age
        scene = types.SimpleNamespace(fighters=create_fighters(arena), arena=arena, effects=fx, trail=[])
        view.draw(pg.Surface((1280, 720)), scene, 1.0)
        return pg

    def border_colors(self, pg):
        return {r[0] for r in pg.rects if r[1][2] == 44 and r[1][3] == 44 and r[2] == 2}

    def test_recognized_gesture_flashes_green_then_calms_down(self):
        self.assertIn(palette.UI_GREEN, self.border_colors(self.draw(("slash", "medium", True), 0.0)))
        self.assertNotIn(palette.UI_GREEN, self.border_colors(self.draw(("slash", "medium", True), 0.6)))

    def test_error_is_red_and_ambiguous_is_orange_with_question_mark(self):
        self.assertIn(palette.UI_RED, self.border_colors(self.draw((None, None, False, "no_match"))))
        font = StubFont()
        pg = self.draw((None, None, False, "ambiguous"), font=font)
        self.assertIn(palette.UI_ORANGE, self.border_colors(pg))
        self.assertIn("?", [t[0] for t in font.texts])

    def test_ambiguous_without_font_still_draws_a_marker(self):
        pg = self.draw((None, None, False, "ambiguous"))
        self.assertGreaterEqual(pg.draw_calls["circle"], 1)

    def test_error_cross_is_drawn_for_unrecognized(self):
        pg = self.draw((None, None, False, "no_match"))
        self.assertEqual(len([l for l in pg.lines if l[0] == palette.REJECTED]), 2)


if __name__ == "__main__":
    unittest.main()
