import dataclasses
import math
import random
import unittest
from collections import deque

import settings
from ai.bot import BotController, Intent, Observation, observe
from ai.difficulty import DIFFICULTIES, DIFFICULTY_ORDER, Difficulty
from arena.arena import Arena
from arena.floor import ArenaFloor
from combat.attacks import resolve_attack
from core.gameplay import GameplayState, create_fighters
from core.match_rules import MatchRules
from entities.fighter import Fighter, FighterState as S


class Idle:
    def direction(self, i):
        return (0, 0)


def make(diff="normal", seed=0, collapse=True, limit=None, gap=None):
    arena = Arena.from_settings()
    arena.attach_floor(ArenaFloor(arena, enabled=collapse))
    fighters = create_fighters(arena)
    ctl = BotController(diff, seed)
    s = GameplayState(Idle(), arena=arena, fighters=fighters, controllers={1: ctl},
                      rules=MatchRules(0, limit))
    if gap is not None:
        fighters[1].x = fighters[1].prev_x = fighters[0].x + gap
        fighters[1].y = fighters[1].prev_y = fighters[0].y
    return s, ctl


def custom(**kw):
    base = dict(name="custom", label="X", reaction=0.27, decision_interval=0.1, aggression=0.0,
                dodge_skill=1.0, punish_skill=1.0, draw_time=0.2, mistake=0.0)
    base.update(kw)
    return Difficulty(**base)


class FairnessTests(unittest.TestCase):
    def test_difficulty_only_contains_decision_quality_parameters(self):
        names = {f.name for f in dataclasses.fields(Difficulty)}
        for forbidden in ("hp", "health", "damage", "speed", "knockback", "armor"):
            self.assertNotIn(forbidden, names)

    def test_difficulties_are_ordered_by_skill(self):
        d = [DIFFICULTIES[n] for n in DIFFICULTY_ORDER]
        self.assertGreater(d[0].reaction, d[1].reaction)
        self.assertGreater(d[1].reaction, d[2].reaction)
        self.assertLess(d[0].aggression, d[2].aggression)
        self.assertLess(d[0].dodge_skill, d[2].dodge_skill)
        self.assertTrue(all(x.reaction > 0.1 for x in d))          # реакция всегда ограничена

    def test_bot_has_the_same_body_and_rules_as_the_player(self):
        s, _ = make()
        a, b = s.fighters
        self.assertEqual((a.max_hp, a.speed, a.width), (b.max_hp, b.speed, b.width))

    def test_bot_attacks_use_the_same_specs(self):
        s, _ = make()
        s.perform_gesture(1, "slash")
        self.assertEqual(s.fighters[1].attack.spec, resolve_attack("slash"))

    def test_observation_reads_only_public_attributes(self):
        allowed = {"x", "y", "facing", "state", "hp", "max_hp", "attack"}

        class Spy:
            def __init__(self):
                self.x, self.y, self.facing = 1.0, 2.0, (1.0, 0.0)
                self.state, self.hp, self.max_hp, self.attack = S.IDLE, 90.0, 100.0, None
                self.accessed = set()

            def __getattribute__(self, name):
                if not name.startswith("__") and name != "accessed":
                    object.__getattribute__(self, "accessed").add(name)
                return object.__getattribute__(self, name)

        spy = Spy()
        obs = observe(spy, 1.0)
        self.assertTrue(spy.accessed <= allowed, spy.accessed - allowed)
        self.assertIsInstance(obs, Observation)

    def test_bot_never_touches_player_input_or_player_rush(self):
        s, ctl = make()

        class Trap:
            def __getattr__(self, name):
                raise AssertionError("бот читает скрытые данные: " + name)

        s.command_input = Trap()
        s.rush[0] = Trap()
        for _ in range(300):
            ctl.think(s, 1, 1 / 60)


class ReactionTests(unittest.TestCase):
    def scenario(self, reaction, seed=0):
        s, ctl = make(custom(reaction=reaction), seed, collapse=False, gap=80)
        blue, red = s.fighters
        t0 = None
        first_dodge = None
        for i in range(120):
            if i == 30:
                s.combat.request_attack(blue, "sweep", "slow")   # долгая подготовка
                t0 = s.time
            s.update(1 / 60)
            if t0 is not None and ctl.dodge is not None and first_dodge is None:
                first_dodge = s.time - t0
        return first_dodge, red.hp, t0

    def test_bot_cannot_react_before_its_reaction_time(self):
        for reaction in (0.2, 0.3):
            first, hp, _ = self.scenario(reaction)
            self.assertIsNotNone(first, reaction)
            self.assertGreaterEqual(first, reaction - 0.02)

    def test_slower_reaction_means_later_dodge(self):
        fast, _, _ = self.scenario(0.18)
        slow, _, _ = self.scenario(0.30)
        self.assertLess(fast, slow)

    def test_bot_with_good_reaction_dodges_a_telegraphed_attack(self):
        saved = 0
        for seed in range(10):
            _, hp, _ = self.scenario(0.15, seed)
            saved += hp == 100.0
        self.assertGreaterEqual(saved, 7)

    def test_bot_with_zero_dodge_skill_gets_hit(self):
        s, ctl = make(custom(dodge_skill=0.0, reaction=0.15), 0, collapse=False, gap=80)
        s.combat.request_attack(s.fighters[0], "sweep", "slow")
        for _ in range(90):
            s.update(1 / 60)
        self.assertLess(s.fighters[1].hp, 100.0)


class BehaviourTests(unittest.TestCase):
    def test_bot_is_never_standing_still(self):
        for diff in DIFFICULTY_ORDER:
            s, _ = make(diff, 1, collapse=False)
            bot, path, last = s.fighters[1], 0.0, None
            for _ in range(60 * 15):
                s.update(1 / 60)
                if last is not None:
                    path += math.hypot(bot.x - last[0], bot.y - last[1])
                last = (bot.x, bot.y)
                if s.result:
                    break
            self.assertGreater(path, 300.0, diff)

    def test_bot_approaches_a_far_player(self):
        s, _ = make("normal", 2, collapse=False)
        start = s.fighters[1].x - s.fighters[0].x
        for _ in range(60 * 2):
            s.update(1 / 60)
        self.assertLess(s.fighters[1].x - s.fighters[0].x, start - 150)

    def test_bot_attacks_a_standing_player_and_uses_several_gestures(self):
        used = set()
        wins = 0
        for seed in range(12):
            s, ctl = make("normal", seed, collapse=False)
            last = None
            for _ in range(60 * 40):
                s.update(1 / 60)
                a = s.fighters[1].attack
                if a is not None and a is not last:
                    used.add(a.spec.name)
                last = a
                if s.result:
                    break
            wins += bool(s.result and s.result.outcome == "defeat")
        self.assertGreaterEqual(wins, 10)
        self.assertGreaterEqual(len(used), 3)          # разные жесты

    def test_bot_uses_combo_continuations(self):
        chained = 0
        for seed in range(12):
            s, _ = make("hard", seed, collapse=False, gap=70)
            for _ in range(60 * 25):
                s.update(1 / 60)
                if s.fighters[1].combo and len(s.fighters[1].combo.history) >= 2:
                    chained += 1
                    break
                if s.result:
                    break
        self.assertGreater(chained, 0)

    def test_bot_keeps_a_distance_band_instead_of_hugging(self):
        s, _ = make("normal", 3, collapse=False, gap=300)
        dists = []
        for _ in range(60 * 8):
            s.update(1 / 60)
            dists.append(math.hypot(s.fighters[0].x - s.fighters[1].x, s.fighters[0].y - s.fighters[1].y))
        self.assertLess(min(dists), 100)
        self.assertGreater(sum(d > 40 for d in dists) / len(dists), 0.8)

    def test_bot_punishes_a_whiffed_attack(self):
        reacted = 0
        for seed in range(10):
            s, ctl = make(custom(reaction=0.12, draw_time=0.12), seed, collapse=False, gap=170)
            blue, red = s.fighters
            s.combat.request_attack(blue, "thrust", "medium")      # промах: бот вне зоны
            engaged = False
            start = red.x
            for _ in range(60 * 2):
                s.update(1 / 60)
                if red.attack is not None:
                    engaged = True
            reacted += engaged or abs(red.x - start) > 40
        self.assertGreaterEqual(reacted, 8)

    def test_bot_steps_back_after_being_hit_sometimes_not_always(self):
        s, ctl = make("normal", 4, collapse=False, gap=60)
        ctl.last_hp = 100.0
        s.fighters[1].hp = 90.0
        ctl.think(s, 1, 1 / 60)
        self.assertEqual(ctl.last_hp, 90.0)

    def test_dead_bot_gives_no_intent(self):
        s, ctl = make()
        s.fighters[1].state = S.DEAD
        self.assertEqual(ctl.think(s, 1, 1 / 60), Intent())

    def test_reset_clears_internal_state(self):
        s, ctl = make()
        for _ in range(120):
            s.update(1 / 60)
        ctl.reset()
        self.assertEqual((len(ctl.history), ctl.pending, ctl.dodge), (0, None, None))

    def test_same_seed_gives_same_behaviour_and_seeds_differ(self):
        def run(seed):
            s, _ = make("normal", seed, collapse=False)
            for _ in range(60 * 10):
                s.update(1 / 60)
            return round(s.fighters[1].x, 3), round(s.fighters[1].y, 3), s.fighters[0].hp
        self.assertEqual(run(5), run(5))
        self.assertNotEqual(run(5), run(6))


class ArenaAwarenessTests(unittest.TestCase):
    def test_bot_leaves_the_ring_that_is_about_to_collapse(self):
        s, ctl = make("normal", 0, collapse=True, gap=400)
        bot = s.fighters[1]
        bot.x = bot.prev_x = s.arena.right - 18
        bot.y = bot.prev_y = s.arena.center_y
        for _ in range(int(31 * 60)):
            s.update(1 / 60)
        self.assertTrue(bot.alive)

    def test_bot_survives_every_collapse_against_a_passive_player(self):
        for seed in range(4):
            s, _ = make("normal", seed, collapse=True, limit=None)
            s.fighters[0].hp = s.fighters[0].max_hp
            for _ in range(int(170 * 60)):
                s.update(1 / 60)
                s.fighters[0].hp = 100.0              # игрок бессмертен: проверяем только арену
                s.fighters[0].state = S.IDLE if s.fighters[0].state is S.HITSTUN else s.fighters[0].state
                if not s.fighters[1].alive:
                    break
            self.assertFalse(s.fighters[1].ring_out, seed)

    def test_bot_stays_inside_the_current_safe_zone(self):
        s, _ = make("hard", 1, collapse=True)
        for _ in range(int(100 * 60)):
            s.update(1 / 60)
            s.fighters[0].hp = 100.0
        l, t, r, b = s.arena.bounds
        bot = s.fighters[1]
        if bot.alive:
            self.assertTrue(l - 20 <= bot.x <= r + 20 and t - 20 <= bot.y <= b + 20)


class BeatableTests(unittest.TestCase):
    """Бот не непобедим: сценарные игроки разной силы побеждают его."""

    class Human:
        def __init__(self, reaction, draw):
            self.r, self.draw = reaction, draw
            self.hist, self.pending, self.dir, self.next = deque(), None, (0, 0), 0.0

        def __call__(self, st):
            now = st.time
            me, bot = st.fighters
            if not me.alive:
                return
            self.hist.append((now, bot.x, bot.y, bot.state))
            seen = None
            for h in self.hist:
                if h[0] <= now - self.r:
                    seen = h
            while len(self.hist) > 2 and self.hist[1][0] <= now - self.r:
                self.hist.popleft()
            if self.pending and now >= self.pending[0]:
                st.perform_gesture(0, *self.pending[1:])
                self.pending = None
            if seen and now >= self.next:
                self.next = now + 0.1
                _, bx, by, bstate = seen
                dx, dy = bx - me.x, by - me.y
                dist = math.hypot(dx, dy) or 1
                ux, uy = dx / dist, dy / dist
                self.dir = (0, 0)
                if me.state is S.IDLE:
                    if bstate is S.WINDUP and dist < 140:
                        self.dir = (-ux, -uy)
                    elif dist > 112:
                        self.dir = (ux, uy)
                    elif dist < 70:
                        self.dir = (-ux, -uy)
                    if self.pending is None and bstate is not S.WINDUP:
                        if 85 < dist <= 118:
                            self.pending = (now + self.draw, "thrust", "medium")
                        elif dist <= 85 and bstate in (S.RECOVERY, S.HITSTUN):
                            self.pending = (now + self.draw * 0.6, "slash", "fast")
            d = self.dir
            st.input = type("I", (), {"direction": staticmethod(lambda i: d if i == 0 else (0, 0))})()

    def wins(self, diff, reaction, draw, seeds=10):
        w = 0
        for seed in range(seeds):
            s, _ = make(diff, seed, collapse=False, limit=90)
            policy = self.Human(reaction, draw)
            for _ in range(60 * 95):
                policy(s)
                s.update(1 / 60)
                if s.result:
                    break
            w += bool(s.result and s.result.outcome == "victory")
        return w

    def test_easy_and_normal_bots_lose_to_a_decent_player(self):
        self.assertGreaterEqual(self.wins("easy", 0.25, 0.22), 8)
        self.assertGreaterEqual(self.wins("normal", 0.25, 0.22), 2)

    def test_hard_bot_is_beatable_by_a_fast_player(self):
        self.assertGreaterEqual(self.wins("hard", 0.15, 0.14), 1)

    def test_difficulty_makes_a_real_difference(self):
        easy = self.wins("easy", 0.25, 0.22)
        hard = self.wins("hard", 0.25, 0.22)
        self.assertGreater(easy, hard)


if __name__ == "__main__":
    unittest.main()
