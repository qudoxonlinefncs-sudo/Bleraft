"""Общие помощники для тестов: синтетические жесты."""

import math
import random

# Независимые от шаблонов описания фигур (ключевые точки, Y вниз)
SHAPES = {
    "slash": ((0, 1), (1, 0)),
    "sweep": ((0, 0), (1, 0)),
    "thrust": ((0, 0), (0, 1)),
    "double": ((0, 0), (0.5, 1), (1, 0)),
    "backslash": ((0, 0), (1, 1)),
    "L": ((0, 0), (0, 1), (1, 1)),
    "lambda": ((0, 1), (0.5, 0), (1, 1)),
    "zigzag": ((0, 0), (1, 0.3), (0, 0.6), (1, 0.9)),
}


def polyline(keys, per_segment=40):
    points = []
    for (x0, y0), (x1, y1) in zip(keys, keys[1:]):
        for i in range(per_segment):
            k = i / per_segment
            points.append((x0 + (x1 - x0) * k, y0 + (y1 - y0) * k))
    points.append(keys[-1])
    return points


def circle_points(count=60):
    return [(0.5 * math.cos(2 * math.pi * i / count),
             0.5 * math.sin(2 * math.pi * i / count)) for i in range(count + 1)]


def make_stroke(base, scale=300.0, origin=(400.0, 300.0), duration=0.4,
                rot_deg=0.0, noise=0.0, sx=1.0, sy=1.0, reverse=False,
                seed=1, t0=0.0):
    """Жест (x, y, t): масштаб, положение, длительность, поворот, шум, обратное направление."""
    pts = list(polyline(base) if isinstance(base[0][0], (int, float)) and len(base) < 8 else base)
    if reverse:
        pts.reverse()
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    rng = random.Random(seed)
    rot = math.radians(rot_deg)
    c, s = math.cos(rot), math.sin(rot)
    n = len(pts)
    out = []
    for i, (x, y) in enumerate(pts):
        x, y = (x - cx) * sx, (y - cy) * sy
        x, y = x * c - y * s, x * s + y * c
        out.append((
            origin[0] + x * scale + rng.gauss(0, noise * scale),
            origin[1] + y * scale + rng.gauss(0, noise * scale),
            t0 + duration * i / (n - 1),
        ))
    return out


def shape_stroke(name, **kwargs):
    base = polyline(SHAPES[name]) if name in SHAPES else name
    return make_stroke(base, **kwargs)
