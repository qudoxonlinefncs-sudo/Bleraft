import unittest

from physics.collision import clamp_box_to_bounds

BOUNDS = (100, 100, 300, 200)  # 200 x 100
SIZE = 20


class ClampBoxTests(unittest.TestCase):
    def clamp(self, x, y):
        return clamp_box_to_bounds(x, y, SIZE, SIZE, BOUNDS)

    def test_inside_is_unchanged(self):
        self.assertEqual(self.clamp(200, 150), (200, 150))

    def test_touching_each_wall_is_allowed(self):
        self.assertEqual(self.clamp(110, 150), (110, 150))  # левая
        self.assertEqual(self.clamp(290, 150), (290, 150))  # правая
        self.assertEqual(self.clamp(200, 110), (200, 110))  # верхняя
        self.assertEqual(self.clamp(200, 190), (200, 190))  # нижняя

    def test_each_wall_stops_the_box(self):
        self.assertEqual(self.clamp(0, 150), (110, 150))
        self.assertEqual(self.clamp(999, 150), (290, 150))
        self.assertEqual(self.clamp(200, 0), (200, 110))
        self.assertEqual(self.clamp(200, 999), (200, 190))

    def test_corners(self):
        self.assertEqual(self.clamp(0, 0), (110, 110))
        self.assertEqual(self.clamp(999, 0), (290, 110))
        self.assertEqual(self.clamp(0, 999), (110, 190))
        self.assertEqual(self.clamp(999, 999), (290, 190))

    def test_axes_are_independent_so_box_slides_along_wall(self):
        self.assertEqual(self.clamp(0, 140), (110, 140))

    def test_box_always_fully_inside_after_clamp(self):
        for x in range(-50, 400, 37):
            for y in range(-50, 300, 29):
                cx, cy = self.clamp(x, y)
                self.assertGreaterEqual(cx - SIZE / 2, 100)
                self.assertLessEqual(cx + SIZE / 2, 300)
                self.assertGreaterEqual(cy - SIZE / 2, 100)
                self.assertLessEqual(cy + SIZE / 2, 200)

    def test_bounds_smaller_than_box_centers_it(self):
        self.assertEqual(
            clamp_box_to_bounds(0, 0, 50, 50, (100, 100, 120, 120)), (110, 110)
        )


if __name__ == "__main__":
    unittest.main()
