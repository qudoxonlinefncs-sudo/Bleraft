"""Проверка ui/combat_view на ПОДДЕЛЬНОМ pygame.

Проверяется, ЧТО рисуется в каждом состоянии боя (какие формы, какими цветами),
а не то, как это выглядит на экране. Внешний вид нужно смотреть глазами.
"""

import types
import unittest

import settings
from arena.arena import Arena
from combat.combat_system import CombatSystem
from entities.fighter import Fighter, FighterState as S
from tests.test_renderer import FakeSurface, make_fake_pygame
from ui import palette
from ui.combat_view import CombatView, HP_BAR_WIDTH
from ui.effects import Effects

ARENA = Arena.from_settings()


def fake_pg():
    pg = make_fake_pygame()
    pg.calls = []

    def recorder(name):
        # первый аргумент pygame.draw.* - поверхность, в записи он не нужен
        return lambda surface, *args: pg.calls.append((name,) + args)

    pg.draw.polygon = recorder("polygon")
    pg.draw.line = recorder("line")
    pg.draw.lines = recorder("lines")
    pg.draw.circle = recorder("circle")
    pg.draw.rect = recorder("rect")
    return pg


def scene(fighters, trail=(), effects=None):
    return types.SimpleNamespace(
        fighters=fighters, arena=ARENA, effects=effects or Effects(), trail=list(trail))


def duel(gap=60):
    blue = Fighter("blue", 500.0, 360.0, 36, 280.0)
    red = Fighter("red", 500.0 + gap, 360.0, 36, 280.0)
    return blue, red, CombatSystem([blue, red])


def advance_to(cs, fighter, state):
    for _ in range(600):
        if fighter.state is state:
            return
        cs.update(1 / 60)
    raise AssertionError("не дошли до " + state.value)


def calls(pg, name):
    return [c for c in pg.calls if c[0] == name]


class AttackDrawingTests(unittest.TestCase):
    def setUp(self):
        self.pg = fake_pg()
        self.view = CombatView(self.pg)
        self.screen = FakeSurface((1280, 720))

    def draw(self, fighters):
        self.pg.calls.clear()
        self.view.draw(self.screen, scene(fighters), 1.0)

    def test_idle_fighters_draw_no_attack_shapes_but_show_facing(self):
        blue, red, cs = duel(gap=300)
        cs.update(1 / 60)
        self.draw([blue, red])
        self.assertEqual(calls(self.pg, "polygon"), [])
        facing_lines = [c for c in calls(self.pg, "line")
                        if c[1] in (palette.ATTACK_COLORS["blue"]["bright"],
                                    palette.ATTACK_COLORS["red"]["bright"])]
        self.assertEqual(len(facing_lines), 2)

    def test_windup_shows_zone_outline_and_growing_fill(self):
        blue, red, cs = duel(gap=300)
        cs.request_attack(blue, "slash")
        cs.update(1 / 60)
        self.draw([blue, red])
        polys = calls(self.pg, "polygon")
        self.assertEqual(len(polys), 2)
        outline, fill = polys
        self.assertEqual(outline[1], palette.ATTACK_COLORS["blue"]["dim"])
        self.assertEqual(outline[3], 1)                       # контур
        self.assertEqual(fill[1], palette.ATTACK_COLORS["blue"]["main"])
        self.assertEqual(len(fill), 3)                         # заливка без толщины

    def test_windup_fill_grows_with_progress(self):
        blue, red, cs = duel(gap=300)
        cs.request_attack(blue, "thrust")
        sizes = []
        for _ in range(3):
            cs.update(1 / 60)
            self.draw([blue, red])
            fill = calls(self.pg, "polygon")[1]
            xs = [p[0] for p in fill[2]]
            sizes.append(max(xs) - min(xs))
        self.assertLess(sizes[0], sizes[1])
        self.assertLess(sizes[1], sizes[2])

    def test_active_phase_is_filled_bright_during_hit_window(self):
        blue, red, cs = duel(gap=300)
        cs.request_attack(blue, "slash")
        advance_to(cs, blue, S.ACTIVE)
        self.draw([blue, red])
        polys = calls(self.pg, "polygon")
        self.assertEqual(polys[0][1], palette.ATTACK_COLORS["blue"]["bright"])
        self.assertEqual(len(polys[0]), 3)

    def test_recovery_shows_only_dim_outline(self):
        blue, red, cs = duel(gap=300)
        cs.request_attack(blue, "slash")
        advance_to(cs, blue, S.RECOVERY)
        self.draw([blue, red])
        polys = calls(self.pg, "polygon")
        self.assertEqual(len(polys), 1)
        self.assertEqual(polys[0][1], palette.ATTACK_COLORS["blue"]["dim"])

    def test_zone_polygon_is_in_front_of_the_fighter(self):
        blue, red, cs = duel(gap=300)
        cs.request_attack(blue, "slash")
        advance_to(cs, blue, S.ACTIVE)
        self.draw([blue, red])
        xs = [p[0] for p in calls(self.pg, "polygon")[0][2]]
        self.assertGreater(min(xs), blue.x - 5)      # не позади бойца
        self.assertGreater(max(xs), blue.x + 50)

    def test_dead_fighter_draws_nothing(self):
        blue, red, cs = duel()
        blue.state = S.DEAD
        red.state = S.DEAD
        self.draw([blue, red])
        self.assertEqual(calls(self.pg, "polygon"), [])
        self.assertEqual(calls(self.pg, "circle"), [])

    def test_finisher_outline_is_thicker(self):
        blue, red, cs = duel(gap=3000)
        for gesture in ("slash", "sweep", "double"):
            for _ in range(600):
                if cs.request_attack(blue, gesture) == "started":
                    break
                cs.update(1 / 60)
        advance_to(cs, blue, S.RECOVERY)
        self.assertTrue(blue.attack.spec.is_finisher)
        self.draw([blue, red])
        self.assertEqual(calls(self.pg, "polygon")[0][3], 3)


class FeedbackDrawingTests(unittest.TestCase):
    def setUp(self):
        self.pg = fake_pg()
        self.view = CombatView(self.pg)
        self.screen = FakeSurface((1280, 720))
        self.blue, self.red, _ = duel()

    def draw(self, **kw):
        self.pg.calls.clear()
        self.screen.blits.clear()
        self.view.draw(self.screen, scene([self.blue, self.red], **kw), 1.0)

    def test_hit_flash_draws_white_sprite_over_the_hit_fighter_only(self):
        self.draw()
        self.assertEqual(self.screen.blits, [])
        self.red.hit_flash = 0.1
        self.draw()
        self.assertEqual(len(self.screen.blits), 1)
        sprite, pos = self.screen.blits[0]
        self.assertEqual(sprite.size, (settings.PLAYER_SIZE, settings.PLAYER_SIZE))
        self.assertEqual(pos, (round(self.red.x) - 18, round(self.red.y) - 18))

    def test_flash_sprite_is_built_once(self):
        self.red.hit_flash = 0.1
        self.draw()
        created = len(self.pg.created)
        self.draw()
        self.draw()
        self.assertEqual(len(self.pg.created), created)

    def test_health_bars_reflect_hp(self):
        self.blue.hp = 50.0
        self.red.hp = 100.0
        self.draw()
        fills = {c[1]: c[2] for c in calls(self.pg, "rect")
                 if c[1] in (palette.HP_FILL["blue"], palette.HP_FILL["red"])}
        self.assertEqual(fills[palette.HP_FILL["blue"]][2], HP_BAR_WIDTH // 2)
        self.assertEqual(fills[palette.HP_FILL["red"]][2], HP_BAR_WIDTH)

    def test_zero_hp_draws_no_fill(self):
        self.blue.hp = 0.0
        self.draw()
        blue_fills = [c for c in calls(self.pg, "rect") if c[1] == palette.HP_FILL["blue"]]
        self.assertEqual(blue_fills, [])

    def test_red_bar_drains_toward_the_right_edge_of_arena(self):
        self.red.hp = 25.0
        self.draw()
        fill = next(c[2] for c in calls(self.pg, "rect") if c[1] == palette.HP_FILL["red"])
        self.assertEqual(fill[0] + fill[2], int(ARENA.right))

    def test_gesture_trail_is_drawn_only_with_two_or_more_points(self):
        self.draw(trail=[(10, 10, 0.0)])
        self.assertEqual(calls(self.pg, "lines"), [])
        self.draw(trail=[(10, 10, 0.0), (50, 60, 0.1), (90, 20, 0.2)])
        lines = calls(self.pg, "lines")
        self.assertEqual(len(lines), 1)
        self.assertEqual(lines[0][1], palette.TRAIL)
        self.assertEqual(lines[0][3], [(10, 10), (50, 60), (90, 20)])

    def test_hit_sparks_are_drawn_as_rings(self):
        fx = Effects()
        fx.add_hit(300, 300, big=False)
        fx.update(0.1)
        self.draw(effects=fx)
        rings = [c for c in calls(self.pg, "circle") if c[1] == palette.SPARK]
        self.assertEqual(len(rings), 1)
        self.assertGreater(rings[0][3], 6)

    def test_big_spark_grows_larger_than_small_one(self):
        radii = []
        for big in (False, True):
            fx = Effects()
            fx.add_hit(300, 300, big=big)
            fx.update(0.2)
            self.draw(effects=fx)
            radii.append(next(c[3] for c in calls(self.pg, "circle") if c[1] == palette.SPARK))
        self.assertGreater(radii[1], radii[0])

    def test_unknown_gesture_indicator_is_a_red_cross(self):
        fx = Effects()
        fx.set_indicator(0, None, None, False)
        self.draw(effects=fx)
        red_lines = [c for c in calls(self.pg, "line") if c[1] == palette.REJECTED]
        self.assertEqual(len(red_lines), 2)

    def test_recognized_gesture_indicator_shows_icon_and_tier_segments(self):
        for tier, segments in (("fast", 1), ("medium", 2), ("slow", 3)):
            fx = Effects()
            fx.set_indicator(0, "slash", tier, True)
            self.draw(effects=fx)
            color = palette.TIER_COLORS[tier]
            icons = [c for c in calls(self.pg, "lines") if c[1] == color]
            self.assertEqual(len(icons), 1, tier)
            lit = [c for c in calls(self.pg, "rect") if c[1] == color and c[2][3] == 4]
            self.assertEqual(len(lit), segments, tier)

    def test_rejected_attack_indicator_is_dimmed(self):
        fx = Effects()
        fx.set_indicator(0, "slash", "fast", False)
        self.draw(effects=fx)
        self.assertEqual([c for c in calls(self.pg, "lines") if c[1] == palette.TIER_COLORS["fast"]], [])
        self.assertEqual(len([c for c in calls(self.pg, "lines") if c[1] == palette.HP_BORDER]), 1)

    def test_every_template_has_an_icon(self):
        from input.gesture_templates import DEFAULT_TEMPLATES
        for t in DEFAULT_TEMPLATES:
            fx = Effects()
            fx.set_indicator(1, t.name, "medium", True)
            self.draw(effects=fx)
            self.assertTrue(calls(self.pg, "lines"), t.name)


if __name__ == "__main__":
    unittest.main()
