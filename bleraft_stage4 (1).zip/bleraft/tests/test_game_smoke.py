"""Проверка потока управления Game.run() на ПОДДЕЛЬНОМ pygame.

Важно: это НЕ проверка реального Pygame (его API здесь заменён заглушкой),
а проверка нашей логики: окно создаётся с нужным размером, цикл крутится,
ESC и закрытие окна завершают игру, pygame.quit() вызывается всегда.
Реальный запуск окна проверяется вручную: python main.py
"""

import sys
import types
import unittest

import settings
from core.game import Game
from core.states import State


def make_fake_pygame(events_per_frame, frame_ms=16):
    """events_per_frame: список списков событий, по одному списку на кадр."""
    pg = types.ModuleType("pygame")
    pg.QUIT, pg.KEYDOWN, pg.K_ESCAPE = 256, 768, 27
    pg.calls = []
    frames = iter(events_per_frame)

    class Surface:
        def fill(self, color):
            pg.calls.append(("fill", color))

    class Clock:
        def tick(self, fps):
            pg.calls.append(("tick", fps))
            return frame_ms

        def get_fps(self):
            return 60.0

    pg.init = lambda: pg.calls.append(("init",))
    pg.quit = lambda: pg.calls.append(("quit",))
    pg.display = types.SimpleNamespace(
        set_mode=lambda size: (pg.calls.append(("set_mode", size)), Surface())[1],
        set_caption=lambda text: pg.calls.append(("caption", text)),
        flip=lambda: pg.calls.append(("flip",)),
    )
    pg.time = types.SimpleNamespace(Clock=Clock)
    pg.event = types.SimpleNamespace(get=lambda: next(frames, [types.SimpleNamespace(type=pg.QUIT)]))
    return pg


class CountingState(State):
    def __init__(self):
        super().__init__()
        self.updates = 0
        self.draws = 0
        self.events = []

    def update(self, dt):
        self.updates += 1

    def draw(self, surface, alpha):
        self.draws += 1

    def handle_event(self, event):
        self.events.append(event)


class GameSmokeTests(unittest.TestCase):
    def _run(self, events_per_frame):
        fake = make_fake_pygame(events_per_frame)
        sys.modules["pygame"] = fake
        self.addCleanup(sys.modules.pop, "pygame", None)
        state = CountingState()
        Game(initial_state=state).run()
        return fake, state

    def test_window_created_with_settings_size_and_closed_at_end(self):
        fake, _ = self._run([[]])
        self.assertIn(("set_mode", (settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT)), fake.calls)
        self.assertEqual(fake.calls[0], ("init",))
        self.assertEqual(fake.calls[-1], ("quit",))

    def test_escape_stops_game(self):
        esc = types.SimpleNamespace(type=768, key=27)
        fake, state = self._run([[], [], [esc]])
        self.assertEqual(sum(1 for c in fake.calls if c[0] == "flip"), 2)
        self.assertEqual(state.events, [])  # ESC не уходит в состояние

    def test_other_events_reach_state(self):
        key_a = types.SimpleNamespace(type=768, key=97)
        _, state = self._run([[key_a]])
        self.assertEqual(state.events, [key_a])

    def test_logic_and_draw_run_each_frame(self):
        _, state = self._run([[], [], []])
        self.assertEqual(state.draws, 3)  # 3 кадра; кадр с QUIT не рисуется
        self.assertGreater(state.updates, 0)

    def test_no_extra_update_or_draw_after_escape(self):
        esc = types.SimpleNamespace(type=768, key=27)
        fake, state = self._run([[esc]])  # ESC уже в самом первом кадре
        self.assertEqual(state.updates, 0)
        self.assertEqual(state.draws, 0)
        self.assertEqual(sum(1 for c in fake.calls if c[0] == "flip"), 0)
        self.assertEqual(fake.calls[-1], ("quit",))

    def test_no_extra_update_or_draw_after_window_close(self):
        quit_event = types.SimpleNamespace(type=256)
        fake, state = self._run([[quit_event]])
        self.assertEqual(state.updates, 0)
        self.assertEqual(state.draws, 0)
        self.assertEqual(sum(1 for c in fake.calls if c[0] == "flip"), 0)

    def test_no_extra_frame_after_state_requests_quit(self):
        class QuitOnEvent(CountingState):
            def handle_event(self, event):
                self.manager.request_quit()

        fake = make_fake_pygame([[types.SimpleNamespace(type=768, key=97)]])
        sys.modules["pygame"] = fake
        self.addCleanup(sys.modules.pop, "pygame", None)
        state = QuitOnEvent()
        Game(initial_state=state).run()
        self.assertEqual(state.updates, 0)
        self.assertEqual(state.draws, 0)
        self.assertEqual(fake.calls[-1], ("quit",))


class QuitInUpdateTests(unittest.TestCase):
    """Состояние запрашивает выход прямо в update()."""

    def _run(self, quit_on_update, frame_ms, frames=3):
        class QuitInUpdate(CountingState):
            def update(self, dt):
                super().update(dt)
                if self.updates == quit_on_update:
                    self.manager.request_quit()

        fake = make_fake_pygame([[] for _ in range(frames)], frame_ms=frame_ms)
        sys.modules["pygame"] = fake
        self.addCleanup(sys.modules.pop, "pygame", None)
        state = QuitInUpdate()
        Game(initial_state=state).run()
        return fake, state

    def test_single_tick_quit_means_no_draw(self):
        fake, state = self._run(quit_on_update=1, frame_ms=17)
        self.assertEqual(state.updates, 1)
        self.assertEqual(state.draws, 0)
        self.assertEqual(sum(1 for c in fake.calls if c[0] == "flip"), 0)
        self.assertEqual(fake.calls[-1], ("quit",))

    def test_quit_in_middle_of_multi_tick_frame_stops_remaining_ticks(self):
        # 100 мс кадр = 6 тиков логики; выход запрошен на 2-м тике
        fake, state = self._run(quit_on_update=2, frame_ms=100)
        self.assertEqual(state.updates, 2)
        self.assertEqual(state.draws, 0)
        self.assertEqual(sum(1 for c in fake.calls if c[0] == "flip"), 0)

    def test_quit_on_last_tick_of_multi_tick_frame_still_skips_draw(self):
        fake, state = self._run(quit_on_update=6, frame_ms=100)
        self.assertEqual(state.updates, 6)
        self.assertEqual(state.draws, 0)

    def test_quit_in_later_frame_keeps_earlier_frames_intact(self):
        # кадры по 100 мс: 6 тиков в кадре; выход на 8-м тике (2-й кадр)
        fake, state = self._run(quit_on_update=8, frame_ms=100)
        self.assertEqual(state.updates, 8)
        self.assertEqual(state.draws, 1)  # отрисован только 1-й кадр
        self.assertEqual(sum(1 for c in fake.calls if c[0] == "flip"), 1)

    def test_without_quit_all_ticks_of_multi_tick_frame_run(self):
        fake, state = self._run(quit_on_update=-1, frame_ms=100, frames=2)
        self.assertEqual(state.updates, 12)  # 2 кадра * 6 тиков
        self.assertEqual(state.draws, 2)


if __name__ == "__main__":
    unittest.main()
