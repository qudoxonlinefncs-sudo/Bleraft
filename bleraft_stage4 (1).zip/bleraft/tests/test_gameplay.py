import sys
import types
import unittest

import settings
from arena.arena import Arena
from core.game import Game
from core.gameplay import GameplayState, create_fighters
from core.states import StateManager
from tests.test_game_smoke import make_fake_pygame


class FakeInput:
    def __init__(self, directions=None):
        self.directions = directions or {}

    def direction(self, index):
        return self.directions.get(index, (0, 0))


class FakeRenderer:
    def __init__(self):
        self.calls = []

    def draw(self, surface, arena, fighters, alpha):
        self.calls.append((surface, arena, list(fighters), alpha))


class CreateFightersTests(unittest.TestCase):
    def setUp(self):
        self.arena = Arena.from_settings()
        self.blue, self.red = create_fighters(self.arena)

    def test_two_fighters_with_expected_teams(self):
        self.assertEqual((self.blue.team, self.red.team), ("blue", "red"))

    def test_fighters_on_opposite_sides_of_arena(self):
        self.assertLess(self.blue.x, self.arena.center_x)
        self.assertGreater(self.red.x, self.arena.center_x)
        self.assertAlmostEqual(self.blue.x - self.arena.center_x,
                               -(self.red.x - self.arena.center_x))
        self.assertEqual(self.blue.y, self.arena.center_y)
        self.assertEqual(self.red.y, self.arena.center_y)

    def test_fighters_start_fully_inside_arena(self):
        left, top, right, bottom = self.arena.bounds
        for f in (self.blue, self.red):
            self.assertGreaterEqual(f.x - f.width / 2, left)
            self.assertLessEqual(f.x + f.width / 2, right)
            self.assertGreaterEqual(f.y - f.height / 2, top)
            self.assertLessEqual(f.y + f.height / 2, bottom)

    def test_fighters_do_not_overlap_at_start(self):
        self.assertGreater(self.red.x - self.blue.x, self.blue.width)


class GameplayStateTests(unittest.TestCase):
    def test_players_move_independently(self):
        state = GameplayState(FakeInput({0: (1, 0), 1: (0, 1)}))
        blue, red = state.fighters
        blue_start, red_start = (blue.x, blue.y), (red.x, red.y)
        state.update(0.1)
        self.assertGreater(blue.x, blue_start[0])
        self.assertEqual(blue.y, blue_start[1])
        self.assertEqual(red.x, red_start[0])
        self.assertGreater(red.y, red_start[1])

    def test_no_input_no_movement(self):
        state = GameplayState(FakeInput())
        before = [(f.x, f.y) for f in state.fighters]
        state.update(1.0)
        self.assertEqual([(f.x, f.y) for f in state.fighters], before)

    def test_fighters_cannot_leave_arena_over_long_play(self):
        state = GameplayState(FakeInput({0: (-1, -1), 1: (1, 1)}))
        for _ in range(60 * 20):
            state.update(1 / 60)
        left, top, right, bottom = state.arena.bounds
        blue, red = state.fighters
        self.assertAlmostEqual(blue.x - blue.width / 2, left)
        self.assertAlmostEqual(blue.y - blue.height / 2, top)
        self.assertAlmostEqual(red.x + red.width / 2, right)
        self.assertAlmostEqual(red.y + red.height / 2, bottom)

    def test_draw_delegates_to_renderer_with_scene_data(self):
        renderer = FakeRenderer()
        state = GameplayState(FakeInput(), renderer)
        surface = object()
        state.draw(surface, 0.25)
        self.assertEqual(len(renderer.calls), 1)
        got_surface, arena, fighters, alpha = renderer.calls[0]
        self.assertIs(got_surface, surface)
        self.assertIs(arena, state.arena)
        self.assertEqual(fighters, state.fighters)
        self.assertEqual(alpha, 0.25)

    def test_draw_without_renderer_is_safe(self):
        GameplayState(FakeInput()).draw(object(), 0.0)

    def test_works_inside_state_manager(self):
        manager = StateManager()
        state = GameplayState(FakeInput({0: (1, 0)}))
        manager.change(state)
        x0 = state.fighters[0].x
        manager.update(0.05)
        self.assertGreater(state.fighters[0].x, x0)


class GameIntegrationTests(unittest.TestCase):
    """GameplayState внутри настоящего Game.run() на ПОДДЕЛЬНОМ pygame."""

    def test_scene_runs_inside_game_loop(self):
        fake = make_fake_pygame([[], [], []], frame_ms=16)
        sys.modules["pygame"] = fake
        self.addCleanup(sys.modules.pop, "pygame", None)
        renderer = FakeRenderer()
        state = GameplayState(FakeInput({0: (1, 0)}), renderer)
        x0 = state.fighters[0].x
        Game(initial_state=state).run()
        self.assertGreater(state.fighters[0].x, x0)
        self.assertEqual(len(renderer.calls), 3)  # 3 кадра, кадр с выходом не рисуется
        self.assertEqual(fake.calls[-1], ("quit",))


class SettingsConsistencyTests(unittest.TestCase):
    def test_player_fits_in_arena_and_spawn_offset_is_inside(self):
        self.assertLess(settings.PLAYER_SPAWN_OFFSET + settings.PLAYER_SIZE / 2,
                        settings.ARENA_WIDTH / 2)
        self.assertLess(settings.PLAYER_SIZE, settings.ARENA_HEIGHT)

    def test_arena_with_frame_fits_window(self):
        self.assertLessEqual(settings.ARENA_WIDTH + 2 * settings.ARENA_FRAME,
                             settings.WINDOW_WIDTH)
        self.assertLessEqual(settings.ARENA_HEIGHT + 2 * settings.ARENA_FRAME,
                             settings.WINDOW_HEIGHT)

    def test_speed_is_positive(self):
        self.assertGreater(settings.PLAYER_SPEED, 0)


if __name__ == "__main__":
    unittest.main()
