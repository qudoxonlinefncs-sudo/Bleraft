"""Распознавание v2: допуски, V против `/`, чужие фигуры, ошибки вместо угадывания."""

import math
import random
import unittest

from input.gesture_recognizer import GestureRecognizer, Shape
from tests.helpers import SHAPES, circle_points, make_stroke, polyline

NAMES = ("slash", "sweep", "thrust", "double")


def variant(name, rng, rot_max=12, wobble=0.05, jitter=0.006, hook=0.08, aspect=0.25):
    """Слегка изменённый жест: поворот, волна, дрожание, хвостик, пропорции, направление."""
    base = polyline(SHAPES[name], per_segment=40)
    n = len(base)
    a = aspect if name == "double" else 0.08
    sx, sy = 1 + rng.uniform(-a, a), 1 + rng.uniform(-a, a)
    rot = math.radians(rng.uniform(-rot_max, rot_max))
    amp, freq, ph = wobble * rng.random(), rng.uniform(0.5, 2.0), rng.uniform(0, 6.28)
    pts = []
    for i, (x, y) in enumerate(base):
        t = i / (n - 1)
        x, y = (x - 0.5) * sx, (y - 0.5) * sy
        off = amp * math.sin(2 * math.pi * freq * t + ph)
        x, y = x + off * 0.7, y + off * 0.7
        c, s = math.cos(rot), math.sin(rot)
        x, y = x * c - y * s, x * s + y * c
        pts.append((x + rng.gauss(0, jitter), y + rng.gauss(0, jitter)))
    if rng.random() < 0.6:
        (x1, y1) = pts[-1]
        ang, length = rng.uniform(0, 6.28), rng.uniform(0, hook)
        pts += [(x1 + math.cos(ang) * length * k / 4, y1 + math.sin(ang) * length * k / 4)
                for k in range(1, 5)]
    if rng.random() < 0.5:
        pts.reverse()
    scale = rng.uniform(130, 520)
    ox, oy = rng.uniform(200, 1000), rng.uniform(200, 560)
    dur = rng.uniform(0.2, 0.8)
    m = len(pts)
    return [(ox + x * scale, oy + y * scale, dur * i / (m - 1)) for i, (x, y) in enumerate(pts)]


class ToleranceTests(unittest.TestCase):
    def setUp(self):
        self.rec = GestureRecognizer()

    def test_many_slightly_distorted_variants_of_each_gesture_are_recognized(self):
        for name in NAMES:
            rng = random.Random(42)
            ok = wrong = 0
            n = 400
            for _ in range(n):
                r = self.rec.recognize(variant(name, rng))
                ok += r.name == name
                wrong += r.name is not None and r.name != name
            self.assertEqual(wrong, 0, name)                 # неправильных атак нет
            self.assertGreaterEqual(ok / n, 0.98, name)

    def test_rougher_gestures_still_never_give_a_wrong_attack(self):
        for name in NAMES:
            rng = random.Random(7)
            ok = wrong = 0
            n = 400
            for _ in range(n):
                r = self.rec.recognize(variant(name, rng, rot_max=16, wobble=0.08, hook=0.11, aspect=0.3))
                ok += r.name == name
                wrong += r.name is not None and r.name != name
            self.assertEqual(wrong, 0, name)
            self.assertGreaterEqual(ok / n, 0.9, name)

    def test_lines_tolerate_about_eighteen_degrees(self):
        for name in ("slash", "sweep", "thrust"):
            for rot in (-17, -10, 0, 10, 17):
                self.assertEqual(
                    self.rec.recognize(make_stroke(polyline(SHAPES[name]), rot_deg=rot)).name,
                    name, (name, rot))

    def test_curved_line_is_still_a_line(self):
        for bow in (0.0, 0.04, -0.06, 0.1):
            pts = polyline(SHAPES["sweep"])
            n = len(pts)
            stroke = [(300 + x * 300, 400 + y * 300 + bow * 300 * math.sin(math.pi * i / (n - 1)),
                       0.4 * i / (n - 1)) for i, (x, y) in enumerate(pts)]
            self.assertEqual(self.rec.recognize(stroke).name, "sweep", bow)

    def test_hook_at_the_end_is_ignored(self):
        for name in ("slash", "sweep", "thrust"):
            pts = polyline(SHAPES[name])
            x, y = pts[-1]
            pts += [(x + 0.015 * k, y + 0.02 * k) for k in range(1, 6)]      # короткий хвостик (~8%)
            self.assertEqual(self.rec.recognize(make_stroke(pts)).name, name)

    def test_hand_drawn_in_either_direction(self):
        for name in NAMES:
            for rev in (False, True):
                self.assertEqual(self.rec.recognize(make_stroke(polyline(SHAPES[name]), reverse=rev)).name, name)


class SlashVersusVTests(unittest.TestCase):
    def setUp(self):
        self.rec = GestureRecognizer()

    def test_slash_is_not_taken_for_v_and_v_is_not_taken_for_slash(self):
        rng = random.Random(3)
        for _ in range(300):
            self.assertNotEqual(self.rec.recognize(variant("slash", rng)).name, "double")
            self.assertNotEqual(self.rec.recognize(variant("double", rng)).name, "slash")

    def test_v_with_clearly_shorter_second_leg_is_still_v(self):
        # первая ножка длиной 1, вторая 0.6 (доля 0.375)
        pts = polyline(((0, 0), (0.5, 1.0), (0.5 + 0.3, 1.0 - 0.6)))
        self.assertEqual(self.rec.recognize(make_stroke(pts)).name, "double")

    def test_v_with_tiny_second_leg_is_an_error_not_a_guess(self):
        # вторая ножка ~20% длины: нельзя отличить V от линии с хвостиком
        pts = polyline(((0, 0), (0.5, 1.0), (0.62, 0.76)))
        result = self.rec.recognize(make_stroke(pts))
        self.assertIsNone(result.name)
        self.assertIn(result.reason, ("ambiguous", "no_match"))

    def test_v_geometry_features(self):
        xy = [(x * 300, y * 300) for x, y in polyline(SHAPES["double"])]
        shape = Shape(xy, 64, __import__("settings"))
        self.assertEqual(shape.kind, "vee")
        self.assertGreater(min(shape.legs), 0.4)
        line = [(x * 300, y * 300) for x, y in polyline(SHAPES["slash"])]
        self.assertEqual(Shape(line, 64, __import__("settings")).kind, "line")

    def test_inverted_v_and_sideways_chevron_are_not_v(self):
        for key in ("lambda", "L"):
            self.assertIsNone(self.rec.recognize(make_stroke(polyline(SHAPES[key]))).name)
        chevron = polyline(((0, 0), (1, 0.5), (0, 1)))
        self.assertIsNone(self.rec.recognize(make_stroke(chevron)).name)


class UnknownShapesTests(unittest.TestCase):
    def setUp(self):
        self.rec = GestureRecognizer()
        self.rng = random.Random(1)

    def accepted(self, base, n=100):
        count = 0
        for _ in range(n):
            pts = [(600 + (x - 0.5) * 300 + self.rng.gauss(0, 2),
                    400 + (y - 0.5) * 300 + self.rng.gauss(0, 2), 0.4 * i / (len(base) - 1))
                   for i, (x, y) in enumerate(base)]
            count += self.rec.recognize(pts).name is not None
        return count

    def test_foreign_drawings_are_rejected(self):
        shapes = {
            "circle": circle_points(60),
            "scribble": [(self.rng.random(), self.rng.random()) for _ in range(60)],
            "S": [(0.5 + 0.5 * math.sin(t * 6.28), t) for t in [i / 60 for i in range(61)]],
            "zigzag": polyline(SHAPES["zigzag"]),
            "L": polyline(SHAPES["L"]),
            "lambda": polyline(SHAPES["lambda"]),
            "backslash": polyline(SHAPES["backslash"]),
            "W": polyline(((0, 0), (0.25, 1), (0.5, 0.3), (0.75, 1), (1, 0))),
        }
        for name, base in shapes.items():
            self.assertEqual(self.accepted(base), 0, name)

    def test_attempt_flag_separates_clicks_from_wrong_gestures(self):
        click = self.rec.recognize([(10, 10, 0.0), (11, 10, 0.05)])
        wrong = self.rec.recognize(make_stroke(circle_points()))
        ok = self.rec.recognize(make_stroke(polyline(SHAPES["sweep"])))
        self.assertFalse(click.is_attempt)
        self.assertTrue(wrong.is_attempt)
        self.assertTrue(ok.is_attempt)

    def test_result_has_geometry_independent_of_resolution(self):
        for scale in (0.5, 1, 3):
            stroke = make_stroke(polyline(SHAPES["slash"]), scale=300 * scale,
                                 origin=(400 * scale, 300 * scale))
            rec = GestureRecognizer(reference_size=720 * scale)
            self.assertEqual(rec.recognize(stroke).name, "slash")


if __name__ == "__main__":
    unittest.main()
