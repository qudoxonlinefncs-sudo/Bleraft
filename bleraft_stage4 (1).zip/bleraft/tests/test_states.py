import unittest

from core.states import BlankState, State, StateManager


class Recorder(State):
    def __init__(self, name, log):
        super().__init__()
        self.name, self.log = name, log

    def on_enter(self):
        self.log.append(self.name + ":enter")

    def on_exit(self):
        self.log.append(self.name + ":exit")

    def update(self, dt):
        self.log.append(self.name + ":update")


class StateManagerTests(unittest.TestCase):
    def test_change_calls_exit_then_enter(self):
        log, mgr = [], StateManager()
        mgr.change(Recorder("a", log))
        mgr.change(Recorder("b", log))
        self.assertEqual(log, ["a:enter", "a:exit", "b:enter"])

    def test_update_goes_to_current_state_only(self):
        log, mgr = [], StateManager()
        mgr.change(Recorder("a", log))
        mgr.change(Recorder("b", log))
        log.clear()
        mgr.update(0.016)
        self.assertEqual(log, ["b:update"])

    def test_state_can_request_quit(self):
        mgr = StateManager()
        state = BlankState()
        mgr.change(state)
        self.assertFalse(mgr.quit_requested)
        state.manager.request_quit()
        self.assertTrue(mgr.quit_requested)

    def test_manager_without_state_is_safe(self):
        mgr = StateManager()
        mgr.update(0.1)
        mgr.handle_event(object())
        mgr.draw(object(), 0.0)

    def test_blank_state_fills_background(self):
        class Surface:
            color = None

            def fill(self, color):
                self.color = color

        import settings
        surface = Surface()
        BlankState().draw(surface, 0.0)
        self.assertEqual(surface.color, settings.BACKGROUND_COLOR)


if __name__ == "__main__":
    unittest.main()
