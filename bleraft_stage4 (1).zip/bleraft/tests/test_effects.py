import unittest

from ui.effects import Effects


class EffectsTests(unittest.TestCase):
    def test_spark_lives_and_expires(self):
        fx = Effects()
        fx.add_hit(10, 20, big=True)
        self.assertEqual(len(fx.sparks), 1)
        self.assertTrue(fx.sparks[0].big)
        fx.update(0.1)
        self.assertEqual(len(fx.sparks), 1)
        fx.update(0.3)
        self.assertEqual(fx.sparks, [])

    def test_indicator_is_replaced_and_expires(self):
        fx = Effects()
        fx.set_indicator(0, "slash", "fast", True)
        fx.update(0.5)
        fx.set_indicator(0, "sweep", "slow", False)
        self.assertEqual(fx.indicators[0].gesture, "sweep")
        self.assertEqual(fx.indicators[0].age, 0.0)
        fx.update(1.0)
        self.assertEqual(fx.indicators, {})

    def test_unknown_gesture_indicator(self):
        fx = Effects()
        fx.set_indicator(1, None, None, False)
        self.assertIsNone(fx.indicators[1].gesture)

    def test_clear(self):
        fx = Effects()
        fx.add_hit(0, 0)
        fx.set_indicator(0, "slash", "fast", True)
        fx.clear()
        self.assertEqual((fx.sparks, fx.indicators), ([], {}))


if __name__ == "__main__":
    unittest.main()
