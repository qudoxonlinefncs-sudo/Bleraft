import itertools
import unittest

import settings
from combat.attacks import (
    ATTACKS, COMBOS, SPEED_TIERS, TIER_ORDER, AttackDefinition, ComboDefinition,
    Modifiers, resolve_attack, tier_for_speed,
)
from combat.combo_system import validate_combos
from input.gesture_templates import DEFAULT_TEMPLATES

HIGHER_IS_BETTER = ("damage", "knockback", "reach", "hitstun")
LOWER_IS_BETTER = ("windup", "recovery", "total_time")


def metrics(spec):
    return {k: getattr(spec, k) for k in HIGHER_IS_BETTER + LOWER_IS_BETTER}


class AttackConfigTests(unittest.TestCase):
    def test_every_gesture_has_an_attack_and_vice_versa(self):
        self.assertEqual({t.name for t in DEFAULT_TEMPLATES}, set(ATTACKS))

    def test_attack_keys_match_names(self):
        for key, attack in ATTACKS.items():
            self.assertEqual(key, attack.name)

    def test_all_values_are_positive(self):
        for attack in ATTACKS.values():
            for field in ("windup", "active", "recovery", "damage", "knockback",
                          "hitstun", "reach", "width"):
                self.assertGreater(getattr(attack, field), 0, (attack.name, field))

    def test_hit_windows_are_valid_and_do_not_overlap(self):
        for attack in ATTACKS.values():
            last_end = 0.0
            for start, end in attack.hit_windows:
                self.assertLessEqual(0.0, start)
                self.assertLess(start, end)
                self.assertLessEqual(end, 1.0)
                self.assertGreaterEqual(start, last_end)
                last_end = end

    def test_double_strike_has_two_hit_windows_and_others_one(self):
        self.assertEqual(len(ATTACKS["double"].hit_windows), 2)
        for name in ("slash", "sweep", "thrust"):
            self.assertEqual(len(ATTACKS[name].hit_windows), 1)

    def test_attacks_have_distinct_shapes(self):
        # у каждой атаки своя дальность/ширина: нет двух одинаковых хитбоксов
        shapes = {(a.reach, a.width) for a in ATTACKS.values()}
        self.assertEqual(len(shapes), len(ATTACKS))
        self.assertGreater(ATTACKS["thrust"].reach, ATTACKS["slash"].reach)
        self.assertGreater(ATTACKS["sweep"].width, ATTACKS["slash"].width)


class SpeedTierTests(unittest.TestCase):
    def test_medium_equals_base(self):
        for name, base in ATTACKS.items():
            spec = resolve_attack(name, "medium")
            self.assertAlmostEqual(spec.windup, base.windup)
            self.assertAlmostEqual(spec.damage, base.damage)
            self.assertAlmostEqual(spec.recovery, base.recovery)

    def test_fast_is_quicker_and_weaker_and_slow_is_slower_and_stronger(self):
        for name in ATTACKS:
            fast, mid, slow = (resolve_attack(name, t) for t in TIER_ORDER)
            self.assertLess(fast.windup, mid.windup)
            self.assertLess(mid.windup, slow.windup)
            self.assertLess(fast.recovery, mid.recovery)
            self.assertLess(mid.recovery, slow.recovery)
            self.assertLess(fast.damage, mid.damage)
            self.assertLess(mid.damage, slow.damage)
            self.assertLess(fast.knockback, slow.knockback)

    def test_no_tier_is_better_in_every_stat(self):
        """Ни одна скорость не доминирует: у каждой есть и плюс, и минус."""
        for name in ATTACKS:
            specs = {t: metrics(resolve_attack(name, t)) for t in TIER_ORDER}
            for a, b in itertools.permutations(TIER_ORDER, 2):
                better = sum(
                    specs[a][k] > specs[b][k] for k in HIGHER_IS_BETTER
                ) + sum(specs[a][k] < specs[b][k] for k in LOWER_IS_BETTER)
                worse = sum(
                    specs[a][k] < specs[b][k] for k in HIGHER_IS_BETTER
                ) + sum(specs[a][k] > specs[b][k] for k in LOWER_IS_BETTER)
                self.assertGreater(better, 0, (name, a, b))
                self.assertGreater(worse, 0, (name, a, b))

    def test_slow_is_not_strictly_better_than_fast_in_damage_per_second(self):
        # медленная атака не должна быть и сильнее, и эффективнее по времени
        for name in ATTACKS:
            fast = resolve_attack(name, "fast")
            slow = resolve_attack(name, "slow")
            fast_rate = fast.damage / fast.total_time
            slow_rate = slow.damage / slow.total_time
            self.assertLessEqual(slow_rate, fast_rate * 1.05, name)

    def test_tier_table_has_exactly_three_tiers(self):
        self.assertEqual(set(SPEED_TIERS), {"fast", "medium", "slow"})
        self.assertEqual(TIER_ORDER, ("fast", "medium", "slow"))

    def test_tier_for_speed_uses_configured_thresholds(self):
        self.assertEqual(tier_for_speed(0.0), "slow")
        self.assertEqual(tier_for_speed(settings.GESTURE_SPEED_SLOW + 0.01), "medium")
        self.assertEqual(tier_for_speed(settings.GESTURE_SPEED_FAST + 0.01), "fast")
        self.assertEqual(tier_for_speed(99), "fast")
        self.assertLess(settings.GESTURE_SPEED_SLOW, settings.GESTURE_SPEED_FAST)


class FinisherConfigTests(unittest.TestCase):
    def test_default_combos_include_slash_sweep_double(self):
        self.assertIn(("slash", "sweep", "double"), [c.steps for c in COMBOS])
        self.assertGreaterEqual(len(COMBOS), 3)

    def test_combo_config_is_valid(self):
        self.assertEqual(validate_combos(COMBOS, ATTACKS), [])

    def test_finisher_has_own_parameters_and_longer_recovery(self):
        for combo in COMBOS:
            last = combo.steps[-1]
            normal = resolve_attack(last, "medium")
            finisher = resolve_attack(last, "medium", combo)
            self.assertTrue(finisher.is_finisher)
            self.assertEqual(finisher.combo_name, combo.name)
            self.assertGreater(finisher.recovery, normal.recovery * 1.5, combo.name)
            self.assertGreater(finisher.damage, normal.damage, combo.name)
            self.assertGreater(finisher.knockback, normal.knockback, combo.name)
            self.assertFalse(normal.is_finisher)

    def test_validate_catches_bad_configs(self):
        mod = Modifiers()
        self.assertTrue(validate_combos([ComboDefinition("one", ("slash",), mod)], ATTACKS))
        self.assertTrue(validate_combos([ComboDefinition("x", ("slash", "nope"), mod)], ATTACKS))
        dup = [ComboDefinition("a", ("slash", "sweep"), mod), ComboDefinition("b", ("slash", "sweep"), mod)]
        self.assertTrue(validate_combos(dup, ATTACKS))
        prefix = [ComboDefinition("a", ("slash", "sweep"), mod),
                  ComboDefinition("b", ("slash", "sweep", "thrust"), mod)]
        self.assertTrue(validate_combos(prefix, ATTACKS))


if __name__ == "__main__":
    unittest.main()
