"""Проверка ui на ПОДДЕЛЬНОМ pygame.

Это проверка нашей логики отрисовки (какие слои строятся, куда и сколько раз
выводятся, работает ли кэш), а не того, как картинка выглядит на экране.
Внешний вид и совместимость с настоящим pygame-ce нужно проверять вручную.
"""

import types
import unittest

import settings
from arena.arena import Arena
from core.gameplay import create_fighters
from ui import palette, sprites
from ui.renderer import SceneRenderer


class FakeSurface:
    def __init__(self, size, flags=0):
        self.size = size
        self.fills = []
        self.blits = []
        self.pixels = {}

    def fill(self, color):
        self.fills.append(color)

    def blit(self, source, pos):
        self.blits.append((source, pos))

    def set_at(self, pos, color):
        self.pixels[pos] = color

    def get_height(self):
        return self.size[1]


def make_fake_pygame():
    pg = types.SimpleNamespace()
    pg.SRCALPHA = 65536
    pg.created = []

    def surface_factory(size, flags=0):
        surf = FakeSurface(size, flags)
        pg.created.append(surf)
        return surf

    pg.Surface = surface_factory
    pg.rect_calls = []
    pg.ellipse_calls = []
    pg.draw = types.SimpleNamespace(
        rect=lambda *args: pg.rect_calls.append(args),
        ellipse=lambda *args: pg.ellipse_calls.append(args),
    )
    pg.transform = types.SimpleNamespace(scale=lambda surf, size: surface_factory(size))
    return pg


class SpriteDataTests(unittest.TestCase):
    def test_grid_is_square_and_rows_have_equal_length(self):
        self.assertTrue(all(len(row) == sprites.GRID_SIZE for row in sprites.FIGHTER_GRID))

    def test_sprite_size_matches_player_size(self):
        self.assertEqual(sprites.GRID_SIZE * settings.SPRITE_SCALE, settings.PLAYER_SIZE)

    def test_every_symbol_is_in_every_team_palette(self):
        symbols = {c for row in sprites.FIGHTER_GRID for c in row} - {"."}
        for team, colors in palette.TEAM_PALETTES.items():
            self.assertTrue(symbols <= set(colors), team)

    def test_teams_look_different(self):
        self.assertNotEqual(palette.TEAM_PALETTES["blue"]["M"],
                            palette.TEAM_PALETTES["red"]["M"])

    def test_build_sprite_paints_only_opaque_pixels_and_scales(self):
        pg = make_fake_pygame()
        sprite = sprites.build_fighter_sprite(pg, "blue", settings.SPRITE_SCALE)
        small = pg.created[0]
        opaque = sum(1 for row in sprites.FIGHTER_GRID for c in row if c != ".")
        self.assertEqual(len(small.pixels), opaque)
        self.assertEqual(sprite.size, (settings.PLAYER_SIZE, settings.PLAYER_SIZE))


class RendererTests(unittest.TestCase):
    def setUp(self):
        self.pg = make_fake_pygame()
        self.renderer = SceneRenderer(self.pg)
        self.arena = Arena.from_settings()
        self.fighters = create_fighters(self.arena)
        self.screen = FakeSurface((settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT))

    def draw(self, alpha=1.0):
        self.renderer.draw(self.screen, self.arena, self.fighters, alpha)

    def test_background_is_filled_first(self):
        self.draw()
        self.assertEqual(self.screen.fills, [settings.BACKGROUND_COLOR])

    def test_blit_count_arena_plus_shadow_and_sprite_per_fighter(self):
        self.draw()
        self.assertEqual(len(self.screen.blits), 1 + 2 * len(self.fighters))

    def test_arena_layer_is_placed_with_frame_offset(self):
        self.draw()
        layer, pos = self.screen.blits[0]
        frame = settings.ARENA_FRAME
        self.assertEqual(pos, (self.arena.left - frame, self.arena.top - frame))
        self.assertEqual(
            layer.size,
            (self.arena.width + 2 * frame, self.arena.height + 2 * frame),
        )

    def test_sprites_are_pixel_snapped_at_fighter_positions(self):
        self.draw(alpha=1.0)
        half = settings.PLAYER_SIZE // 2
        positions = [pos for _, pos in self.screen.blits[1:]]
        for fighter in self.fighters:
            expected = (round(fighter.x) - half, round(fighter.y) - half)
            self.assertIn(expected, positions)

    def test_interpolation_alpha_changes_draw_position(self):
        blue = self.fighters[0]
        blue.update(0.5, (1, 0), self.arena.bounds)  # сдвиг вправо
        self.draw(alpha=0.0)
        at_start = {pos for _, pos in self.screen.blits}
        self.screen.blits.clear()
        self.draw(alpha=1.0)
        at_end = {pos for _, pos in self.screen.blits}
        self.assertNotEqual(at_start, at_end)

    def test_each_team_gets_its_own_sprite(self):
        self.draw()
        sprite_surfaces = {id(src) for src, _ in self.screen.blits[1:]
                           if src.size == (settings.PLAYER_SIZE, settings.PLAYER_SIZE)}
        self.assertEqual(len(sprite_surfaces), 2)

    def test_layers_are_cached_between_frames(self):
        self.draw()
        created_after_first = len(self.pg.created)
        rects_after_first = len(self.pg.rect_calls)
        self.draw()
        self.draw()
        self.assertEqual(len(self.pg.created), created_after_first)
        self.assertEqual(len(self.pg.rect_calls), rects_after_first)

    def test_arena_layer_rebuilt_when_arena_changes(self):
        self.draw()
        before = len(self.pg.created)
        self.arena = Arena(10, 10, 300, 200)
        self.draw()
        self.assertEqual(len(self.pg.created), before + 1)


if __name__ == "__main__":
    unittest.main()
