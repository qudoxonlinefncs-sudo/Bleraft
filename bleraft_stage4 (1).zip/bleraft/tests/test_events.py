import unittest

from core.events import EventBus


class EventBusTests(unittest.TestCase):
    def test_publish_calls_subscribers_with_data(self):
        bus, got = EventBus(), []
        bus.subscribe("damage", lambda **d: got.append(d))
        bus.publish("damage", amount=5)
        self.assertEqual(got, [{"amount": 5}])

    def test_unsubscribe(self):
        bus, got = EventBus(), []

        def handler(**d):
            got.append(d)

        bus.subscribe("x", handler)
        bus.unsubscribe("x", handler)
        bus.publish("x")
        self.assertEqual(got, [])

    def test_publish_without_subscribers_is_ok(self):
        EventBus().publish("nobody")

    def test_handler_may_unsubscribe_itself(self):
        bus, got = EventBus(), []

        def once(**d):
            got.append(1)
            bus.unsubscribe("e", once)

        bus.subscribe("e", once)
        bus.publish("e")
        bus.publish("e")
        self.assertEqual(got, [1])


if __name__ == "__main__":
    unittest.main()
