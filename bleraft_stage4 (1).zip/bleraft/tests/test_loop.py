import unittest

from core.loop import FixedStepLoop


class FixedStepLoopTests(unittest.TestCase):
    def setUp(self):
        self.loop = FixedStepLoop(ticks_per_second=60, max_frame_time=0.25)
        self.steps = []

    def _update(self, dt):
        self.steps.append(dt)

    def test_small_frame_gives_no_tick_and_keeps_remainder(self):
        ticks = self.loop.advance(0.005, self._update)
        self.assertEqual(ticks, 0)
        self.assertGreater(self.loop.alpha, 0.0)

    def test_exact_step_gives_one_tick(self):
        ticks = self.loop.advance(1 / 60, self._update)
        self.assertEqual(ticks, 1)
        self.assertAlmostEqual(self.steps[0], 1 / 60)

    def test_long_frame_gives_several_ticks(self):
        ticks = self.loop.advance(3 / 60, self._update)
        self.assertEqual(ticks, 3)

    def test_one_second_of_frames_gives_about_60_ticks(self):
        total = 0
        for _ in range(100):  # 100 кадров по 10 мс = 1 секунда
            total += self.loop.advance(0.01, self._update)
        self.assertIn(total, (59, 60))
        self.assertEqual(self.loop.tick_count, total)

    def test_huge_frame_is_capped(self):
        ticks = self.loop.advance(10.0, self._update)
        self.assertEqual(ticks, 15)  # 0.25 c * 60

    def test_negative_frame_time_is_ignored(self):
        self.assertEqual(self.loop.advance(-1.0, self._update), 0)

    def test_invalid_tick_rate_rejected(self):
        with self.assertRaises(ValueError):
            FixedStepLoop(0, 0.25)

    def test_should_stop_prevents_further_ticks(self):
        ticks = self.loop.advance(
            5 / 60, self._update, should_stop=lambda: len(self.steps) >= 2
        )
        self.assertEqual(ticks, 2)
        self.assertEqual(len(self.steps), 2)
        self.assertEqual(self.loop.tick_count, 2)

    def test_should_stop_already_true_gives_zero_ticks(self):
        ticks = self.loop.advance(3 / 60, self._update, should_stop=lambda: True)
        self.assertEqual(ticks, 0)
        self.assertEqual(self.steps, [])

    def test_should_stop_false_keeps_normal_behaviour(self):
        ticks = self.loop.advance(3 / 60, self._update, should_stop=lambda: False)
        self.assertEqual(ticks, 3)


if __name__ == "__main__":
    unittest.main()
