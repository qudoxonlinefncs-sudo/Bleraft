"""Движение. Чистая логика, без Pygame."""

import math


def clamp_direction_length(dx, dy):
    """Ограничивает длину вектора направления единицей.

    Цифровая диагональ (1, 1) имеет длину ~1.41 и превращается в вектор
    длины 1, поэтому по диагонали персонаж не бежит быстрее. Более короткие
    векторы (например, от стика геймпада) остаются как есть.
    """
    length = math.hypot(dx, dy)
    if length <= 1.0:
        return float(dx), float(dy)
    return dx / length, dy / length


def step_position(x, y, direction, speed, dt):
    """Новая позиция после шага dt секунд. Скорость - пиксели в секунду."""
    dx, dy = clamp_direction_length(direction[0], direction[1])
    return x + dx * speed * dt, y + dy * speed * dt
