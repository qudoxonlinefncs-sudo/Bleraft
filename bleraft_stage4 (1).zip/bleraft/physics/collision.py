"""Столкновения. Чистая логика, без Pygame."""


def _clamp_axis(center, half_size, low, high):
    lowest = low + half_size
    highest = high - half_size
    if lowest > highest:  # область меньше объекта: ставим по центру
        return (low + high) / 2
    return min(max(center, lowest), highest)


def clamp_box_to_bounds(cx, cy, width, height, bounds):
    """Возвращает центр прямоугольника, целиком лежащего внутри bounds.

    bounds = (left, top, right, bottom). Каждая ось ограничивается отдельно,
    поэтому у стены персонаж скользит вдоль неё, а не залипает.
    """
    left, top, right, bottom = bounds
    return (
        _clamp_axis(cx, width / 2, left, right),
        _clamp_axis(cy, height / 2, top, bottom),
    )


def limit_motion(old, new, low, high):
    """Не даёт ДВИЖЕНИЕМ выйти за [low, high], но и не затягивает назад.

    Если объект уже оказался снаружи (его вынесло отбрасыванием), он может
    идти только внутрь: стена не тянет его обратно и не мешает Ring Out.
    """
    if low > high:
        return (low + high) / 2
    new = min(new, max(old, high))
    return max(new, min(old, low))
