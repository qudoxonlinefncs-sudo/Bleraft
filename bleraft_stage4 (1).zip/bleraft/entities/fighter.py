"""Игровой персонаж. Чистая логика, без Pygame."""

import math
from enum import Enum

import settings
from physics.collision import clamp_box_to_bounds, limit_motion
from physics.movement import clamp_direction_length, step_position


class FighterState(Enum):
    IDLE = "idle"
    WINDUP = "windup"        # подготовка атаки
    ACTIVE = "active"        # активная фаза атаки
    RECOVERY = "recovery"    # восстановление после атаки
    HITSTUN = "hitstun"      # потеря управления после попадания
    DEAD = "dead"


class Fighter:
    def __init__(self, team, x, y, size, speed, max_hp=None):
        self.team = team          # "blue" / "red": ключ палитры и команда
        self.x = x                # центр хитбокса
        self.y = y
        self.prev_x = x           # позиция на прошлом тике (для интерполяции)
        self.prev_y = y
        self.width = size
        self.height = size
        self.speed = speed        # пикселей в секунду

        # --- бой (изменяется боевой системой) ---
        self.max_hp = settings.MAX_HP if max_hp is None else max_hp
        self.hp = float(self.max_hp)
        self.facing = (1.0, 0.0)  # единичный вектор взгляда
        self.state = FighterState.IDLE
        self.hitstun_remaining = 0.0
        self.hit_flash = 0.0      # секунд белой вспышки
        self.move_factor = 1.0    # доля обычной скорости (зависит от состояния)
        self.knock_vx = 0.0       # скорость отбрасывания, px/с
        self.knock_vy = 0.0
        self.ring_out = False     # вылетел за край арены
        self.ring_out_time = 0.0  # сколько секунд падает (для анимации)
        self.attack = None        # текущая атака (combat_system.AttackInstance)
        self.combo = None         # трекер комбо (combat.combo_system.ComboTracker)

    @property
    def alive(self):
        return self.state is not FighterState.DEAD

    @property
    def box(self):
        """Осевой прямоугольник (left, top, right, bottom)."""
        hw, hh = self.width / 2, self.height / 2
        return (self.x - hw, self.y - hh, self.x + hw, self.y + hh)

    def update(self, dt, direction, bounds, knock_through=False):
        """Один тик логики: движение, отбрасывание, границы.

        По умолчанию боец целиком удерживается внутри bounds. С knock_through=True
        bounds - стена только для ходьбы: отбрасывание может вынести бойца за край
        (тогда сцена засчитывает Ring Out), а стена не тянет его обратно.
        """
        self.prev_x, self.prev_y = self.x, self.y

        # сначала нормализуем диагональ, потом применяем множитель состояния
        dx, dy = clamp_direction_length(direction[0], direction[1])
        x, y = step_position(
            self.x, self.y,
            (dx * self.move_factor, dy * self.move_factor),
            self.speed, dt,
        )

        kx = ky = 0.0   # смещение от отбрасывания в этом тике
        # отбрасывание: равномерное торможение. Путь считается точно и не зависит
        # от dt, в том числе когда остановка происходит посреди шага.
        speed = math.hypot(self.knock_vx, self.knock_vy)
        if speed > 0.0:
            decel = settings.KNOCKBACK_DECEL
            stop_time = speed / decel
            if dt >= stop_time:
                distance = speed * stop_time / 2
                new_speed = 0.0
            else:
                new_speed = speed - decel * dt
                distance = (speed + new_speed) / 2 * dt
            kx = self.knock_vx / speed * distance
            ky = self.knock_vy / speed * distance
            x += kx
            y += ky
            ratio = new_speed / speed
            self.knock_vx *= ratio
            self.knock_vy *= ratio
            if new_speed == 0.0:
                self.knock_vx = self.knock_vy = 0.0

        if not knock_through:
            self.x, self.y = clamp_box_to_bounds(x, y, self.width, self.height, bounds)
            return
        left, top, right, bottom = bounds
        hw, hh = self.width / 2, self.height / 2
        walk_x = limit_motion(self.x, x - kx, left + hw, right - hw) + kx
        walk_y = limit_motion(self.y, y - ky, top + hh, bottom - hh) + ky
        self.x, self.y = walk_x, walk_y

    def render_position(self, alpha):
        """Позиция между прошлым и текущим тиком; alpha в диапазоне 0..1."""
        return (
            self.prev_x + (self.x - self.prev_x) * alpha,
            self.prev_y + (self.y - self.prev_y) * alpha,
        )
