"""Бот-противник. Чистая логика, без Pygame.

Честность:
  - бот видит игрока только через Observation (положение, взгляд, состояние,
    HP и видимая зона атаки - то, что видит человек), и с задержкой `reaction`;
  - бот не читает ввод игрока (след мыши, нераспознанные жесты, Combo Rush игрока);
  - атаку бот "рисует" draw_time секунд, как игрок рисует жест;
  - бот ходит с той же скоростью, бьёт теми же атаками и по тем же правилам.

Поведение: держит дистанцию и обходит игрока по кругу, сближается и отступает,
уклоняется от замеченной атаки (шаг в сторону или назад - что быстрее),
наказывает промах и восстановление игрока, продолжает комбо, не стоит у края
арены и на растрескавшихся плитках.
"""

import math
import random
from collections import deque
from dataclasses import dataclass

from ai.difficulty import DIFFICULTIES
from combat.attacks import resolve_attack
from combat.hitbox import attack_hitbox
from entities.fighter import FighterState

_EPS = 1e-6
FAST_WINDUP = resolve_attack("slash", "fast").windup


@dataclass(frozen=True)
class Intent:
    direction: tuple = (0.0, 0.0)
    gesture: str = None
    tier: str = "medium"


@dataclass(frozen=True)
class Observation:
    """Публичная информация о бойце: что видно на экране."""

    time: float
    x: float
    y: float
    facing: tuple
    state: FighterState
    hp: float
    max_hp: float
    spec: object          # AttackSpec видимой атаки (зона удара нарисована на экране)
    phase: object         # фаза атаки (подготовка/активная/восстановление)
    attack_facing: tuple
    phase_remaining: float


def observe(fighter, now):
    atk = fighter.attack
    return Observation(
        time=now, x=fighter.x, y=fighter.y, facing=fighter.facing,
        state=fighter.state, hp=fighter.hp, max_hp=fighter.max_hp,
        spec=atk.spec if atk else None,
        phase=atk.phase if atk else None,
        attack_facing=atk.facing if atk else fighter.facing,
        phase_remaining=(atk.phase_duration - atk.phase_time) if atk else 0.0,
    )


def _unit(dx, dy):
    n = math.hypot(dx, dy)
    return (dx / n, dy / n) if n > _EPS else (0.0, 0.0)


class BotController:
    def __init__(self, difficulty="normal", seed=0):
        self.d = DIFFICULTIES[difficulty] if isinstance(difficulty, str) else difficulty
        self.seed = seed
        self.reset()

    def reset(self):
        self.rng = random.Random(self.seed)
        self.history = deque()
        self.next_decision = 0.0
        self.direction = (0.0, 0.0)
        self.strafe = 1.0
        self.strafe_until = 0.0
        self.dodge = None             # (направление, до какого времени)
        self.threat_handled = False   # решение по текущей атаке игрока уже принято
        self.pending = None           # (когда выполнить, жест, скорость)
        self.retreat_until = 0.0
        self.last_hp = None
        self.punish_decided = False   # решение "наказывать ли" принято для текущей атаки игрока
        self.punish_go = False

    # ---------- восприятие ----------

    def _delayed(self, now):
        """Самое свежее наблюдение, которое бот уже успел осмыслить."""
        limit = now - self.d.reaction
        chosen = None
        for obs in self.history:
            if obs.time <= limit:
                chosen = obs
            else:
                break
        while len(self.history) > 2 and self.history[1].time <= limit:
            self.history.popleft()
        return chosen

    @staticmethod
    def _opponent(scene, index):
        me = scene.fighters[index]
        enemies = [f for f in scene.fighters if f.team != me.team and f.alive]
        if not enemies:
            return None
        return min(enemies, key=lambda f: math.hypot(f.x - me.x, f.y - me.y))

    # ---------- главный метод ----------

    def think(self, scene, index, dt):
        now = scene.time
        me = scene.fighters[index]
        opp = self._opponent(scene, index)
        if opp is None or not me.alive:
            return Intent()
        self.history.append(observe(opp, now))
        obs = self._delayed(now)
        if obs is not None and obs.state not in (
                FighterState.WINDUP, FighterState.ACTIVE, FighterState.RECOVERY):
            self.punish_decided = False

        gesture, tier = None, "medium"
        if self.pending is not None and now >= self.pending[0]:
            _, gesture, tier = self.pending
            self.pending = None
            if me.state in (FighterState.HITSTUN, FighterState.DEAD):
                gesture = None

        if self.last_hp is not None and me.hp < self.last_hp:
            if self.rng.random() < 0.5:
                self.retreat_until = now + 0.3             # получил удар: иногда отступить
            self.pending = None
        self.last_hp = me.hp

        if obs is not None and now >= self.next_decision:
            self.next_decision = now + self.d.decision_interval
            self._decide(scene, me, obs, now)
        if self.dodge is not None:
            if now >= self.dodge[1]:
                self.dodge = None
            else:
                return Intent(self.dodge[0], gesture, tier)
        return Intent(self.direction, gesture, tier)

    # ---------- решения ----------

    def _decide(self, scene, me, obs, now):
        floor = scene.floor
        bounds = scene.arena.bounds
        to_opp = _unit(obs.x - me.x, obs.y - me.y)
        dist = math.hypot(obs.x - me.x, obs.y - me.y)

        # ничего не решаем за бойца, который занят (движение ограничено самой игрой)
        if me.state in (FighterState.HITSTUN, FighterState.DEAD):
            self.direction = (0.0, 0.0)
            return
        if me.state in (FighterState.WINDUP, FighterState.ACTIVE):
            self.direction = to_opp if dist > 70 else (0.0, 0.0)
            return
        if me.state is FighterState.RECOVERY:
            threat = obs.state in (FighterState.WINDUP, FighterState.ACTIVE) or dist < 80
            self.direction = (-to_opp[0], -to_opp[1]) if threat else (0.0, 0.0)
            self._maybe_continue_combo(scene, me, obs, now, dist)
            return

        # 1. безопасность арены важнее боя
        safe = self._safety_vector(me, floor, bounds)
        if safe is not None:
            self.direction = safe
            return

        # 2. уклонение от замеченной атаки
        if self._try_dodge(scene, me, obs, now, bounds):
            return

        # 3. наказание: игрок восстанавливается после атаки
        if self._try_punish(me, obs, now, dist, to_opp):
            return

        # 4. отступление после полученного удара
        if now < self.retreat_until:
            perp = (-to_opp[1] * self.strafe, to_opp[0] * self.strafe)
            self.direction = _unit(-to_opp[0] + 0.5 * perp[0], -to_opp[1] + 0.5 * perp[1])
            return

        # 5. нейтральная игра: дистанция, обход по кругу, атака
        self._neutral(scene, me, obs, now, dist, to_opp)

    def _safety_vector(self, me, floor, bounds):
        """Куда идти, если боец у края, на трещинах или в зоне будущего обрушения."""
        if floor is None:
            return None
        left, top, right, bottom = bounds
        margin = 55.0
        warn_rect = None
        if floor.warning_active:                       # кольцо скоро упадёт
            warn_rect = (left + floor.tile, top + floor.tile, right - floor.tile, bottom - floor.tile)
        near_edge = (me.x - left < margin or right - me.x < margin
                     or me.y - top < margin or bottom - me.y < margin)
        in_warning = warn_rect is not None and not (
            warn_rect[0] + 20 <= me.x <= warn_rect[2] - 20
            and warn_rect[1] + 20 <= me.y <= warn_rect[3] - 20)
        if not (near_edge or in_warning):
            return None
        target = warn_rect or bounds
        cx, cy = (target[0] + target[2]) / 2, (target[1] + target[3]) / 2
        return _unit(cx - me.x, cy - me.y)

    def _try_dodge(self, scene, me, obs, now, bounds):
        if obs.state is not FighterState.WINDUP or obs.spec is None:
            self.threat_handled = obs.state in (FighterState.ACTIVE,) and self.threat_handled
            if obs.state not in (FighterState.WINDUP, FighterState.ACTIVE):
                self.threat_handled = False
            return False
        spec = obs.spec
        box = me.box
        inflated = (box[0] - 4, box[1] - 4, box[2] + 4, box[3] + 4)
        zone = attack_hitbox(obs.x, obs.y, obs.attack_facing, spec)
        if not zone.intersects_box(inflated):
            return False                                   # атака в другую сторону
        if self.threat_handled:
            return self.dodge is not None
        self.threat_handled = True
        if self.rng.random() >= self.d.dodge_skill:
            return False                                   # не заметил / не успел решить

        fx, fy = obs.attack_facing
        rx, ry = -fy, fx
        rel = (me.x - obs.x, me.y - obs.y)
        p = rel[0] * fx + rel[1] * fy
        q = rel[0] * rx + rel[1] * ry
        speed = me.speed
        left, top, right, bottom = bounds
        options = []
        # шаг назад (от атакующего вдоль удара)
        far = spec.start_offset + spec.reach + me.width / 2 + 6
        options.append(((fx, fy), max(0.0, far - p) / speed))
        # шаг в сторону
        lateral = spec.width / 2 + me.width / 2 + 6
        side = 1.0 if q > 0 else (-1.0 if q < 0 else self.rng.choice((-1.0, 1.0)))
        options.append(((rx * side, ry * side), max(0.0, lateral - abs(q)) / speed))
        usable = []
        for direction, seconds in options:
            ex, ey = me.x + direction[0] * (seconds * speed + 30), me.y + direction[1] * (seconds * speed + 30)
            if left + 18 <= ex <= right - 18 and top + 18 <= ey <= bottom - 18:
                usable.append((seconds, direction))
        if not usable:
            return False
        seconds, direction = min(usable)
        real_remaining = obs.phase_remaining - (now - obs.time)
        if seconds <= real_remaining + 0.04 or self.rng.random() < 0.25:
            self.dodge = (direction, now + seconds + 0.06)
            self.direction = direction
            return True
        return False

    def _try_punish(self, me, obs, now, dist, to_opp):
        """Наказание: игрок промахнулся (или заканчивает атаку) и скоро беззащитен.

        Длительность фаз атак - публичные правила игры, поэтому бот может заранее
        прикинуть, когда игрок снова сможет действовать, и успеть ударить.
        """
        if obs.spec is None or obs.state not in (
                FighterState.WINDUP, FighterState.ACTIVE, FighterState.RECOVERY):
            return False
        if obs.state is not FighterState.RECOVERY:
            box = me.box
            zone = attack_hitbox(obs.x, obs.y, obs.attack_facing, obs.spec)
            if zone.intersects_box((box[0] - 4, box[1] - 4, box[2] + 4, box[3] + 4)):
                return False            # атака заденет бота: это дело уклонения
        spec = obs.spec
        if obs.state is FighterState.WINDUP:
            until_free = obs.phase_remaining + spec.active + spec.recovery
        elif obs.state is FighterState.ACTIVE:
            until_free = obs.phase_remaining + spec.recovery
        else:
            until_free = obs.phase_remaining
        real_remaining = until_free - (now - obs.time)
        need = 0.5 * self.d.draw_time + FAST_WINDUP
        if real_remaining < need:
            return False
        if not self.punish_decided:
            self.punish_decided = True
            self.punish_go = self.rng.random() < self.d.punish_skill
        if not self.punish_go:
            return False
        if obs.state is not FighterState.RECOVERY:
            # удар игрока ещё не закончился: не лезть в его зону, ждать на месте
            self.direction = (0.0, 0.0)
            return True
        choice = self._choose_attack(dist, obs, prefer_fast=True)
        if choice is not None and self.pending is None:
            self._schedule(now, *choice, quick=True)
            self.direction = to_opp if dist > 60 else (0.0, 0.0)
            return True
        self.direction = to_opp                           # сблизиться, пока игрок беззащитен
        return True

    def _maybe_continue_combo(self, scene, me, obs, now, dist):
        tracker = me.combo
        if tracker is None or self.pending is not None or not tracker.history:
            return
        options = [g for g in tracker.next_gestures() if tracker.can_continue(g, now)]
        if options and dist < 95 and self.rng.random() < min(1.0, self.d.aggression + 0.25):
            self._schedule(now, self.rng.choice(options), "medium", quick=True)

    def _neutral(self, scene, me, obs, now, dist, to_opp):
        d = self.d
        if now >= self.strafe_until:
            self.strafe = self.rng.choice((-1.0, 1.0))
            self.strafe_until = now + self.rng.uniform(0.8, 1.8)
        perp = (-to_opp[1] * self.strafe, to_opp[0] * self.strafe)
        ideal = 82.0
        if dist > ideal + 14:
            self.direction = _unit(to_opp[0] + 0.35 * perp[0], to_opp[1] + 0.35 * perp[1])
        elif dist < 52:
            self.direction = _unit(-to_opp[0] + 0.6 * perp[0], -to_opp[1] + 0.6 * perp[1])
        else:
            self.direction = _unit(0.25 * to_opp[0] + perp[0], 0.25 * to_opp[1] + perp[1])
        if self.pending is None and obs.state is not FighterState.WINDUP:
            reach_factor = 1.0 if dist <= 100 else (0.6 if dist <= 130 else 0.0)  # дальше - только выпад
            if self.rng.random() < d.aggression * reach_factor:
                choice = self._choose_attack(dist, obs, prefer_fast=False)
                if choice is not None:
                    self._schedule(now, *choice)

    # ---------- выбор атаки ----------

    def _reach(self, gesture, tier):
        spec = resolve_attack(gesture, tier)
        return spec.start_offset + spec.reach + 18      # макс. расстояние между центрами

    def _choose_attack(self, dist, obs, prefer_fast):
        tiers = ("fast", "medium") if prefer_fast else ("fast", "medium", "medium", "slow")
        tier = self.rng.choice(tiers)
        candidates = [g for g in ("slash", "sweep", "thrust", "double")
                      if dist <= self._reach(g, tier) * 0.92]
        if self.rng.random() < self.d.mistake:
            candidates = ["slash", "sweep", "thrust", "double"]   # ошибка: может не достать
        if not candidates:
            return None
        weights = {"slash": 3, "sweep": 2, "double": 2 if dist < 70 else 0.5,
                   "thrust": 3 if dist > 85 else 1}
        gesture = self.rng.choices(candidates, [weights[g] for g in candidates])[0]
        return gesture, tier

    def _schedule(self, now, gesture, tier, quick=False):
        delay = self.d.draw_time * (0.5 if quick else 1.0)
        self.pending = (now + delay, gesture, tier)
