"""Сложность бота: только качество решений и время реакции.

У бота те же HP, скорость, урон и правила, что у игрока. Нечестных бонусов нет.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Difficulty:
    name: str
    label: str
    reaction: float           # задержка восприятия: бот видит игрока таким, каким тот был давно
    decision_interval: float  # как часто бот принимает решения
    aggression: float         # шанс начать атаку, когда она возможна (0..1)
    dodge_skill: float        # шанс попытаться уклониться от замеченной атаки
    punish_skill: float       # шанс наказать промах/восстановление игрока
    draw_time: float          # "рисование жеста": задержка между решением и началом атаки
    mistake: float            # шанс выбрать неудачный жест или момент


DIFFICULTIES = {
    "easy": Difficulty("easy", "ЛЁГКИЙ", 0.40, 0.16, 0.35, 0.30, 0.35, 0.30, 0.30),
    "normal": Difficulty("normal", "СРЕДНИЙ", 0.27, 0.12, 0.55, 0.55, 0.65, 0.22, 0.15),
    "hard": Difficulty("hard", "СЛОЖНЫЙ", 0.21, 0.10, 0.65, 0.70, 0.78, 0.19, 0.10),
}
DIFFICULTY_ORDER = ("easy", "normal", "hard")
