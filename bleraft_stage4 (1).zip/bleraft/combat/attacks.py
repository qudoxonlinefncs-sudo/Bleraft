"""Конфигурация боя: атаки, скоростные категории жестов, комбо.

ЗДЕСЬ находятся все числа баланса (урон, время, дальность, отбрасывание).
Логика боя (combat_system.py, combo_system.py) чисел не содержит.
Время - в секундах, расстояния - в пикселях, отбрасывание - начальная
скорость в px/с (торможение задаётся settings.KNOCKBACK_DECEL).

Ключ атаки совпадает с именем жеста в input/gesture_templates.py.
"""

from dataclasses import dataclass

import settings


@dataclass(frozen=True)
class AttackDefinition:
    """Базовые (средняя скорость жеста) параметры атаки."""

    name: str
    windup: float        # подготовка: урона нет, можно уклониться
    active: float        # активная фаза: хитбокс наносит урон
    recovery: float      # восстановление: боец уязвим и почти не двигается
    damage: float        # урон одного попадания
    knockback: float     # начальная скорость отбрасывания цели
    hitstun: float       # на сколько цель теряет управление
    reach: float         # длина хитбокса вперёд
    width: float         # ширина хитбокса
    start_offset: float = 10.0   # от центра бойца до ближнего края хитбокса
    # Окна попаданий внутри активной фазы (доли её длительности). Одно окно -
    # один удар; несколько окон - несколько ударов (например, двойной).
    hit_windows: tuple = ((0.0, 1.0),)


@dataclass(frozen=True)
class Modifiers:
    """Множители к параметрам атаки."""

    windup: float = 1.0
    active: float = 1.0
    recovery: float = 1.0
    damage: float = 1.0
    knockback: float = 1.0
    hitstun: float = 1.0
    reach: float = 1.0


# Быстрый жест: быстрее и безопаснее, но слабее и короче.
# Медленный жест: сильнее и дальше, но долгая подготовка и восстановление.
SPEED_TIERS = {
    "fast": Modifiers(windup=0.6, active=0.9, recovery=0.7, damage=0.7,
                      knockback=0.8, hitstun=0.9, reach=0.9),
    "medium": Modifiers(),
    "slow": Modifiers(windup=1.7, active=1.1, recovery=1.55, damage=1.4,
                      knockback=1.4, hitstun=1.1, reach=1.1),
}
TIER_ORDER = ("fast", "medium", "slow")


ATTACKS = {
    # `/` - диагональный удар: универсальный
    "slash": AttackDefinition(
        "slash", windup=0.18, active=0.10, recovery=0.28,
        damage=8, knockback=380, hitstun=0.30, reach=64, width=70),
    # `-` - горизонтальный взмах: широкий, но короткий
    "sweep": AttackDefinition(
        "sweep", windup=0.22, active=0.12, recovery=0.32,
        damage=7, knockback=330, hitstun=0.30, reach=52, width=110),
    # `|` - выпад: узкий и длинный, долгое восстановление при промахе
    "thrust": AttackDefinition(
        "thrust", windup=0.14, active=0.08, recovery=0.40,
        damage=9, knockback=300, hitstun=0.32, reach=112, width=24),
    # `V` - двойной удар: два попадания в одной активной фазе
    "double": AttackDefinition(
        "double", windup=0.26, active=0.34, recovery=0.38,
        damage=5, knockback=260, hitstun=0.28, reach=60, width=64,
        hit_windows=((0.0, 0.25), (0.55, 0.80))),
}


@dataclass(frozen=True)
class ComboDefinition:
    name: str
    steps: tuple             # последовательность имён жестов
    finisher: Modifiers      # собственные параметры завершающей атаки


COMBOS = (
    ComboDefinition("classic", ("slash", "sweep", "double"),
                    Modifiers(damage=1.6, knockback=1.8, recovery=1.8,
                              hitstun=1.3, reach=1.1)),
    ComboDefinition("lunge", ("thrust", "slash"),
                    Modifiers(damage=1.5, knockback=1.6, recovery=1.8,
                              hitstun=1.3, reach=1.1)),
    ComboDefinition("cross", ("sweep", "thrust", "double"),
                    Modifiers(damage=1.6, knockback=1.7, recovery=1.8,
                              hitstun=1.3, reach=1.1)),
)


@dataclass(frozen=True)
class AttackSpec:
    """Готовые параметры конкретной атаки с учётом скорости жеста и комбо."""

    name: str
    tier: str
    windup: float
    active: float
    recovery: float
    damage: float
    knockback: float
    hitstun: float
    reach: float
    width: float
    start_offset: float
    hit_windows: tuple
    is_finisher: bool = False
    combo_name: str = ""

    @property
    def total_time(self):
        return self.windup + self.active + self.recovery


def tier_for_speed(speed):
    """Категория скорости жеста по порогам из settings (доля экрана в секунду)."""
    if speed >= settings.GESTURE_SPEED_FAST:
        return "fast"
    if speed <= settings.GESTURE_SPEED_SLOW:
        return "slow"
    return "medium"


def resolve_attack(name, tier="medium", combo=None):
    """Параметры атаки: база * множители скорости * множители завершающей атаки."""
    base = ATTACKS[name]
    tm = SPEED_TIERS[tier]
    fm = combo.finisher if combo is not None else Modifiers()
    return AttackSpec(
        name=name,
        tier=tier,
        windup=base.windup * tm.windup * fm.windup,
        active=base.active * tm.active * fm.active,
        recovery=base.recovery * tm.recovery * fm.recovery,
        damage=base.damage * tm.damage * fm.damage,
        knockback=base.knockback * tm.knockback * fm.knockback,
        hitstun=base.hitstun * tm.hitstun * fm.hitstun,
        reach=base.reach * tm.reach * fm.reach,
        width=base.width,
        start_offset=base.start_offset,
        hit_windows=base.hit_windows,
        is_finisher=combo is not None,
        combo_name=combo.name if combo is not None else "",
    )
