"""Хитбоксы атак: ориентированный прямоугольник против прямоугольника бойца."""

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class OrientedBox:
    """Прямоугольник, повёрнутый по направлению (fx, fy) (единичный вектор)."""

    cx: float
    cy: float
    fx: float
    fy: float
    half_length: float   # вдоль направления
    half_width: float    # поперёк

    def corners(self):
        rx, ry = -self.fy, self.fx   # перпендикуляр
        out = []
        for sl, sw in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            out.append((
                self.cx + self.fx * self.half_length * sl + rx * self.half_width * sw,
                self.cy + self.fy * self.half_length * sl + ry * self.half_width * sw,
            ))
        return out

    def intersects_box(self, bounds):
        """Пересечение с осевым прямоугольником bounds = (l, t, r, b).

        Метод разделяющих осей. Касание считается пересечением.
        """
        left, top, right, bottom = bounds
        box_corners = [(left, top), (right, top), (right, bottom), (left, bottom)]
        own_corners = self.corners()
        axes = ((1.0, 0.0), (0.0, 1.0), (self.fx, self.fy), (-self.fy, self.fx))
        for ax, ay in axes:
            own = [x * ax + y * ay for x, y in own_corners]
            other = [x * ax + y * ay for x, y in box_corners]
            if max(own) < min(other) or max(other) < min(own):
                return False
        return True


def attack_hitbox(x, y, facing, spec, scale=1.0):
    """Хитбокс атаки перед бойцом в точке (x, y) с направлением facing.

    scale < 1 даёт укороченный хитбокс от ближнего края (для анимации подготовки).
    """
    fx, fy = facing
    length = math.hypot(fx, fy)
    if length < 1e-9:
        fx, fy, length = 1.0, 0.0, 1.0
    fx, fy = fx / length, fy / length
    half_length = spec.reach * scale / 2
    middle = spec.start_offset + half_length
    return OrientedBox(x + fx * middle, y + fy * middle, fx, fy,
                       half_length, spec.width / 2)
