"""Комбо: отслеживание цепочки жестов бойца. Чистая логика.

Правила:
- Цепочка продолжается, только если следующий жест - продолжение какого-либо
  комбо и введён в окне комбо. Окно открывается на COMBO_CANCEL_FRACTION
  восстановления предыдущей атаки и закрывается через COMBO_WINDOW_AFTER
  секунд после его конца.
- Ввод раньше окна не засчитывается (боевая система его отклоняет),
  позже - цепочка сбрасывается по тайм-ауту.
- Жест вне цепочки начинает новую цепочку.
- Завершающая атака комбо закрывает цепочку и окна после неё нет.
"""

from dataclasses import dataclass

import settings
from combat.attacks import COMBOS

# Пока атака цепочки ещё выполняется, окно закрыто и тайм-аута нет:
# окно открывается только когда атака переходит в восстановление.
_NEVER = float("inf")


@dataclass(frozen=True)
class ComboStep:
    index: int            # номер шага в цепочке (с нуля)
    continued: bool       # продолжает ли ввод цепочку
    finished: object      # ComboDefinition, если это завершающая атака, иначе None


class ComboTracker:
    def __init__(self, combos=COMBOS):
        self.combos = tuple(combos)
        self.history = []
        self._open_from = _NEVER
        self._deadline = _NEVER

    def reset(self):
        self.history = []
        self._open_from = _NEVER
        self._deadline = _NEVER

    def update(self, now):
        """Тайм-аут: цепочка сбрасывается, когда окно комбо закрылось."""
        if self.history and now > self._deadline:
            self.reset()

    def open_window(self, now, recovery):
        """Вызывается, когда атака цепочки переходит в восстановление."""
        self._open_from = now + settings.COMBO_CANCEL_FRACTION * recovery
        self._deadline = now + recovery + settings.COMBO_WINDOW_AFTER

    def window_open(self, now):
        return bool(self.history) and self._open_from <= now <= self._deadline

    def next_gestures(self):
        n = len(self.history)
        prefix = tuple(self.history)
        return {c.steps[n] for c in self.combos
                if len(c.steps) > n and c.steps[:n] == prefix}

    def can_continue(self, gesture, now):
        return self.window_open(now) and gesture in self.next_gestures()

    def register(self, gesture, now):
        """Фиксирует выполняемую атаку и возвращает ComboStep."""
        self.update(now)
        continued = self.can_continue(gesture, now)
        if continued:
            self.history.append(gesture)
        elif any(c.steps[0] == gesture for c in self.combos):
            self.history = [gesture]
        else:
            self.history = []
        self._open_from = _NEVER      # новая атака: окно закрыто до её восстановления
        self._deadline = _NEVER
        finished = next((c for c in self.combos if tuple(self.history) == c.steps), None)
        step = ComboStep(max(len(self.history) - 1, 0), continued, finished)
        if finished is not None:
            self.reset()
        return step


def validate_combos(combos, attacks):
    """Проверка конфигурации: возвращает список проблем (пустой - всё хорошо)."""
    problems = []
    seen = set()
    for c in combos:
        if len(c.steps) < 2:
            problems.append("%s: комбо короче двух шагов" % c.name)
        for step in c.steps:
            if step not in attacks:
                problems.append("%s: неизвестная атака %r" % (c.name, step))
        if c.steps in seen:
            problems.append("%s: повторяет другое комбо" % c.name)
        seen.add(c.steps)
    for a in combos:
        for b in combos:
            if a is not b and b.steps[:len(a.steps)] == a.steps:
                problems.append("%s является началом %s" % (a.name, b.name))
    return problems
