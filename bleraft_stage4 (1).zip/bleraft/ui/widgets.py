"""Кнопки и меню с управлением мышью и клавиатурой."""

from ui import theme


class Button:
    def __init__(self, label, rect, action, enabled=True):
        self.label = label
        self.rect = rect            # (x, y, w, h)
        self.action = action        # функция без аргументов
        self.enabled = enabled

    def contains(self, pos):
        x, y, w, h = self.rect
        return x <= pos[0] < x + w and y <= pos[1] < y + h


class Menu:
    def __init__(self, pygame, buttons, on_activate=None, horizontal=False):
        self.pg = pygame
        self.buttons = buttons
        self.selected = 0
        self.pressed = None
        self.on_activate = on_activate      # например, звук клика
        self.horizontal = horizontal

    def _hit(self, pos):
        for i, b in enumerate(self.buttons):
            if b.contains(pos):
                return i
        return None

    def move(self, step):
        n = len(self.buttons)
        for _ in range(n):
            self.selected = (self.selected + step) % n
            if self.buttons[self.selected].enabled:
                return

    def activate(self, index):
        button = self.buttons[index]
        if not button.enabled:
            return
        if self.on_activate is not None:
            self.on_activate(button)
        button.action()

    def handle_event(self, event):
        pg = self.pg
        kind = event.type
        if kind == pg.KEYDOWN:
            prev = (pg.K_LEFT, pg.K_a) if self.horizontal else (pg.K_UP, pg.K_w)
            nxt = (pg.K_RIGHT, pg.K_d) if self.horizontal else (pg.K_DOWN, pg.K_s)
            if event.key in prev:
                self.move(-1)
                return True
            if event.key in nxt:
                self.move(1)
                return True
            if event.key in (pg.K_RETURN, pg.K_KP_ENTER, pg.K_SPACE):
                self.activate(self.selected)
                return True
        elif kind == pg.MOUSEMOTION:
            i = self._hit(event.pos)
            if i is not None and self.buttons[i].enabled:
                self.selected = i
        elif kind == pg.MOUSEBUTTONDOWN and event.button == 1:
            i = self._hit(event.pos)
            if i is not None and self.buttons[i].enabled:
                self.pressed = self.selected = i
                return True
        elif kind == pg.MOUSEBUTTONUP and event.button == 1:
            i = self._hit(event.pos)
            pressed, self.pressed = self.pressed, None
            if pressed is not None and i == pressed:
                self.activate(i)
                return True
        return False

    def draw(self, surface, font, t):
        for i, b in enumerate(self.buttons):
            theme.draw_button(self.pg, font, surface, b, i == self.selected,
                              self.pressed == i, t)
