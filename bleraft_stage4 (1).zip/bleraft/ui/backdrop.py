"""Фон меню: тёмная арена с бойцами и поднимающимися искрами.

Статичная часть строится один раз; каждый кадр рисуются только бойцы и искры.
"""

import math

import settings
from ui import palette, sprites


class Backdrop:
    def __init__(self, pygame):
        self._pg = pygame
        self._bg = None
        self._fighters = {}

    def _build(self):
        pg = self._pg
        w, h = settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT
        bg = pg.Surface((w, h))
        for y in range(0, h, 8):                         # вертикальный градиент полосами
            k = y / h
            color = (int(10 + 14 * k), int(12 + 16 * k), int(24 + 30 * k))
            bg.fill(color, (0, y, w, 8))
        ax, ay = (w - settings.ARENA_WIDTH) // 2, (h - settings.ARENA_HEIGHT) // 2 + 20
        tile = settings.ARENA_TILE_SIZE * 2
        for r in range(settings.ARENA_HEIGHT // tile):
            for c in range(settings.ARENA_WIDTH // tile):
                color = (30, 36, 54) if (r + c) % 2 == 0 else (26, 31, 47)
                bg.fill(color, (ax + c * tile, ay + r * tile, tile, tile))
        pg.draw.rect(bg, palette.RIM_DARK, (ax - 5, ay - 5, settings.ARENA_WIDTH + 10,
                                            settings.ARENA_HEIGHT + 10), 5)
        pg.draw.rect(bg, (70, 82, 120), (ax - 3, ay - 3, settings.ARENA_WIDTH + 6,
                                         settings.ARENA_HEIGHT + 6), 2)
        veil = pg.Surface((w, h), pg.SRCALPHA)          # затемнение к краям (один раз)
        for i in range(10):
            alpha = 150 - i * 13
            veil.fill((0, 0, 0, alpha), (0, i * 12, w, 12))
            veil.fill((0, 0, 0, alpha), (0, h - (i + 1) * 12, w, 12))
            veil.fill((0, 0, 0, alpha), (i * 20, 0, 20, h))
            veil.fill((0, 0, 0, alpha), (w - (i + 1) * 20, 0, 20, h))
        veil.fill((0, 0, 0, 90), (0, 0, w, h))
        bg.blit(veil, (0, 0))
        self._bg = bg
        for team in ("blue", "red"):
            self._fighters[team] = sprites.build_fighter_sprite(pg, team, 7)

    def draw(self, surface, t):
        if self._bg is None:
            self._build()
        pg = self._pg
        surface.blit(self._bg, (0, 0))
        bob = int(4 * math.sin(t * 2.2))
        size = 12 * 7
        surface.blit(self._fighters["blue"], (150, 400 + bob))
        surface.blit(self._fighters["red"], (settings.WINDOW_WIDTH - 150 - size, 400 - bob))
        for i in range(18):                              # искры: детерминированные, без random
            x = (i * 137) % settings.WINDOW_WIDTH
            y = settings.WINDOW_HEIGHT - int((t * (22 + i % 5 * 9) + i * 53) % settings.WINDOW_HEIGHT)
            drift = int(10 * math.sin(t + i))
            color = (120, 160, 255) if i % 2 else (255, 150, 120)
            pg.draw.rect(surface, color, (x + drift, y, 3, 3))
