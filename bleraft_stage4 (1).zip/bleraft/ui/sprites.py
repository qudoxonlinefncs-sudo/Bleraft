"""Пиксельный спрайт бойца: данные и сборка поверхности."""

from ui import palette

# 12x12, '.' - прозрачный пиксель; остальные символы - ключи палитры команды
FIGHTER_GRID = (
    "...OOOOOO...",
    "..OMMMMMMO..",
    ".OMLLMMMMMO.",
    ".OMMSSSSMMO.",
    ".OMMSSSSMMO.",
    "..OMMMMMMO..",
    ".OOMDDDDMOO.",
    "OMMMDMMDMMMO",
    "OMMOMMMMOMMO",
    ".OO.OMMO.OO.",
    "...OMMMMO...",
    "...OOOOOO...",
)

GRID_SIZE = len(FIGHTER_GRID)


def build_fighter_sprite(pygame, team, scale):
    """Собирает спрайт команды и увеличивает его без сглаживания."""
    colors = palette.TEAM_PALETTES[team]
    small = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
    for y, row in enumerate(FIGHTER_GRID):
        for x, symbol in enumerate(row):
            if symbol != ".":
                small.set_at((x, y), colors[symbol])
    return pygame.transform.scale(small, (GRID_SIZE * scale, GRID_SIZE * scale))
