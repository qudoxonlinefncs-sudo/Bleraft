"""Общие элементы оформления интерфейса: панели, кнопки, ползунок."""

import math

from ui import palette


def panel(pg, surface, rect, fill=None, border=None, shadow=True):
    x, y, w, h = rect
    fill = fill or palette.UI_PANEL
    border = border or palette.HP_BORDER
    if shadow:
        pg.draw.rect(surface, (6, 8, 14), (x + 6, y + 6, w, h))
    pg.draw.rect(surface, fill, rect)
    pg.draw.rect(surface, palette.UI_PANEL_LIGHT, (x + 2, y + 2, w - 4, 3))
    pg.draw.rect(surface, border, rect, 2)
    for cx, cy in ((x, y), (x + w - 6, y), (x, y + h - 6), (x + w - 6, y + h - 6)):
        pg.draw.rect(surface, border, (cx, cy, 6, 6))      # пиксельные "заклёпки" по углам


def draw_button(pg, font, surface, button, selected, pressed, t):
    x, y, w, h = button.rect
    off = 3 if pressed else 0
    if not button.enabled:
        fill, border, text_color = palette.UI_PANEL, palette.UI_PANEL_LIGHT, palette.UI_DIM
    elif selected:
        fill, border, text_color = palette.UI_PANEL_LIGHT, palette.UI_ACCENT, palette.UI_GOLD
    else:
        fill, border, text_color = palette.UI_PANEL, palette.HP_BORDER, palette.UI_TEXT
    if not pressed:
        pg.draw.rect(surface, (6, 8, 14), (x + 5, y + 5, w, h))
    pg.draw.rect(surface, fill, (x + off, y + off, w, h))
    pg.draw.rect(surface, palette.UI_PANEL_LIGHT if not selected else palette.UI_ACCENT,
                 (x + off + 2, y + off + 2, w - 4, 2))
    pg.draw.rect(surface, border, (x + off, y + off, w, h), 2)
    stripe = palette.UI_GOLD if selected else palette.UI_ACCENT
    pg.draw.rect(surface, stripe, (x + off + 6, y + off + 8, 6, h - 16))      # акцентная полоса
    font.draw(surface, button.label, x + off + w // 2, y + off + h // 2, 3,
              text_color, palette.RIM_DARK, "center")
    if selected:
        bob = int(3 * math.sin(t * 8))
        font.draw(surface, ">", x + off + w - 30 + bob, y + off + h // 2, 3, palette.UI_GOLD, None, "center")
        font.draw(surface, "<", x + off + 24 - bob + 18, y + off + h // 2, 3, palette.UI_GOLD, None, "center")


def draw_slider(pg, surface, rect, fraction, selected):
    x, y, w, h = rect
    pg.draw.rect(surface, palette.HP_BACK, rect)
    pg.draw.rect(surface, palette.UI_ACCENT if selected else palette.HP_BORDER, rect, 2)
    filled = int((w - 6) * max(0.0, min(1.0, fraction)))
    if filled > 0:
        pg.draw.rect(surface, palette.UI_GOLD if selected else palette.UI_ACCENT,
                     (x + 3, y + 3, filled, h - 6))
