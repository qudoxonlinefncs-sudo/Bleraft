"""Экраны игры: главное меню, лобби, статистика, настройки, матч."""

import math

import settings
from ai.difficulty import DIFFICULTIES, DIFFICULTY_ORDER
from core.flow import Phase
from core.match_rules import KO, RING_OUT, TIMEOUT, VICTORY
from core.match_setup import MODE_MATCH, MODE_TRAINING, build_scene, time_limit_for
from core.states import State
from ui import palette, sprites, theme
from ui.match_hud import MatchHud, format_time
from ui.widgets import Button, Menu

W, H = settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT
BTN_W, BTN_H = 380, 56
REASONS = {KO: "НОКАУТ", RING_OUT: "РИНГ АУТ", TIMEOUT: "ПО ВРЕМЕНИ"}


class Screen(State):
    phase = None

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.flow = None
        self.t = 0.0

    def update(self, dt):
        self.t += dt

    def _click(self, _button=None):
        self.ctx.sound.play("click")

    def _is_key(self, event, *names):
        pg = self.ctx.pygame
        return event.type == pg.KEYDOWN and event.key in [getattr(pg, n) for n in names]


# ---------------------------------------------------------------- главное меню

class MainMenuScreen(Screen):
    phase = Phase.MAIN_MENU

    def __init__(self, ctx):
        super().__init__(ctx)
        x = (W - BTN_W) // 2
        items = [
            ("ИГРАТЬ", lambda: self.flow.go("lobby", mode=MODE_MATCH)),
            ("ТРЕНИРОВКА", lambda: self.flow.go("lobby", mode=MODE_TRAINING)),
            ("СТАТИСТИКА", lambda: self.flow.go("stats")),
            ("НАСТРОЙКИ", lambda: self.flow.go("settings")),
            ("ВЫХОД", lambda: self.flow.quit()),
        ]
        buttons = [Button(label, (x, 250 + i * 72, BTN_W, BTN_H), action)
                   for i, (label, action) in enumerate(items)]
        self.menu = Menu(ctx.pygame, buttons, self._click)

    def handle_event(self, event):
        self.menu.handle_event(event)

    def draw(self, surface, alpha):
        font = self.ctx.font
        self.ctx.backdrop.draw(surface, self.t)
        font.draw(surface, "BLERAFT", W // 2, 70, 12, palette.UI_GOLD, palette.RIM_DARK, "midtop")
        font.draw(surface, "GESTURE COMBAT", W // 2, 176, 3, palette.UI_ACCENT, palette.RIM_DARK, "midtop")
        self.menu.draw(surface, font, self.t)
        font.draw(surface, "W/S ИЛИ МЫШЬ  ENTER - ВЫБОР", W // 2, H - 34, 2, palette.UI_DIM, None, "midtop")


# ---------------------------------------------------------------- лобби

class LobbyScreen(Screen):
    phase = Phase.LOBBY

    def __init__(self, ctx, mode=MODE_MATCH):
        super().__init__(ctx)
        self.mode = mode
        self.difficulty = ctx.profile.difficulty
        if self.difficulty not in DIFFICULTIES:
            self.difficulty = "normal"
        x = (W - BTN_W) // 2
        self.fight = Button("В БОЙ", (x, 512, BTN_W, 52), self.start)
        self.diff_button = Button(self._diff_label(), (x, 574, BTN_W, 52), lambda: self.cycle(1))
        self.back = Button("НАЗАД", (x, 636, BTN_W, 52), lambda: self.flow.go("main_menu"))
        self.menu = Menu(ctx.pygame, [self.fight, self.diff_button, self.back], self._click)
        self.sprites = {t: sprites.build_fighter_sprite(ctx.pygame, t, 8) for t in ("blue", "red")}

    def _diff_label(self):
        return "< %s >" % DIFFICULTIES[self.difficulty].label

    def cycle(self, step):
        i = (DIFFICULTY_ORDER.index(self.difficulty) + step) % len(DIFFICULTY_ORDER)
        self.difficulty = DIFFICULTY_ORDER[i]
        self.diff_button.label = self._diff_label()
        self.ctx.profile.set_difficulty(self.difficulty)
        self.ctx.profile.save_settings()

    def start(self):
        self.flow.go("match", mode=self.mode, difficulty=self.difficulty)

    def handle_event(self, event):
        pg = self.ctx.pygame
        if self._is_key(event, "K_ESCAPE"):
            self.flow.go("main_menu")
            return
        if self.menu.selected == 1 and self._is_key(event, "K_LEFT", "K_a"):
            self.cycle(-1)
            self._click()
            return
        if self.menu.selected == 1 and self._is_key(event, "K_RIGHT", "K_d"):
            self.cycle(1)
            self._click()
            return
        self.menu.handle_event(event)

    def draw(self, surface, alpha):
        font = self.ctx.font
        self.ctx.backdrop.draw(surface, self.t)
        font.draw(surface, "ЛОББИ", W // 2, 28, 7, palette.UI_GOLD, palette.RIM_DARK, "midtop")
        for x, team, name, lines in (
                (110, "blue", "ИГРОК", ("МЫШЬ - ЖЕСТЫ", "WASD - ХОД")),
                (W - 110 - 360, "red", "БОТ", (DIFFICULTIES[self.difficulty].label,
                                               "ТЕ ЖЕ ПРАВИЛА"))):
            theme.panel(self.ctx.pygame, surface, (x, 120, 360, 330))
            color = palette.HP_FILL[team]
            font.draw(surface, name, x + 180, 140, 4, color, palette.RIM_DARK, "midtop")
            bob = int(3 * math.sin(self.t * 2 + (0 if team == "blue" else 1.5)))
            surface.blit(self.sprites[team], (x + 180 - 48, 200 + bob))
            for i, line in enumerate(lines):
                font.draw(surface, line, x + 180, 330 + i * 34, 2, palette.UI_TEXT, None, "midtop")
        font.draw(surface, "VS", W // 2, 260, 9, palette.UI_TEXT, palette.RIM_DARK, "midtop")
        if self.mode == MODE_MATCH:
            info = "МАТЧ %s  КРАЙ АРЕНЫ РАЗРУШАЕТСЯ КАЖДЫЕ %d С" % (
                format_time(settings.MATCH_DURATION), settings.COLLAPSE_INTERVAL)
        else:
            info = "ТРЕНИРОВКА  БЕЗ ВРЕМЕНИ И ОБРУШЕНИЯ АРЕНЫ"
        font.draw(surface, info, W // 2, 470, 2, palette.UI_ACCENT, palette.RIM_DARK, "midtop")
        font.draw(surface, "ЖЕСТЫ:  /   -   |   V", W // 2, 492, 2, palette.UI_DIM, None, "midtop")
        self.menu.draw(surface, font, self.t)


# ---------------------------------------------------------------- статистика

class StatsScreen(Screen):
    phase = Phase.STATS

    def __init__(self, ctx):
        super().__init__(ctx)
        self.summary = ctx.profile.summary()
        x = (W - BTN_W) // 2
        self.menu = Menu(ctx.pygame, [Button("НАЗАД", (x, 640, BTN_W, 52),
                                             lambda: self.flow.go("main_menu"))], self._click)

    def handle_event(self, event):
        if self._is_key(event, "K_ESCAPE"):
            self.flow.go("main_menu")
            return
        self.menu.handle_event(event)

    def draw(self, surface, alpha):
        font, s = self.ctx.font, self.summary
        self.ctx.backdrop.draw(surface, self.t)
        font.draw(surface, "СТАТИСТИКА", W // 2, 28, 7, palette.UI_GOLD, palette.RIM_DARK, "midtop")
        theme.panel(self.ctx.pygame, surface, (150, 110, W - 300, 510))
        if s["played"] == 0 and s["training"] == 0:
            font.draw(surface, "ПОКА НЕТ СЫГРАННЫХ МАТЧЕЙ", W // 2, 340, 3, palette.UI_DIM, None, "center")
        else:
            rows = (
                ("МАТЧЕЙ СЫГРАНО", s["played"]), ("ПОБЕДЫ", s["wins"]),
                ("ПОРАЖЕНИЯ", s["losses"]), ("ПРОЦЕНТ ПОБЕД", "%d%%" % s["winrate"]),
                ("ЛУЧШАЯ СЕРИЯ", s["best_combo"]), ("УРОН НАНЕСЁН", s["damage_dealt"]),
                ("УРОН ПОЛУЧЕН", s["damage_taken"]), ("РИНГ АУТ: ПОБЕД", s["ring_out_wins"]),
                ("РИНГ АУТ: ПОРАЖЕНИЙ", s["ring_out_losses"]),
                ("СРЕДНЕЕ ВРЕМЯ", format_time(s["avg_duration"])),
                ("ТРЕНИРОВОК", s["training"]),
            )
            for i, (label, value) in enumerate(rows):
                y = 140 + i * 30
                font.draw(surface, label, 190, y, 2, palette.UI_DIM)
                font.draw(surface, str(value), 560, y, 2, palette.UI_TEXT, None, "topright")
            font.draw(surface, "ПОСЛЕДНИЕ МАТЧИ", 640, 140, 2, palette.UI_ACCENT)
            for i, m in enumerate(s["recent"]):
                y = 176 + i * 34
                won = m["outcome"] == VICTORY
                font.draw(surface, "ПОБЕДА" if won else "ПОРАЖЕНИЕ", 640, y, 2,
                          palette.UI_GREEN if won else palette.UI_RED)
                diff = DIFFICULTIES.get(m.get("difficulty"), DIFFICULTIES["normal"]).label
                tag = "ТРЕН" if m.get("mode") == MODE_TRAINING else format_time(m["duration"])
                font.draw(surface, "%s  %s" % (tag, diff), 820, y, 2, palette.UI_TEXT)
        self.menu.draw(surface, font, self.t)


# ---------------------------------------------------------------- настройки

CONTROL_LABELS = (("p1_up", "ИГРОК 1 ВВЕРХ"), ("p1_down", "ИГРОК 1 ВНИЗ"),
                  ("p1_left", "ИГРОК 1 ВЛЕВО"), ("p1_right", "ИГРОК 1 ВПРАВО"),
                  ("p2_up", "ИГРОК 2 ВВЕРХ"), ("p2_down", "ИГРОК 2 ВНИЗ"),
                  ("p2_left", "ИГРОК 2 ВЛЕВО"), ("p2_right", "ИГРОК 2 ВПРАВО"))
ROW_H = 46
ROW_Y0 = 112
SLIDER = (760, 0, 300, 22)


class SettingsScreen(Screen):
    phase = Phase.SETTINGS

    def __init__(self, ctx):
        super().__init__(ctx)
        self.profile = ctx.profile
        # строки: ("sound",) ("volume",) ("key", action) ("reset",) ("back",)
        self.rows = [("sound",), ("volume",)] + [("key", a) for a, _ in CONTROL_LABELS] + [
            ("reset",), ("back",)]
        self.selected = 0
        self.capturing = None          # действие, для которого ждём клавишу

    # --- логика ---

    def _row_rect(self, i):
        return (150, ROW_Y0 + i * ROW_H, W - 300, ROW_H - 6)

    def _row_at(self, pos):
        for i in range(len(self.rows)):
            x, y, w, h = self._row_rect(i)
            if x <= pos[0] < x + w and y <= pos[1] < y + h:
                return i
        return None

    def _volume_from_x(self, x):
        sx, _, sw, _ = SLIDER
        return min(1.0, max(0.0, (x - sx) / sw))

    def _activate(self, i):
        kind = self.rows[i]
        self.ctx.sound.play("click")
        if kind[0] == "sound":
            self.profile.settings["sound_on"] = not self.profile.sound_on
        elif kind[0] == "key":
            self.capturing = kind[1]
        elif kind[0] == "reset":
            self.profile.reset_bindings()
        elif kind[0] == "back":
            self.profile.save_settings()
            self.flow.go("main_menu")
            return
        self.profile.save_settings()

    def _nudge(self, i, step):
        kind = self.rows[i]
        if kind[0] == "volume":
            self.profile.set_volume(round(self.profile.volume + 0.1 * step, 2))
            self.profile.save_settings()
            self.ctx.sound.play("click")
        elif kind[0] == "sound":
            self.profile.settings["sound_on"] = step > 0
            self.profile.save_settings()

    def handle_event(self, event):
        pg = self.ctx.pygame
        if self.capturing is not None:                     # ждём новую клавишу
            if event.type == pg.KEYDOWN:
                if event.key != pg.K_ESCAPE:
                    self.profile.set_binding(pg, self.capturing, event.key)
                    self.profile.save_settings()
                self.capturing = None
            return
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_ESCAPE:
                self.profile.save_settings()
                self.flow.go("main_menu")
            elif event.key in (pg.K_UP, pg.K_w):
                self.selected = (self.selected - 1) % len(self.rows)
            elif event.key in (pg.K_DOWN, pg.K_s):
                self.selected = (self.selected + 1) % len(self.rows)
            elif event.key in (pg.K_LEFT, pg.K_a):
                self._nudge(self.selected, -1)
            elif event.key in (pg.K_RIGHT, pg.K_d):
                self._nudge(self.selected, 1)
            elif event.key in (pg.K_RETURN, pg.K_KP_ENTER, pg.K_SPACE):
                self._activate(self.selected)
        elif event.type == pg.MOUSEMOTION:
            i = self._row_at(event.pos)
            if i is not None:
                self.selected = i
            if self.rows[self.selected][0] == "volume" and event.buttons[0]:
                self.profile.set_volume(self._volume_from_x(event.pos[0]))
        elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            i = self._row_at(event.pos)
            if i is None:
                return
            self.selected = i
            if self.rows[i][0] == "volume":
                self.profile.set_volume(self._volume_from_x(event.pos[0]))
                self.profile.save_settings()
            else:
                self._activate(i)

    # --- отрисовка ---

    def _key_name(self, action):
        code = self.profile.bindings(self.ctx.pygame)[action]
        try:
            return self.ctx.pygame.key.name(code).upper()
        except Exception:
            return str(code)

    def draw(self, surface, alpha):
        pg, font = self.ctx.pygame, self.ctx.font
        self.ctx.backdrop.draw(surface, self.t)
        font.draw(surface, "НАСТРОЙКИ", W // 2, 24, 7, palette.UI_GOLD, palette.RIM_DARK, "midtop")
        theme.panel(pg, surface, (130, ROW_Y0 - 14, W - 260, ROW_H * len(self.rows) + 16))
        labels = dict(CONTROL_LABELS)
        for i, row in enumerate(self.rows):
            x, y, w, h = self._row_rect(i)
            sel = i == self.selected
            if sel:
                pg.draw.rect(surface, palette.UI_PANEL_LIGHT, (x, y, w, h))
                pg.draw.rect(surface, palette.UI_ACCENT, (x, y, w, h), 2)
            color = palette.UI_GOLD if sel else palette.UI_TEXT
            ty = y + h // 2
            kind = row[0]
            if kind == "sound":
                font.draw(surface, "ЗВУК", x + 20, ty - 7, 2, color)
                on = self.profile.sound_on
                font.draw(surface, "ВКЛ" if on else "ВЫКЛ", x + w - 20, ty - 7, 2,
                          palette.UI_GREEN if on else palette.UI_RED, None, "topright")
            elif kind == "volume":
                font.draw(surface, "ГРОМКОСТЬ", x + 20, ty - 7, 2, color)
                rect = (SLIDER[0], y + 8, SLIDER[2], SLIDER[3])
                theme.draw_slider(pg, surface, rect, self.profile.volume, sel)
                font.draw(surface, "%d%%" % round(self.profile.volume * 100), x + w - 20, ty - 7,
                          2, palette.UI_TEXT, None, "topright")
            elif kind == "key":
                font.draw(surface, labels[row[1]], x + 20, ty - 7, 2, color)
                waiting = self.capturing == row[1]
                font.draw(surface, "НАЖМИТЕ КЛАВИШУ..." if waiting else self._key_name(row[1]),
                          x + w - 20, ty - 7, 2, palette.UI_ORANGE if waiting else palette.UI_ACCENT,
                          None, "topright")
            elif kind == "reset":
                font.draw(surface, "СБРОСИТЬ КЛАВИШИ", x + 20, ty - 7, 2, color)
            else:
                font.draw(surface, "НАЗАД", x + w // 2, ty - 7, 2, color, None, "midtop")
        font.draw(surface, "ENTER - ВЫБОР  ВЛЕВО/ВПРАВО - ЗНАЧЕНИЕ  ESC - НАЗАД", W // 2, H - 26, 2,
                  palette.UI_DIM, None, "midtop")


# ---------------------------------------------------------------- матч

class MatchScreen(Screen):
    """Матч: MATCH_START -> FIGHT -> VICTORY / DEFEAT (+ пауза по Esc)."""

    RESULT_INPUT_DELAY = 0.6

    def __init__(self, ctx, mode=MODE_MATCH, difficulty="normal", seed=None):
        super().__init__(ctx)
        self.mode = mode
        self.difficulty = difficulty
        self.seed = seed
        self.scene = build_scene(ctx, mode, difficulty, seed)
        self.hud = MatchHud(ctx.pygame, ctx.font)
        self.phase = Phase.MATCH_START
        self.countdown = settings.MATCH_COUNTDOWN + settings.MATCH_GO_TIME
        self.paused = False
        self.result_time = 0.0
        self.record = None
        x = (W - BTN_W) // 2
        self.result_menu = Menu(ctx.pygame, [
            Button("РЕВАНШ", (W // 2 - 250, 540, 240, 56), self.rematch),
            Button("В ЛОББИ", (W // 2 + 10, 540, 240, 56), self.to_lobby),
        ], self._click, horizontal=True)
        self.pause_menu = Menu(ctx.pygame, [
            Button("ПРОДОЛЖИТЬ", (x, 290, BTN_W, 56), self.resume),
            Button("В ЛОББИ", (x, 362, BTN_W, 56), self.to_lobby),
        ], self._click)

    # --- действия ---

    def rematch(self):
        self.flow.go("match", mode=self.mode, difficulty=self.difficulty)

    def to_lobby(self):
        self.flow.go("lobby", mode=self.mode)

    def resume(self):
        self.paused = False

    @property
    def finished(self):
        return self.phase in (Phase.VICTORY, Phase.DEFEAT)

    # --- события и логика ---

    def handle_event(self, event):
        pg = self.ctx.pygame
        if self.finished:
            if self.result_time >= self.RESULT_INPUT_DELAY:
                self.result_menu.handle_event(event)
            return
        if self.paused:
            if self._is_key(event, "K_ESCAPE"):
                self.resume()
            else:
                self.pause_menu.handle_event(event)
            return
        if self._is_key(event, "K_ESCAPE") and self.phase is Phase.FIGHT:
            self.paused = True
            self.scene.command_input.recorder.cancel()
            return
        if self.phase is Phase.FIGHT:
            self.scene.handle_event(event)

    def update(self, dt):
        self.t += dt
        if self.phase is Phase.MATCH_START:
            self.countdown -= dt
            if self.countdown <= 0:
                self.phase = Phase.FIGHT
        elif self.phase is Phase.FIGHT:
            if not self.paused:
                self.scene.update(dt)
                for name in self.scene.sound_events:
                    self.ctx.sound.play(name)
                self.scene.sound_events = []
                if self.scene.result is not None:
                    self._finish()
        else:
            self.result_time += dt
            self.scene.update(dt)        # результат уже есть: движутся только эффекты

    def _finish(self):
        result = self.scene.result
        self.phase = Phase.VICTORY if result.outcome == VICTORY else Phase.DEFEAT
        self.result_time = 0.0
        self.record = self.ctx.profile.record_match(result, self.mode, self.difficulty)
        self.ctx.sound.play("win" if self.phase is Phase.VICTORY else "lose")

    # --- отрисовка ---

    def draw(self, surface, alpha):
        self.scene.draw(surface, alpha)
        self.hud.draw(surface, self.scene, time_limit_for(self.mode))
        if self.phase is Phase.MATCH_START:
            self._draw_countdown(surface)
        elif self.paused:
            self._draw_pause(surface)
        elif self.finished:
            self._draw_result(surface)

    def _draw_countdown(self, surface):
        font = self.ctx.font
        if self.countdown > settings.MATCH_GO_TIME:
            n = int(math.ceil(self.countdown - settings.MATCH_GO_TIME))
            frac = (self.countdown - settings.MATCH_GO_TIME) % 1.0 or 1.0
            text, scale, color = str(n), 14 + int(6 * frac), palette.UI_TEXT
        else:
            text, scale, color = "БОЙ!", 14, palette.UI_GOLD
        font.draw(surface, text, W // 2, 330, scale, color, palette.RIM_DARK, "center")
        font.draw(surface, "РИСУЙ ЖЕСТЫ МЫШЬЮ:  /   -   |   V", W // 2, 440, 2, palette.UI_TEXT,
                  palette.RIM_DARK, "midtop")

    def _draw_pause(self, surface):
        font, pg = self.ctx.font, self.ctx.pygame
        theme.panel(pg, surface, (W // 2 - 230, 200, 460, 250))
        font.draw(surface, "ПАУЗА", W // 2, 220, 6, palette.UI_GOLD, palette.RIM_DARK, "midtop")
        self.pause_menu.draw(surface, font, self.t)

    def _draw_result(self, surface):
        font, pg = self.ctx.font, self.ctx.pygame
        won = self.phase is Phase.VICTORY
        r = self.scene.result
        slide = min(1.0, self.result_time / 0.4)
        bar = int(70 * slide)                                  # чёрные полосы сверху и снизу
        pg.draw.rect(surface, (0, 0, 0), (0, 0, W, bar))
        pg.draw.rect(surface, (0, 0, 0), (0, H - bar, W, bar))
        top = int(110 - (1.0 - slide) * 400)
        theme.panel(pg, surface, (W // 2 - 380, top, 760, 520),
                    border=palette.UI_GOLD if won else palette.UI_RED)
        pulse = 11 if int(self.result_time * 3) % 2 == 0 else 10
        title = "ПОБЕДА!" if won else "ПОРАЖЕНИЕ"
        font.draw(surface, title, W // 2, top + 24, pulse if won else 9,
                  palette.UI_GOLD if won else palette.UI_RED, palette.RIM_DARK, "midtop")
        font.draw(surface, REASONS.get(r.reason, ""), W // 2, top + 130, 3,
                  palette.UI_TEXT, palette.RIM_DARK, "midtop")
        st = r.stats
        rows = (("ВРЕМЯ", format_time(r.duration)),
                ("УРОН НАНЕСЁН", int(st.get("damage_dealt", 0))),
                ("УРОН ПОЛУЧЕН", int(st.get("damage_taken", 0))),
                ("ПОПАДАНИЙ", "%d / %d" % (st.get("hits_landed", 0), st.get("hits_taken", 0))),
                ("МАКС. СЕРИЯ", st.get("max_combo", 0)),
                ("ЖЕСТОВ ВЕРНО", "%d / %d" % (st.get("gestures_ok", 0),
                                              st.get("gestures_ok", 0) + st.get("gestures_failed", 0))))
        for i, (label, value) in enumerate(rows):
            y = top + 190 + i * 40
            font.draw(surface, label, W // 2 - 280, y, 3, palette.UI_DIM)
            font.draw(surface, str(value), W // 2 + 280, y, 3, palette.UI_TEXT, None, "topright")
        if self.result_time >= self.RESULT_INPUT_DELAY:
            self.result_menu.draw(surface, font, self.t)
