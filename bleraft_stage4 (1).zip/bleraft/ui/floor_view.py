"""Отрисовка пола арены: плитки, трещины, предупреждение, падение, граница-стена.

Слой с плитками строится один раз на каждое изменение пола (floor.version) и
кэшируется. Каждый кадр рисуются только мигающая рамка предупреждения,
падающие плитки (несколько десятков простых прямоугольников) и граница.
"""

from arena.floor import CRACKED, INTACT
from ui import palette

STAGGER = 0.035       # задержка падения соседних плиток (красивая "волна")


def _crack_lines(r, c, tile):
    """Детерминированный рисунок трещин плитки (без случайности)."""
    k = (r * 7 + c * 13) % 4
    t = tile
    patterns = (
        ((2, t // 2, t // 2, t // 3), (t // 2, t // 3, t - 3, t // 2 + 4)),
        ((t // 3, 2, t // 2, t // 2), (t // 2, t // 2, t - 4, t - 3)),
        ((2, t - 4, t // 2, t // 2), (t // 2, t // 2, t - 3, 4)),
        ((t // 2, 2, t // 2 + 3, t // 2), (t // 2 + 3, t // 2, 3, t - 3)),
    )
    return patterns[k]


class FloorView:
    def __init__(self, pygame):
        self._pg = pygame
        self._layer = None
        self._key = None

    def _build_layer(self, floor):
        pg, tile = self._pg, floor.tile
        layer = pg.Surface((floor.arena.width, floor.arena.height), pg.SRCALPHA)
        for r in range(floor.rows):
            for c in range(floor.cols):
                st = floor.state[r][c]
                if st not in (INTACT, CRACKED):
                    continue
                color = palette.FLOOR_A if (r + c) % 2 == 0 else palette.FLOOR_B
                layer.fill(color, (c * tile, r * tile, tile, tile))
                if st == CRACKED:
                    for x0, y0, x1, y1 in _crack_lines(r, c, tile):
                        pg.draw.line(layer, palette.CRACK, (c * tile + x0, r * tile + y0),
                                     (c * tile + x1, r * tile + y1), 2)
        return layer

    def draw(self, surface, floor):
        pg, a, tile = self._pg, floor.arena, floor.tile
        key = (id(floor), floor.version)
        if key != self._key:
            self._layer = self._build_layer(floor)
            self._key = key
        surface.blit(self._layer, (int(a.left), int(a.top)))

        if floor.warning_active:      # мигающая рамка по кольцу, которое скоро упадёт
            color = palette.WARN_A if int(floor.time * 4) % 2 == 0 else palette.WARN_B
            l, t, r, b = floor.safe_bounds
            pg.draw.rect(surface, color, (l, t, r - l, b - t), 3)
            pg.draw.rect(surface, color, (l + tile, t + tile, r - l - 2 * tile, b - t - 2 * tile), 1)

        for (row, col), start in floor.fall_started.items():
            p = (floor.time - start - ((row + col) % 8) * STAGGER) / floor.fall_time
            p = max(0.0, min(1.0, p))
            size = max(2, int(tile * (1.0 - 0.65 * p)))
            off = (tile - size) // 2
            drop = int(70 * p * p)
            x = int(a.left) + col * tile + off
            y = int(a.top) + row * tile + off + drop
            color = palette.TILE_FALL if p > 0.5 else palette.FLOOR_A
            pg.draw.rect(surface, color, (x, y, size, size))

        self._draw_rim(surface, floor.safe_bounds)

    def _draw_rim(self, surface, bounds):
        """Граница безопасной зоны: невысокая стена. Её можно только перелететь отбрасыванием."""
        pg = self._pg
        l, t, r, b = (int(v) for v in bounds)
        pg.draw.rect(surface, palette.RIM_DARK, (l - 5, t - 5, r - l + 10, b - t + 10), 5)
        pg.draw.rect(surface, palette.RIM_LIGHT, (l - 3, t - 3, r - l + 6, b - t + 6), 2)
        pg.draw.rect(surface, palette.RIM_GLOW, (l - 1, t - 1, r - l + 2, b - t + 2), 1)
