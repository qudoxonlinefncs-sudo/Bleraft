"""Отрисовка сцены. Модуль pygame передаётся снаружи (удобно для тестов).

Тяжёлые слои (пол арены, спрайты, тень) строятся один раз и кэшируются.
"""

import settings
from ui import palette, sprites
from ui.floor_view import FloorView


class SceneRenderer:
    def __init__(self, pygame):
        self._pg = pygame
        self._arena_key = None
        self._arena_layer = None
        self._sprites = {}
        self._shadow = None
        self._floor_view = FloorView(pygame)

    # --- кэшируемые слои ---

    def _build_arena_layer(self, arena):
        pg = self._pg
        frame = settings.ARENA_FRAME
        tile = settings.ARENA_TILE_SIZE
        width, height = int(arena.width), int(arena.height)
        total_w, total_h = width + 2 * frame, height + 2 * frame

        layer = pg.Surface((total_w, total_h))
        layer.fill(palette.FRAME_OUTER)
        pg.draw.rect(layer, palette.FRAME_INNER, (2, 2, total_w - 4, total_h - 4))

        for row in range(0, height, tile):
            for col in range(0, width, tile):
                color = palette.FLOOR_A if ((row + col) // tile) % 2 == 0 else palette.FLOOR_B
                pg.draw.rect(
                    layer, color,
                    (frame + col, frame + row, min(tile, width - col), min(tile, height - row)),
                )

        pg.draw.rect(layer, palette.CENTER_LINE, (frame + width // 2 - 1, frame, 2, height))
        pg.draw.rect(layer, palette.FRAME_HIGHLIGHT, (frame - 1, frame - 1, width + 2, height + 2), 1)
        return layer

    def _get_arena_layer(self, arena):
        key = (arena.left, arena.top, arena.width, arena.height)
        if key != self._arena_key:
            self._arena_layer = self._build_arena_layer(arena)
            self._arena_key = key
        return self._arena_layer

    def _get_sprite(self, team):
        if team not in self._sprites:
            self._sprites[team] = sprites.build_fighter_sprite(
                self._pg, team, settings.SPRITE_SCALE
            )
        return self._sprites[team]

    def _get_shadow(self):
        if self._shadow is None:
            pg = self._pg
            width, height = settings.PLAYER_SIZE, settings.PLAYER_SIZE // 3
            self._shadow = pg.Surface((width, height), pg.SRCALPHA)
            pg.draw.ellipse(self._shadow, palette.SHADOW, (0, 0, width, height))
        return self._shadow

    # --- кадр ---

    def draw(self, surface, arena, fighters, alpha):
        surface.fill(settings.BACKGROUND_COLOR)

        floor = getattr(arena, "floor", None)
        if floor is not None:
            self._floor_view.draw(surface, floor)
        else:
            frame = settings.ARENA_FRAME
            surface.blit(
                self._get_arena_layer(arena),
                (int(arena.left) - frame, int(arena.top) - frame),
            )

        shadow = self._get_shadow()
        # нижние (по экрану) персонажи рисуются поверх верхних
        for fighter in sorted(fighters, key=lambda f: f.y):
            rx, ry = fighter.render_position(alpha)
            half_w, half_h = fighter.width // 2, fighter.height // 2
            sprite = self._get_sprite(fighter.team)
            if fighter.ring_out:                       # падение за краем арены
                p = fighter.ring_out_time / settings.RING_OUT_FALL_TIME
                if p >= 1.0:
                    continue
                size = max(2, int(fighter.width * (1.0 - 0.8 * p)))
                small = self._pg.transform.scale(sprite, (size, size))
                surface.blit(small, (round(rx) - size // 2, round(ry) - size // 2 + int(40 * p * p)))
                continue
            surface.blit(shadow, (round(rx) - half_w, round(ry) + half_h - shadow.get_height() // 2))
            surface.blit(sprite, (round(rx) - half_w, round(ry) - half_h))
