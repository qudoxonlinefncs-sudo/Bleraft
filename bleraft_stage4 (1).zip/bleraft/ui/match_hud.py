"""HUD матча: таймер, предупреждение об обрушении, Combo Rush, подписи."""

from ui import palette


def format_time(seconds):
    seconds = max(0, int(seconds + 0.999))
    return "%d:%02d" % (seconds // 60, seconds % 60)


class MatchHud:
    def __init__(self, pygame, font):
        self._pg = pygame
        self._font = font

    def draw(self, surface, scene, time_limit=None, names=("ИГРОК", "БОТ")):
        arena = scene.arena
        f = self._font
        # подписи над полосками здоровья
        f.draw(surface, names[0], int(arena.left), 12, 2, palette.HP_FILL["blue"], palette.RIM_DARK)
        f.draw(surface, names[1], int(arena.right), 12, 2, palette.HP_FILL["red"],
               palette.RIM_DARK, anchor="topright")
        # таймер
        if time_limit is None:
            f.draw(surface, "ТРЕНИРОВКА", 640, 10, 2, palette.UI_DIM, palette.RIM_DARK, "midtop")
        else:
            left = time_limit - scene.time
            color = palette.UI_RED if left < 30 else palette.UI_TEXT
            f.draw(surface, format_time(left), 640, 8, 4, color, palette.RIM_DARK, "midtop")
        self._draw_collapse(surface, scene)
        for index, rush in enumerate(scene.rush):
            self._draw_rush(surface, scene, index, rush)

    def _draw_collapse(self, surface, scene):
        floor = scene.floor
        if floor is None or not floor.has_next_ring:
            return
        left = floor.time_to_collapse
        if floor.warning_active:
            color = palette.WARN_A if int(scene.time * 4) % 2 == 0 else palette.WARN_B
            text = "ВНИМАНИЕ! КРАЙ АРЕНЫ РАЗРУШИТСЯ ЧЕРЕЗ %d" % int(left + 0.999)
            self._font.draw(surface, text, 640, 52, 2, color, palette.RIM_DARK, "midtop")
        elif left is not None and left < 10:
            self._font.draw(surface, "КРАЙ ЧЕРЕЗ %d" % int(left + 0.999), 640, 52, 2,
                            palette.UI_DIM, palette.RIM_DARK, "midtop")

    def _draw_rush(self, surface, scene, index, rush):
        if not rush.active:
            return
        pg, f, arena = self._pg, self._font, scene.arena
        now = scene.time
        left_side = index == 0
        x = int(arena.left) + 56 if left_side else int(arena.right) - 56
        y = 66
        event = rush.last_event
        age = now - event.time if event is not None else 9.0
        flash = age < 0.2 and event is not None and event.kind != "reset"
        label = "СЕРИЯ x%d" % rush.count
        color = palette.UI_GOLD if rush.combo_active else palette.UI_TEXT
        anchor = "topleft" if left_side else "topright"
        f.draw(surface, label, x, y, 3 if flash else 2, palette.UI_GREEN if flash else color,
               palette.RIM_DARK, anchor)
        # полоска оставшегося времени на следующий жест
        width, height = 150, 8
        bx = x if left_side else x - width
        frac = rush.remaining(now) / rush.limit if rush.limit else 0.0
        frac = max(0.0, min(1.0, frac))
        bar_color = palette.UI_GREEN if frac > 0.5 else (palette.UI_ORANGE if frac > 0.25 else palette.UI_RED)
        pg.draw.rect(surface, palette.HP_BACK, (bx, y + 22, width, height))
        if frac > 0:
            pg.draw.rect(surface, bar_color, (bx, y + 22, int(width * frac), height))
        pg.draw.rect(surface, palette.HP_BORDER, (bx, y + 22, width, height), 1)
        f.draw(surface, "%.1f" % rush.remaining(now), bx + (width + 6 if left_side else -6),
               y + 20, 2, palette.UI_DIM, None, "topleft" if left_side else "topright")
        if rush.combo_active:
            # заметная надпись COMBO; "всплеск" при каждом продолжении
            pop = 8 if age < 0.12 else (7 if age < 0.25 else 6)
            cx = 640 + (-260 if left_side else 260)
            tint = palette.UI_GOLD if rush.count < 5 else palette.UI_ORANGE
            f.draw(surface, "COMBO!", cx, 150, pop, tint, palette.RIM_DARK, "center")
            f.draw(surface, "x%d" % rush.count, cx, 150 + 7 * pop // 2 + 18, 4, palette.UI_TEXT,
                   palette.RIM_DARK, "center")
