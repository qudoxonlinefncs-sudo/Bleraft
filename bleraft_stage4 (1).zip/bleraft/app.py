"""Сборка приложения: профиль, звук, шрифт, экраны и игра."""

from audio.sfx import SoundBank
from core.flow import ScreenFlow
from core.game import Game
from core.profile import Profile, Storage
from ui.backdrop import Backdrop
from ui.pixel_font import PixelFont
from ui.screens import LobbyScreen, MainMenuScreen, MatchScreen, SettingsScreen, StatsScreen


class AppContext:
    """Общие службы, которые получают все экраны."""

    def __init__(self, pygame, storage_dir=None):
        self.pygame = pygame
        self.profile = Profile(Storage(storage_dir))
        self.font = PixelFont(pygame)
        self.sound = SoundBank(pygame, self.profile)
        self.backdrop = Backdrop(pygame)
        self.flow = None


def build_game(pygame, storage_dir=None):
    """Возвращает (Game, AppContext). Игра стартует с главного меню."""
    ctx = AppContext(pygame, storage_dir)
    factories = {
        "main_menu": lambda flow, **kw: MainMenuScreen(ctx, **kw),
        "lobby": lambda flow, **kw: LobbyScreen(ctx, **kw),
        "stats": lambda flow, **kw: StatsScreen(ctx, **kw),
        "settings": lambda flow, **kw: SettingsScreen(ctx, **kw),
        "match": lambda flow, **kw: MatchScreen(ctx, **kw),
    }
    ctx.flow = ScreenFlow(pygame, factories, start="main_menu")
    return Game(initial_state=ctx.flow, quit_on_escape=False), ctx
