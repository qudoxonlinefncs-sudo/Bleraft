"""Схемы управления. Чистая логика: клавиши - просто непрозрачные значения."""

from dataclasses import dataclass


@dataclass(frozen=True)
class ControlScheme:
    up: object
    down: object
    left: object
    right: object


def read_direction(scheme, is_pressed):
    """Направление (dx, dy), каждая компонента -1, 0 или 1.

    is_pressed(key) -> bool. Ось Y экрана направлена вниз. Противоположные
    клавиши взаимно гасятся.
    """
    dx = int(bool(is_pressed(scheme.right))) - int(bool(is_pressed(scheme.left)))
    dy = int(bool(is_pressed(scheme.down))) - int(bool(is_pressed(scheme.up)))
    return dx, dy
