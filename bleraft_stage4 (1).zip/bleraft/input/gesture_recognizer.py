"""Распознавание жестов. Без Pygame.

Версия 2: основа - геометрия жеста, а не расстояние до картинки.
  1. Путь ресемплируется и упрощается (Дуглас-Пекер): остаются только заметные углы.
     Короткие "хвостики" на концах (дрожание при отпускании кнопки) игнорируются.
  2. Прямая линия (`/`, `-`, `|`): мало поворотов, путь почти прямой; жест выбирается
     по углу между концами с допуском. Угол вне допуска, но рядом с ним, - неоднозначно.
  3. V: ровно один острый поворот вершиной вниз, обе ножки достаточно длинные.
     Короткая вторая ножка - неоднозначно (это может быть `/` с хвостиком).
  4. Произвольные шаблоны (kind="path") сравниваются по форме, как в версии 1.
Если жест нельзя надёжно отнести к одному шаблону, возвращается ошибка
("ambiguous"/"no_match"), а не случайная атака.
Размер, положение и разрешение экрана не важны: всё считается в долях размера жеста.
"""

import math
from dataclasses import dataclass

import settings
from input.gesture_templates import DEFAULT_TEMPLATES

_EPS = 1e-9


@dataclass(frozen=True)
class Recognition:
    name: str            # имя жеста или None, если не распознан
    reason: str          # "ok", "invalid", "too_few_points", "too_short",
                         # "too_quick", "no_match", "ambiguous"
    distance: float      # расстояние до лучшего шаблона (меньше - точнее)
    margin: float        # отрыв лучшего шаблона от второго
    length: float        # длина пути, пиксели
    duration: float      # секунды
    speed: float         # доля опорного размера в секунду

    @property
    def ok(self):
        return self.name is not None

    @property
    def is_attempt(self):
        """Была ли это попытка нарисовать жест (а не клик или дрожание мыши)."""
        return self.reason in ("ok", "no_match", "ambiguous")


def path_length(points):
    return sum(
        math.hypot(x1 - x0, y1 - y0)
        for (x0, y0), (x1, y1) in zip(points, points[1:])
    )


def resample(points, count):
    """count равноудалённых по длине пути точек. None, если путь нулевой."""
    total = path_length(points)
    if total < _EPS or count < 2:
        return None
    step = total / (count - 1)
    result = [points[0]]
    accumulated = 0.0
    pts = list(points)
    i = 1
    while i < len(pts):
        (x0, y0), (x1, y1) = pts[i - 1], pts[i]
        segment = math.hypot(x1 - x0, y1 - y0)
        if segment > _EPS and accumulated + segment >= step:
            ratio = (step - accumulated) / segment
            point = (x0 + ratio * (x1 - x0), y0 + ratio * (y1 - y0))
            result.append(point)
            pts.insert(i, point)  # продолжаем с новой точки
            accumulated = 0.0
        else:
            accumulated += segment
        i += 1
    while len(result) < count:  # накопленная погрешность float
        result.append(pts[-1])
    return result[:count]


def normalize_path(points, count):
    """Путь -> count точек с центром в нуле и большей стороной рамки = 1.

    Возвращает None для вырожденного пути (все точки в одном месте).
    """
    sampled = resample(points, count)
    if sampled is None:
        return None
    cx = sum(p[0] for p in sampled) / len(sampled)
    cy = sum(p[1] for p in sampled) / len(sampled)
    shifted = [(x - cx, y - cy) for x, y in sampled]
    xs = [p[0] for p in shifted]
    ys = [p[1] for p in shifted]
    size = max(max(xs) - min(xs), max(ys) - min(ys))
    if size < _EPS:
        return None
    return [(x / size, y / size) for x, y in shifted]


def mean_distance(a, b):
    return sum(math.hypot(p[0] - q[0], p[1] - q[1]) for p, q in zip(a, b)) / len(a)


def _rdp(points, epsilon):
    """Упрощение ломаной (Дуглас-Пекер), возвращает вершины."""
    if len(points) < 3:
        return list(points)
    (x0, y0), (x1, y1) = points[0], points[-1]
    dx, dy = x1 - x0, y1 - y0
    norm = math.hypot(dx, dy)
    far_index, far_dist = 0, -1.0
    for i in range(1, len(points) - 1):
        px, py = points[i]
        if norm < _EPS:
            d = math.hypot(px - x0, py - y0)
        else:
            d = abs(dy * (px - x0) - dx * (py - y0)) / norm
        if d > far_dist:
            far_index, far_dist = i, d
    if far_dist <= epsilon:
        return [points[0], points[-1]]
    left = _rdp(points[: far_index + 1], epsilon)
    right = _rdp(points[far_index:], epsilon)
    return left[:-1] + right


def _seg_len(a, b):
    return math.hypot(b[0] - a[0], b[1] - a[1])


def _turn_degrees(a, b, c):
    """Угол поворота в вершине b (0 - прямо, 180 - разворот)."""
    v1 = (b[0] - a[0], b[1] - a[1])
    v2 = (c[0] - b[0], c[1] - b[1])
    n1, n2 = math.hypot(*v1), math.hypot(*v2)
    if n1 < _EPS or n2 < _EPS:
        return 0.0
    cos = (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)
    return math.degrees(math.acos(max(-1.0, min(1.0, cos))))


def _angle_distance(a, b):
    """Расстояние между углами прямых (период 180 градусов)."""
    d = abs(a - b) % 180.0
    return min(d, 180.0 - d)


class Shape:
    """Геометрические признаки жеста."""

    def __init__(self, xy, count, settings_):
        self.kind = "other"        # line / vee / other
        self.angle = 0.0           # угол линии (Y вверх), 0..180
        self.ambiguous = False
        self.legs = ()
        s = settings_
        sampled = resample(xy, count)
        xs = [p[0] for p in sampled]
        ys = [p[1] for p in sampled]
        size = max(max(xs) - min(xs), max(ys) - min(ys))
        total = path_length(sampled)
        chord = _seg_len(sampled[0], sampled[-1])
        self.total, self.size = total, size
        if size < _EPS or total < _EPS or chord / total < s.GESTURE_CLOSED_RATIO:
            return  # точка или замкнутая фигура
        verts = _rdp(sampled, s.GESTURE_RDP_EPSILON * size)

        # убираем короткие хвостики на концах
        hook = s.GESTURE_HOOK_FRACTION * total
        while len(verts) > 2 and _seg_len(verts[0], verts[1]) < hook:
            verts.pop(0)
        while len(verts) > 2 and _seg_len(verts[-2], verts[-1]) < hook:
            verts.pop()
        # пологие изгибы - это всё ещё прямая
        i = 1
        while i < len(verts) - 1:
            if _turn_degrees(verts[i - 1], verts[i], verts[i + 1]) < s.GESTURE_BEND_MAX_DEG:
                verts.pop(i)
            else:
                i += 1

        if len(verts) == 2:
            core_len = _seg_len(verts[0], verts[1])
            if core_len / total < s.GESTURE_LINE_MIN_STRAIGHT:
                return
            dx, dy = verts[1][0] - verts[0][0], verts[1][1] - verts[0][1]
            self.kind = "line"
            self.angle = math.degrees(math.atan2(-dy, dx)) % 180.0   # Y вверх
        elif len(verts) == 3:
            a, apex, b = verts
            l1, l2 = _seg_len(a, apex), _seg_len(apex, b)
            self.legs = (l1 / (l1 + l2), l2 / (l1 + l2))
            interior = 180.0 - _turn_degrees(a, apex, b)
            steep = math.sin(math.radians(s.GESTURE_VEE_MIN_STEEP_DEG))
            down = (apex[1] - a[1]) / l1       # первая ножка идёт вниз (Y экрана вниз)
            up = (apex[1] - b[1]) / l2         # вторая поднимается
            if down >= steep and up >= steep and interior <= s.GESTURE_VEE_MAX_INTERIOR_DEG:
                if min(self.legs) >= s.GESTURE_VEE_MIN_LEG:
                    self.kind = "vee"
                else:
                    self.ambiguous = True      # V с хвостиком или `/` с изгибом


class GestureRecognizer:
    def __init__(
        self,
        templates=DEFAULT_TEMPLATES,
        reference_size=None,
        resample_points=None,
        min_points=None,
        min_length_ratio=None,
        min_duration=None,
        max_distance=None,
        min_margin=None,
    ):
        s = settings
        self.reference_size = s.GESTURE_REFERENCE_SIZE if reference_size is None else reference_size
        self.count = s.GESTURE_RESAMPLE_POINTS if resample_points is None else resample_points
        self.min_points = s.GESTURE_MIN_POINTS if min_points is None else min_points
        self.min_length_ratio = s.GESTURE_MIN_LENGTH_RATIO if min_length_ratio is None else min_length_ratio
        self.min_duration = s.GESTURE_MIN_DURATION if min_duration is None else min_duration
        self.max_distance = s.GESTURE_MAX_DISTANCE if max_distance is None else max_distance
        self.min_margin = s.GESTURE_MIN_MARGIN if min_margin is None else min_margin
        self._variants = []  # (имя, нормализованные точки) - только для kind="path"
        self._templates = []
        for template in templates:
            self.add_template(template)

    def add_template(self, template):
        """Добавляет жест без изменения самого распознавателя."""
        pts = normalize_path(template.points, self.count)
        if pts is None:
            raise ValueError("Шаблон %r вырожден" % template.name)
        self._templates.append(template)
        if template.kind == "path":
            self._variants.append((template.name, pts))
            if template.allow_reverse:
                self._variants.append((template.name, pts[::-1]))

    def _template_distance(self, template, path):
        pts = normalize_path(template.points, self.count)
        d = mean_distance(path, pts)
        if template.allow_reverse:
            d = min(d, mean_distance(path, pts[::-1]))
        return d

    def _result(self, name, reason, distance=0.0, margin=0.0, length=0.0, duration=0.0):
        speed = 0.0
        if duration > 0:
            speed = length / self.reference_size / duration
        return Recognition(name, reason, distance, margin, length, duration, speed)

    def recognize(self, points):
        """points - последовательность (x, y, t). Никогда не бросает исключений."""
        clean = []
        try:
            for p in points:
                x, y, t = float(p[0]), float(p[1]), float(p[2])
                if math.isfinite(x) and math.isfinite(y) and math.isfinite(t):
                    clean.append((x, y, t))
        except (TypeError, ValueError, IndexError):
            return self._result(None, "invalid")
        if not clean:
            return self._result(None, "invalid")

        xy = [(x, y) for x, y, _ in clean]
        length = path_length(xy)
        duration = clean[-1][2] - clean[0][2]
        if not (math.isfinite(length) and math.isfinite(duration)):
            return self._result(None, "invalid")  # абсурдные координаты
        info = dict(length=length, duration=max(duration, 0.0))

        if len(clean) < self.min_points:
            return self._result(None, "too_few_points", **info)
        if length < self.min_length_ratio * self.reference_size:
            return self._result(None, "too_short", **info)
        if duration < self.min_duration:
            return self._result(None, "too_quick", **info)

        path = normalize_path(xy, self.count)
        if path is None:
            return self._result(None, "too_short", **info)

        shape = Shape(xy, self.count, settings)

        # --- геометрические шаблоны: line / vee ---
        geometric = []
        near = False   # угол рядом с допуском: неоднозначно
        for t in self._templates:
            if t.kind == "line" and shape.kind == "line":
                tol = settings.GESTURE_LINE_TOLERANCE_DEG if t.tolerance is None else t.tolerance
                delta = _angle_distance(shape.angle, t.angle)
                if delta <= tol:
                    geometric.append(t)
                elif delta <= tol + settings.GESTURE_LINE_AMBIGUOUS_DEG:
                    near = True
            elif t.kind == "vee" and shape.kind == "vee":
                geometric.append(t)
        if shape.ambiguous and any(t.kind in ("vee", "line") for t in self._templates):
            near = True

        # --- шаблоны-пути (произвольные жесты) ---
        best = {}
        for name, template in self._variants:
            d = mean_distance(path, template)
            if name not in best or d < best[name]:
                best[name] = d
        ranked = sorted(best.items(), key=lambda item: item[1])
        path_name = None
        path_distance, path_margin = 0.0, float("inf")
        if ranked and math.isfinite(ranked[0][1]):
            path_distance = ranked[0][1]
            if len(ranked) > 1:
                path_margin = ranked[1][1] - path_distance
            if path_distance <= self.max_distance:
                path_name = ranked[0][0]

        names = {t.name for t in geometric}
        if path_name is not None and path_margin >= self.min_margin:
            names.add(path_name)
        elif path_name is not None:
            near = True

        if len(names) > 1 or (not names and near):
            return self._result(None, "ambiguous", **info)
        if not names:
            return self._result(None, "no_match", path_distance, path_margin, **info)
        name = next(iter(names))
        template = next(t for t in self._templates if t.name == name)
        distance = self._template_distance(template, path)
        margin = path_margin if template.kind == "path" else 1.0
        return self._result(name, "ok", distance, margin, **info)
