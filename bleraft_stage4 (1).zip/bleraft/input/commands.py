"""Команды, которые ввод передаёт игровой сцене. Чистые данные."""

from dataclasses import dataclass


@dataclass(frozen=True)
class StrokeCommand:
    player_index: int
    stroke: object          # input.gesture_recorder.Stroke


@dataclass(frozen=True)
class AttackKeyCommand:
    """Атака клавишей (временная замена жеста для игрока без мыши)."""
    player_index: int
    gesture: str


@dataclass(frozen=True)
class ResetCommand:
    """Начать раунд заново."""
