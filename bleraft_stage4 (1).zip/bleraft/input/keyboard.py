"""Клавиатурный ввод. Модуль pygame передаётся снаружи (удобно для тестов)."""

from input.controls import ControlScheme, read_direction


def default_schemes(pygame):
    """Схемы по умолчанию: игрок 1 - WASD, игрок 2 - стрелки."""
    return (
        ControlScheme(up=pygame.K_w, down=pygame.K_s, left=pygame.K_a, right=pygame.K_d),
        ControlScheme(
            up=pygame.K_UP, down=pygame.K_DOWN, left=pygame.K_LEFT, right=pygame.K_RIGHT
        ),
    )


class KeyboardInput:
    def __init__(self, pygame, schemes=None):
        self._pygame = pygame
        self.schemes = tuple(schemes) if schemes is not None else default_schemes(pygame)

    def direction(self, player_index):
        pressed = self._pygame.key.get_pressed()
        return read_direction(self.schemes[player_index], lambda key: pressed[key])
