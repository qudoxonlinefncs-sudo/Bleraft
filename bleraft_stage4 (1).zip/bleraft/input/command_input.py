"""Преобразование событий pygame в команды. Модуль pygame передаётся снаружи.

Мышь (левая кнопка) рисует жесты игрока с номером mouse_player.
У одного компьютера одна мышь, поэтому для второго игрока временно есть
клавиши атак (Z/X/C/V = slash/sweep/thrust/double, средняя скорость).
R - начать раунд заново.
"""

from input.commands import AttackKeyCommand, ResetCommand, StrokeCommand
from input.gesture_recorder import GestureRecorder


def default_attack_keys(pygame):
    return {
        1: {
            pygame.K_z: "slash",
            pygame.K_x: "sweep",
            pygame.K_c: "thrust",
            pygame.K_v: "double",
        }
    }


class CommandInput:
    def __init__(self, pygame, recorder=None, mouse_player=0, attack_keys=None):
        self._pg = pygame
        self.recorder = recorder if recorder is not None else GestureRecorder()
        self.mouse_player = mouse_player
        self.attack_keys = attack_keys if attack_keys is not None else default_attack_keys(pygame)

    def handle_event(self, event, now):
        """Возвращает список команд для события (обычно пустой или из одной)."""
        pg, rec = self._pg, self.recorder
        kind = event.type

        if kind == pg.MOUSEBUTTONDOWN and event.button == 1:
            rec.begin(event.pos[0], event.pos[1], now)
            return []

        if kind == pg.MOUSEMOTION and rec.active:
            if not event.buttons[0]:       # отпускание могло прийти вне окна
                return self._finish(event.pos, now)
            rec.add_point(event.pos[0], event.pos[1], now)
            return []

        if kind == pg.MOUSEBUTTONUP and event.button == 1:
            return self._finish(event.pos, now)

        if kind == pg.KEYDOWN:
            if event.key == pg.K_r:
                return [ResetCommand()]
            for player, keys in self.attack_keys.items():
                gesture = keys.get(event.key)
                if gesture is not None:
                    return [AttackKeyCommand(player, gesture)]
        return []

    def _finish(self, pos, now):
        stroke = self.recorder.end(pos[0], pos[1], now)
        if stroke is None:
            return []
        return [StrokeCommand(self.mouse_player, stroke)]
