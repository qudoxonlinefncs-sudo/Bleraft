"""Шаблоны жестов (данные). Чистая логика, без Pygame.

Чтобы добавить новый жест, достаточно добавить GestureTemplate в
DEFAULT_TEMPLATES (и атаку с тем же именем в combat/attacks.py).
Распознаватель менять не нужно.

Точки шаблона - ключевые точки полилинии в любом масштабе; ось Y направлена
вниз, как на экране. Масштаб, положение и число точек не важны.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class GestureTemplate:
    name: str                 # ключ жеста (совпадает с ключом атаки)
    points: tuple             # ключевые точки (x, y)
    symbol: str               # как жест выглядит для игрока
    allow_reverse: bool = True  # можно рисовать в обратном направлении
    # Как жест распознаётся:
    #   "line" - прямая линия под углом `angle` (градусы, математическая ориентация,
    #            Y вверх: 0 = горизонталь, 45 = `/`, 90 = вертикаль), допуск `tolerance`;
    #   "vee"  - один острый поворот вершиной вниз (V);
    #   "path" - сравнение формы с точками шаблона (для произвольных жестов).
    kind: str = "path"
    angle: float = 0.0
    tolerance: float = None   # None - GESTURE_LINE_TOLERANCE_DEG


DEFAULT_TEMPLATES = (
    GestureTemplate("slash", ((0.0, 1.0), (1.0, 0.0)), "/", kind="line", angle=45.0),
    GestureTemplate("sweep", ((0.0, 0.0), (1.0, 0.0)), "-", kind="line", angle=0.0),
    GestureTemplate("thrust", ((0.0, 0.0), (0.0, 1.0)), "|", kind="line", angle=90.0),
    GestureTemplate("double", ((0.0, 0.0), (0.5, 1.0), (1.0, 0.0)), "V", kind="vee"),
)
