"""Запись траектории жеста. Чистая логика, без Pygame.

Время передаётся снаружи (секунды игровых часов), поэтому запись
детерминирована и тестируется без окна.
"""

import math
from dataclasses import dataclass

import settings


@dataclass(frozen=True)
class Stroke:
    """Готовый жест: точки (x, y, t) в порядке рисования."""

    points: tuple

    @property
    def duration(self):
        if len(self.points) < 2:
            return 0.0
        return self.points[-1][2] - self.points[0][2]

    @property
    def length(self):
        total = 0.0
        for (x0, y0, _), (x1, y1, _) in zip(self.points, self.points[1:]):
            total += math.hypot(x1 - x0, y1 - y0)
        return total


class GestureRecorder:
    def __init__(self, spacing=None, max_points=None):
        self.spacing = settings.GESTURE_POINT_SPACING if spacing is None else spacing
        self.max_points = settings.GESTURE_MAX_POINTS if max_points is None else max_points
        self._points = []
        self.active = False

    @property
    def points(self):
        """Текущие точки (x, y, t) - для отрисовки следа во время рисования."""
        return self._points

    def begin(self, x, y, t):
        """Начало жеста (кнопка нажата). Незавершённый жест отбрасывается."""
        self._points = [(float(x), float(y), float(t))]
        self.active = True

    def add_point(self, x, y, t):
        if not self.active or len(self._points) >= self.max_points:
            return
        lx, ly, _ = self._points[-1]
        if math.hypot(x - lx, y - ly) < self.spacing:
            return  # дрожание мыши не записываем
        self._points.append((float(x), float(y), float(t)))

    def end(self, x, y, t):
        """Конец жеста (кнопка отпущена). Возвращает Stroke или None."""
        if not self.active:
            return None
        self.add_point(x, y, t)
        points = tuple(self._points)
        self.cancel()
        # время конца жеста - момент отпускания, даже если мышь стояла на месте
        if points and points[-1][2] < t:
            points = points + ((points[-1][0], points[-1][1], float(t)),)
        return Stroke(points)

    def cancel(self):
        self._points = []
        self.active = False
