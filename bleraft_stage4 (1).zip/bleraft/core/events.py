"""Простая шина событий: модули не знают друг о друге напрямую.

Например, боевая система публикует "damage", а HUD подписывается на него.
"""


class EventBus:
    def __init__(self):
        self._handlers = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    def unsubscribe(self, name, handler):
        handlers = self._handlers.get(name)
        if handlers and handler in handlers:
            handlers.remove(handler)

    def publish(self, name, **data):
        # копия списка: обработчик может отписаться во время публикации
        for handler in list(self._handlers.get(name, ())):
            handler(**data)
