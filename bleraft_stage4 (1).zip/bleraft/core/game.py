"""Главный игровой цикл. Pygame импортируется только внутри run()."""

import settings
from core.events import EventBus
from core.loop import FixedStepLoop
from core.states import BlankState, StateManager


class Game:
    def __init__(self, initial_state=None, quit_on_escape=True):
        self.events = EventBus()
        self.states = StateManager()
        self.loop = FixedStepLoop(
            settings.LOGIC_TICKS_PER_SECOND, settings.MAX_FRAME_TIME
        )
        self._initial_state = initial_state or BlankState()
        self.running = False
        self.quit_on_escape = quit_on_escape   # в меню Esc обрабатывают сами экраны

    def _exit_requested(self):
        return not self.running or self.states.quit_requested

    def _process_events(self, pygame):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif (self.quit_on_escape and event.type == pygame.KEYDOWN
                  and event.key == pygame.K_ESCAPE):
                self.running = False
            else:
                self.states.handle_event(event)

    def run(self):
        import pygame

        pygame.init()
        try:
            screen = pygame.display.set_mode(
                (settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT)
            )
            pygame.display.set_caption(settings.GAME_TITLE)
            clock = pygame.time.Clock()
            self.states.change(self._initial_state)
            self.running = True
            caption_timer = 0.0

            while self.running and not self.states.quit_requested:
                frame_time = clock.tick(settings.TARGET_FPS) / 1000.0
                self._process_events(pygame)
                if self._exit_requested():
                    break  # выход без лишних update/draw
                self.loop.advance(
                    frame_time, self.states.update, self._exit_requested
                )
                if self._exit_requested():
                    break  # выход запрошен в update(): кадр не рисуем
                self.states.draw(screen, self.loop.alpha)
                pygame.display.flip()

                caption_timer += frame_time
                if caption_timer >= settings.FPS_CAPTION_INTERVAL:
                    caption_timer = 0.0
                    pygame.display.set_caption(
                        "%s - %.0f FPS" % (settings.GAME_TITLE, clock.get_fps())
                    )
        finally:
            self.states.change(None)
            pygame.quit()
