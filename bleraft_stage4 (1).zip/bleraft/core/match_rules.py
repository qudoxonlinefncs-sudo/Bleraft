"""Правила матча и статистика. Чистая логика, без Pygame.

Победа и поражение определяются реальным состоянием боя:
  - нокаут (HP = 0) или Ring Out (вылет за безопасную зону);
  - по истечении времени (если оно ограничено) побеждает тот, у кого больше HP;
    при равенстве - кто нанёс больше урона; иначе поражение.
Если оба бойца выбыли одновременно, это поражение игрока.
"""

from dataclasses import dataclass, field

VICTORY = "victory"
DEFEAT = "defeat"
KO = "ko"
RING_OUT = "ring_out"
TIMEOUT = "timeout"


@dataclass
class MatchStats:
    damage_dealt: float = 0.0
    damage_taken: float = 0.0
    hits_landed: int = 0
    hits_taken: int = 0
    gestures_ok: int = 0
    gestures_failed: int = 0
    max_combo: int = 0

    def as_dict(self):
        return dict(self.__dict__)


@dataclass(frozen=True)
class MatchResult:
    outcome: str            # victory / defeat
    reason: str             # ko / ring_out / timeout
    duration: float         # секунды игрового времени
    player_hp: float
    enemy_hp: float
    stats: dict = field(default_factory=dict)


class MatchRules:
    def __init__(self, player_index=0, time_limit=None):
        self.player_index = player_index
        self.time_limit = time_limit     # None - без ограничения (тренировка)

    @staticmethod
    def _reason(fighter):
        return RING_OUT if fighter.ring_out else KO

    def _result(self, outcome, reason, scene):
        fighters = scene.fighters
        me = fighters[self.player_index]
        enemies = [f for i, f in enumerate(fighters) if i != self.player_index]
        enemy_hp = sum(e.hp for e in enemies) / max(1, len(enemies))
        return MatchResult(outcome, reason, scene.time, me.hp, enemy_hp, scene.stats.as_dict())

    def evaluate(self, scene):
        """MatchResult, если матч закончился, иначе None."""
        fighters = scene.fighters
        me = fighters[self.player_index]
        enemies = [f for i, f in enumerate(fighters) if i != self.player_index]
        if not me.alive:
            return self._result(DEFEAT, self._reason(me), scene)
        if enemies and all(not e.alive for e in enemies):
            dead = next((e for e in enemies if e.ring_out), enemies[0])
            return self._result(VICTORY, self._reason(dead), scene)
        if self.time_limit is not None and scene.time >= self.time_limit:
            enemy_hp = sum(e.hp for e in enemies) / max(1, len(enemies))
            mine, theirs = me.hp / me.max_hp, enemy_hp / enemies[0].max_hp
            if mine > theirs:
                outcome = VICTORY
            elif mine < theirs:
                outcome = DEFEAT
            else:
                st = scene.stats
                outcome = VICTORY if st.damage_dealt > st.damage_taken else DEFEAT
            return self._result(outcome, TIMEOUT, scene)
        return None
