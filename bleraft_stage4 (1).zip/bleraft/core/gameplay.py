"""Игровая сцена: арена, бойцы, жесты, бой, Combo Rush, пол арены, Ring Out, боты."""

import settings
from arena.arena import Arena
from combat.attacks import tier_for_speed
from combat.combat_system import BUSY, STARTED, CombatSystem
from combat.combo_rush import ComboRush
from core.match_rules import MatchStats
from core.states import State
from entities.fighter import Fighter, FighterState
from input.commands import AttackKeyCommand, ResetCommand, StrokeCommand
from input.gesture_recognizer import GestureRecognizer
from ui.effects import Effects


def create_fighters(arena):
    """Синий слева, красный справа, оба по центру арены по вертикали."""
    offset = settings.PLAYER_SPAWN_OFFSET
    return [
        Fighter("blue", arena.center_x - offset, arena.center_y,
                settings.PLAYER_SIZE, settings.PLAYER_SPEED),
        Fighter("red", arena.center_x + offset, arena.center_y,
                settings.PLAYER_SIZE, settings.PLAYER_SPEED),
    ]


class GameplayState(State):
    """Логика сцены. Ввод, отрисовка, боты и правила матча подключаются снаружи.

    input_source.direction(index) -> (dx, dy) - движение игрока index.
    command_input.handle_event(event, now) -> команды (жесты, клавиши атак).
    renderer.draw(surface, arena, fighters, alpha) - арена и бойцы.
    combat_view.draw(surface, scene, alpha) - бой, HUD, след жеста.
    controllers - {индекс бойца: бот}; бот вместо input_source решает, куда идти и когда бить.
    rules - MatchRules: после каждого тика проверяет конец матча (scene.result).
    Всё, кроме input_source, необязательно.
    """

    def __init__(self, input_source, renderer=None, arena=None, fighters=None,
                 command_input=None, combat_view=None, recognizer=None,
                 controllers=None, rules=None, player_index=0):
        super().__init__()
        self.input = input_source
        self.renderer = renderer
        self.command_input = command_input
        self.combat_view = combat_view
        self.recognizer = recognizer if recognizer is not None else GestureRecognizer()
        self.arena = arena if arena is not None else Arena.from_settings()
        self.floor = self.arena.floor
        self.fighters = (
            fighters if fighters is not None else create_fighters(self.arena)
        )
        self.controllers = controllers if controllers is not None else {}
        self.rules = rules
        self.player_index = player_index
        self.combat = CombatSystem(self.fighters)
        self.effects = Effects()
        self.rush = [ComboRush() for _ in self.fighters]
        self.stats = MatchStats()
        self.result = None
        self.sound_events = []     # "hit", "swing", "combo", "crack", "fall", "ringout"

    @property
    def time(self):
        return self.combat.time

    @property
    def trail(self):
        """Точки жеста, который рисуется прямо сейчас."""
        if self.command_input is None or not self.command_input.recorder.active:
            return []
        return self.command_input.recorder.points

    # ---------- ввод ----------

    def handle_event(self, event):
        if self.command_input is None or self.result is not None:
            return
        for command in self.command_input.handle_event(event, self.time):
            self.execute(command)

    def execute(self, command):
        if isinstance(command, ResetCommand):
            self.reset()
        elif isinstance(command, StrokeCommand):
            self._attack_from_stroke(command)
        elif isinstance(command, AttackKeyCommand):
            if 0 <= command.player_index < len(self.fighters):
                self.perform_gesture(command.player_index, command.gesture, "medium")

    def _attack_from_stroke(self, command):
        index = command.player_index
        if not 0 <= index < len(self.fighters):
            return
        result = self.recognizer.recognize(command.stroke.points)
        if not result.ok:
            self.effects.set_indicator(index, None, None, False, result.reason)
            if result.is_attempt:                      # неправильный жест, а не клик
                self.rush[index].fail(self.time)
                if index == self.player_index:
                    self.stats.gestures_failed += 1
            return                                     # неизвестный жест атаку не запускает
        self.perform_gesture(index, result.name, tier_for_speed(result.speed))

    def perform_gesture(self, index, gesture, tier="medium"):
        """Правильно распознанный жест бойца: учёт Combo Rush и запуск атаки.

        Единый путь и для игрока, и для бота: у всех одинаковые правила.
        """
        fighter = self.fighters[index]
        rush = self.rush[index]
        rush.register(self.time)
        if index == self.player_index:
            self.stats.gestures_ok += 1
            self.stats.max_combo = max(self.stats.max_combo, rush.peak)
        result = self.combat.request_attack(
            fighter, gesture, tier, damage_scale=rush.damage_multiplier())
        if result == BUSY:   # чуть рано: запомним, выполнится, когда можно
            self.combat.buffer_attack(fighter, gesture, tier, rush.damage_multiplier())
        elif result == STARTED:
            self.sound_events.append("swing")
        self.effects.set_indicator(index, gesture, tier, result in (STARTED, BUSY), "ok")
        return result

    def reset(self):
        self.fighters[:] = create_fighters(self.arena)
        self.combat = CombatSystem(self.fighters)
        self.effects.clear()
        self.rush = [ComboRush() for _ in self.fighters]
        self.stats = MatchStats()
        self.result = None
        self.sound_events = []
        if self.floor is not None:
            self.floor.reset()
        for controller in self.controllers.values():
            controller.reset()
        if self.command_input is not None:
            self.command_input.recorder.cancel()

    # ---------- логика ----------

    def update(self, dt):
        if self.result is not None:
            self.update_visuals(dt)       # бой остановлен: двигаются только эффекты
            return
        self.combat.update(dt)
        self._handle_combat_events()
        if self.floor is not None:
            self.floor.update(dt)
            self.sound_events.extend(self.floor.events)
        for index, rush in enumerate(self.rush):
            rush.update(self.time)
            self._drain_rush(rush)

        knock_through = self.floor is not None
        for index, fighter in enumerate(self.fighters):
            controller = self.controllers.get(index)
            if controller is not None and fighter.alive:
                intent = controller.think(self, index, dt)
                direction = intent.direction
                if intent.gesture is not None:
                    self.perform_gesture(index, intent.gesture, intent.tier)
            elif controller is not None:
                direction = (0, 0)
            else:
                direction = self.input.direction(index)
            fighter.update(dt, direction, self.arena.bounds, knock_through)
        if self.floor is not None:
            self._check_ring_out()
        self.update_visuals(dt)
        if self.rules is not None:
            self.result = self.rules.evaluate(self)

    def update_visuals(self, dt):
        self.effects.update(dt)
        for fighter in self.fighters:
            if fighter.ring_out:
                fighter.ring_out_time += dt

    def _handle_combat_events(self):
        for event in self.combat.events:
            self.effects.add_hit(event.x, event.y, event.finisher)
            self.sound_events.append("hit")
            attacker = self.fighters.index(event.attacker)
            target = self.fighters.index(event.target)
            self.rush[target].interrupt(self.time)        # удар прерывает серию
            self._drain_rush(self.rush[target])
            if attacker == self.player_index:
                self.stats.damage_dealt += event.damage
                self.stats.hits_landed += 1
            elif target == self.player_index:
                self.stats.damage_taken += event.damage
                self.stats.hits_taken += 1

    def _drain_rush(self, rush):
        for event in rush.events:
            if event.kind in ("combo", "extend", "continue"):
                self.sound_events.append("combo")
        rush.events = []

    def _check_ring_out(self):
        for index, fighter in enumerate(self.fighters):
            if fighter.alive and not self.floor.is_safe(fighter.x, fighter.y):
                fighter.ring_out = True
                fighter.state = FighterState.DEAD
                fighter.attack = None
                fighter.knock_vx = fighter.knock_vy = 0.0
                fighter.move_factor = 0.0
                if fighter.combo is not None:
                    fighter.combo.reset()
                self.rush[index].reset(self.time)
                self.sound_events.append("ringout")

    # ---------- отрисовка ----------

    def draw(self, surface, alpha):
        if self.renderer is not None:
            self.renderer.draw(surface, self.arena, self.fighters, alpha)
        if self.combat_view is not None:
            self.combat_view.draw(surface, self, alpha)
