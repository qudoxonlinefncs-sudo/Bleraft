"""Состояния игры (меню, матч, итоги...) и менеджер состояний."""

import settings


class State:
    """Базовый класс состояния. Переопределяйте нужные методы."""

    def __init__(self):
        self.manager = None

    def on_enter(self):
        pass

    def on_exit(self):
        pass

    def handle_event(self, event):
        pass

    def update(self, dt):
        pass

    def draw(self, surface, alpha):
        pass


class BlankState(State):
    """Пустое состояние: только фон. Используется как каркас (шаг 1)."""

    def draw(self, surface, alpha):
        surface.fill(settings.BACKGROUND_COLOR)


class StateManager:
    def __init__(self):
        self.current = None
        self.quit_requested = False

    def change(self, new_state):
        if self.current is not None:
            self.current.on_exit()
            self.current.manager = None
        self.current = new_state
        if new_state is not None:
            new_state.manager = self
            new_state.on_enter()

    def request_quit(self):
        self.quit_requested = True

    def handle_event(self, event):
        if self.current is not None:
            self.current.handle_event(event)

    def update(self, dt):
        if self.current is not None:
            self.current.update(dt)

    def draw(self, surface, alpha):
        if self.current is not None:
            self.current.draw(surface, alpha)
