"""Цикл с фиксированным шагом логики. Не зависит от Pygame."""

_EPSILON = 1e-9


class FixedStepLoop:
    """Накапливает прошедшее время и выдаёт логике равные шаги.

    Логика всегда обновляется с шагом 1 / ticks_per_second, независимо
    от того, с какой частотой рисуются кадры. Это нужно для честного боя
    и (позже) для сетевой синхронизации.
    """

    def __init__(self, ticks_per_second, max_frame_time):
        if ticks_per_second <= 0:
            raise ValueError("ticks_per_second должен быть > 0")
        self.step = 1.0 / ticks_per_second
        self.max_frame_time = max_frame_time
        self.tick_count = 0
        self._accumulator = 0.0

    def advance(self, frame_time, update, should_stop=None):
        """Добавляет время кадра и вызывает update(step) нужное число раз.

        should_stop - необязательная функция без аргументов. Она проверяется
        перед каждым тиком; если вернула True, оставшиеся тики кадра не
        выполняются (например, состояние запросило выход прямо в update()).

        Возвращает количество выполненных шагов логики.
        """
        frame_time = max(0.0, min(frame_time, self.max_frame_time))
        self._accumulator += frame_time
        ticks = 0
        while self._accumulator >= self.step - _EPSILON:
            if should_stop is not None and should_stop():
                break
            update(self.step)
            self._accumulator = max(0.0, self._accumulator - self.step)
            ticks += 1
        self.tick_count += ticks
        return ticks

    @property
    def alpha(self):
        """Доля шага (0..1) для сглаживания отрисовки между тиками логики."""
        return min(1.0, self._accumulator / self.step)
