"""Переходы между экранами игры с плавным затемнением.

Phase - состояние игры: MAIN_MENU, LOBBY, MATCH_START, FIGHT, VICTORY, DEFEAT
(+ STATS и SETTINGS как отдельные экраны меню). Экраны - обычные State; ScreenFlow
сам является State и хранится в корневом StateManager игры.
"""

from enum import Enum

from core.states import State, StateManager


class Phase(Enum):
    MAIN_MENU = "main_menu"
    LOBBY = "lobby"
    MATCH_START = "match_start"
    FIGHT = "fight"
    VICTORY = "victory"
    DEFEAT = "defeat"
    STATS = "stats"
    SETTINGS = "settings"


class ScreenFlow(State):
    def __init__(self, pygame, factories, start, fade=0.22):
        super().__init__()
        self._pg = pygame
        self.factories = factories       # имя -> функция(flow, **параметры) -> экран
        self.start = start
        self.fade = fade
        self.screens = StateManager()
        self.pending = None
        self.mode = "in"                 # out - затемнение, in - проявление, None - ничего
        self.t = 0.0
        self._veil = None
        self.history = []                # имена экранов (для проверки и отладки)

    # ---------- навигация ----------

    @property
    def current(self):
        return self.screens.current

    @property
    def phase(self):
        return getattr(self.current, "phase", None)

    @property
    def transitioning(self):
        return self.mode is not None

    def on_enter(self):
        self._show(self.start, {})
        self.mode, self.t = "in", 0.0

    def go(self, name, **params):
        """Перейти на экран с затемнением. Во время перехода повторные вызовы игнорируются."""
        if self.pending is None and name in self.factories:
            self.pending = (name, params)
            self.mode, self.t = "out", 0.0

    def quit(self):
        if self.manager is not None:
            self.manager.request_quit()

    def _show(self, name, params):
        screen = self.factories[name](self, **params)
        screen.flow = self
        self.history.append(name)
        self.screens.change(screen)

    # ---------- State ----------

    def handle_event(self, event):
        if self.mode != "out":
            self.screens.handle_event(event)

    def update(self, dt):
        if self.mode is not None:
            self.t += dt
            if self.t >= self.fade:
                if self.mode == "out":
                    name, params = self.pending
                    self.pending = None
                    self._show(name, params)
                    self.mode, self.t = "in", 0.0
                else:
                    self.mode, self.t = None, 0.0
        self.screens.update(dt)

    def draw(self, surface, alpha):
        self.screens.draw(surface, alpha)
        veil = 0.0
        if self.mode == "out":
            veil = min(1.0, self.t / self.fade)
        elif self.mode == "in":
            veil = max(0.0, 1.0 - self.t / self.fade)
        if veil > 0.0:
            if self._veil is None or self._veil.get_size() != surface.get_size():
                self._veil = self._pg.Surface(surface.get_size())
                self._veil.fill((0, 0, 0))
            self._veil.set_alpha(int(255 * veil))
            surface.blit(self._veil, (0, 0))
