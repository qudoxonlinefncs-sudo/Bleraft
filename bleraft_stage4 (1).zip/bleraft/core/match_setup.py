"""Сборка матча: арена с разрушающимся полом, бойцы, бот, правила, ввод и отрисовка."""

import random

import settings
from ai.bot import BotController
from arena.arena import Arena
from arena.floor import ArenaFloor
from core.gameplay import GameplayState, create_fighters
from core.match_rules import MatchRules
from input.command_input import CommandInput
from input.gesture_recognizer import GestureRecognizer
from input.keyboard import KeyboardInput
from ui.combat_view import CombatView
from ui.renderer import SceneRenderer

MODE_MATCH = "match"
MODE_TRAINING = "training"


def time_limit_for(mode):
    return settings.MATCH_DURATION if mode == MODE_MATCH else None


def build_scene(ctx, mode=MODE_MATCH, difficulty="normal", seed=None):
    """Новый матч с чистым состоянием: HP, таймеры, комбо, позиции, арена.

    В обычном матче есть лимит времени и арена разрушается; в тренировке нет
    ни лимита, ни обрушения (Ring Out за край арены остаётся).
    """
    pg = ctx.pygame
    arena = Arena.from_settings()
    arena.attach_floor(ArenaFloor(
        arena, tile_size=settings.ARENA_TILE_SIZE, interval=settings.COLLAPSE_INTERVAL,
        warning=settings.COLLAPSE_WARNING, fall_time=settings.COLLAPSE_FALL_TIME,
        min_cols=settings.COLLAPSE_MIN_COLS, min_rows=settings.COLLAPSE_MIN_ROWS,
        enabled=(mode == MODE_MATCH)))
    fighters = create_fighters(arena)
    if seed is None:
        seed = random.randrange(1 << 30)
    return GameplayState(
        KeyboardInput(pg, ctx.profile.schemes(pg)),
        SceneRenderer(pg),
        arena=arena,
        fighters=fighters,
        command_input=CommandInput(pg),
        combat_view=CombatView(pg, font=ctx.font),
        recognizer=GestureRecognizer(),
        controllers={1: BotController(difficulty, seed)},
        rules=MatchRules(0, time_limit_for(mode)),
    )
